//
//  VisitingCardHorizontalVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 20/03/24.
//

import Foundation
import UIKit

class VisitingCardHorizontalVC: UIViewController {
    
    @IBOutlet weak var imgQR: UIImageView!
    @IBOutlet weak var viewVisitingCard: UIView!
    @IBOutlet weak var btnShare: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tap)
        
        let qrTap = UITapGestureRecognizer(target: self, action: #selector(zoomQR))
        imgQR.addGestureRecognizer(qrTap)
        
        btnShare.layer.cornerRadius = 15      
        viewVisitingCard.layer.borderColor = UIColor.lightGray.cgColor
        viewVisitingCard.layer.borderWidth = 0.5
        createContactsQR()
    }
    
    @objc func handleTap() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func zoomQR() {
        print("QR Tapped")
    }
    
    @IBAction func btnSharedTapped(_ sender: UIButton) {
        let pdfPath = viewVisitingCard.exportAsPdfFromView()
        let fileURL = NSURL(fileURLWithPath: pdfPath)
        var filesToShare = [Any]()
        filesToShare.append(fileURL)
        let activityViewController = UIActivityViewController(activityItems: filesToShare, applicationActivities: nil)
//        activityViewController.completionWithItemsHandler = { activityType, completed, returnedItems, activityError in
//
//        }
        activityViewController.completionWithItemsHandler = { (activityType: UIActivity.ActivityType?, completed: Bool, arrayReturnedItems: [Any]?, error: Error?) in
            if completed {
                print("share completed")
                return
            } else {
                print("share Not Completed")
            }
            if let shareError = error {
                print("error while sharing: \(shareError.localizedDescription)")
            }
        }

        self.present(activityViewController, animated: true, completion: nil)
        
    }
    
//    func createContactsQR() {
//        
//        let name = "Sanjay Arora"
//        let phone = "+919821627378"
//        let URL = "https://www.zentechinfo.com"
//        let URL2 = ""
//        let email = "sanjay.arora@zentechinfo.com"
//        let jobtitle = "Director"
//        let company = "Zentech Info Solutions"
//        
//        let street = "Plot No. C, 810, Centrum IT Park, 3, SG Barve Rd, opp. Railadevi TMC Office, Wagle Industrial Estate,"
//        let city = "Thane"
//        let state = "Maharashtra"
//        let zipCode = "400604"
//        let country = "India"
//        
//        let stringForQR = "BEGIN:VCARD\nVERSION:2.1\nN:\(name)\nTEL;CELL:\(phone)\nURL:\(URL)\nURL:\(URL2)\nEMAIL:\(email)\nTITLE:\(jobtitle)\nORG:\(company)\nADR;WORK:;;\(street);\(city);\(state);\(zipCode);\(country) \nEND:VCARD"
//        
//        imgQR.image =  QRHelper.generateQRCode(from: stringForQR)
//    }
    
    
    func createContactsQR() {
            
            let name = "Sanjay Arora"
            let phone = "+919821627378"
            let URL = "https://www.zentechinfo.com"
            let email = "sanjay.arora@zentechinfo.com"
            let jobtitle = "Director"
            let company = "Zentech Info Solutions"
            
            let street = "Plot No. C, 810, Centrum IT Park, 3, SG Barve Rd, opp. Railadevi TMC Office, Wagle Industrial Estate,"
            let city = "Thane"
            let state = "Maharashtra"
            let zipCode = "400604"
            let country = "India"
            
            // Generate a unique identifier for the image (e.g., UUID)
            let imageIdentifier = UUID().uuidString
            
            // Construct vCard with image identifier
            let stringForQR = """
                BEGIN:VCARD
                VERSION:2.1
                N:\(name)
                TEL;CELL:\(phone)
                URL:\(URL)
                EMAIL:\(email)
                TITLE:\(jobtitle)
                ORG:\(company)
                ADR;WORK:;;\(street);\(city);\(state);\(zipCode);\(country)
                PHOTO;VALUE=URL;TYPE=JPEG:\(imageIdentifier)
                END:VCARD
                """
            
            // Store the image data with the identifier
            let image = UIImage(named: "MyProfileIcon")
            imageDictionary[imageIdentifier] = image
            
            // Generate QR code
            imgQR.image = QRHelper.generateQRCode(from: stringForQR)
        }
        
        // Dictionary to store image data with identifiers
        var imageDictionary: [String: UIImage] = [:]
    
    
}
