//
//  ScanVisitingCardVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 19/03/24.
//

import UIKit
import Vision
import VisionKit

class ScanVisitingCardVC: UIViewController {
    
    
    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var scanImageView: UIImageView!
    @IBOutlet weak var ocrTextView: UITextView!
    @IBOutlet weak var scanButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    
    private var ocrRequest = VNRecognizeTextRequest(completionHandler: nil)
     
    var scannedImage:UIImage = UIImage()
    
    @IBAction func saveBtnAction(_ sender: Any) {
        
        convertToPdfFileAndShare()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //configure()
        
        configureOCR()
        
        configureUI()
        
        scanButton.addTarget(self, action: #selector(scanDocument), for: .touchUpInside)
        saveButton.addTarget(self, action: #selector(saveDocument), for: .touchUpInside)
        
        saveButton.isEnabled = true
    }
    
    func configureUI() {
        scanImageView.layer.borderWidth = 2.0
        scanImageView.layer.borderColor = UIColor.red.cgColor
        scanImageView.layer.cornerRadius = 10.0
        
        scanButton.backgroundColor = UIColor(red: 51/255, green: 51/255, blue: 51/255, alpha: 1.0)
        saveButton.backgroundColor = UIColor(red: 228/255, green: 30/255, blue: 38/255, alpha: 1.0)
        
        scanButton.layer.cornerRadius = 5.0
        saveButton.layer.cornerRadius = 5.0
        
        scanButton.setTitle("Scan Card", for: .normal)
        saveButton.setTitle("Save Card", for: .normal)
        scanButton.setTitleColor(.white, for: .normal)
        saveButton.setTitleColor(.white, for: .normal)
        
        scanImageView.image = scannedImage
        processImage(scannedImage)
    }
    

    @objc private func scanDocument() {
        let scanVC = VNDocumentCameraViewController()
        scanVC.delegate = self
        present(scanVC, animated: true)
    }
    

    @objc private func saveDocument() {
        
//        if scanImageView.image == nil { return }
//        let saveVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NewSaveBusinessCardViewController") as? NewSaveBusinessCardViewController ?? NewSaveBusinessCardViewController()
//        saveVC.scannedText = ocrTextView.text
//        saveVC.scannedImage = scanImageView.image ?? UIImage()
//        let navController = UINavigationController(rootViewController: saveVC)
//        GlobalConstants.isDetailsPageOn = false
//        self.present(navController, animated: true)
    }
    
    public func processImage(_ image: UIImage) {
        guard let cgImage = image.cgImage else { return }

        ocrTextView.text = ""
        scanButton.isEnabled = false
        
        let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        do {
            try requestHandler.perform([self.ocrRequest])
        } catch {
            print(error)
        }
    }
    
    private func configureOCR() {
        ocrRequest = VNRecognizeTextRequest { (request, error) in
            guard let observations = request.results as? [VNRecognizedTextObservation] else { return }
            
            var ocrText = ""
            for observation in observations {
                guard let topCandidate = observation.topCandidates(1).first else { return }
                
                ocrText += topCandidate.string + "\n"
            }
            
            
            DispatchQueue.main.async {
                self.ocrTextView.text = ocrText
                self.scanButton.isEnabled = true
            }
        }
        
        ocrRequest.recognitionLevel = .accurate
        ocrRequest.recognitionLanguages = ["en-US", "en-GB"]
        ocrRequest.usesLanguageCorrection = true
    }
    
    func convertToPdfFileAndShare(){
        
        if ocrTextView.text != "" {
            let fmt = UIMarkupTextPrintFormatter(markupText: ocrTextView.text)
            
            // 2. Assign print formatter to UIPrintPageRenderer
            let render = UIPrintPageRenderer()
            render.addPrintFormatter(fmt, startingAtPageAt: 0)
            
            // 3. Assign paperRect and printableRect
            let page = CGRect(x: 0, y: 0, width: 595.2, height: 841.8) // A4, 72 dpi
            render.setValue(page, forKey: "paperRect")
            render.setValue(page, forKey: "printableRect")
            
            // 4. Create PDF context and draw
            let pdfData = NSMutableData()
            UIGraphicsBeginPDFContextToData(pdfData, .zero, nil)
            
            for ind in 0..<render.numberOfPages {
                UIGraphicsBeginPDFPage();
                render.drawPage(at: ind, in: UIGraphicsGetPDFContextBounds())
            }
            
            UIGraphicsEndPDFContext();
            
            
            // 5. Save PDF file
            let ocrTextArray = ocrTextView.text.components(separatedBy: " ")
            let filename = ocrTextArray[0]
            
            // swiftlint:disable:next line_length
            guard let outputURL = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("\(filename)").appendingPathExtension("pdf")
            else { fatalError("Destination URL not created") }
            
            pdfData.write(to: outputURL, atomically: true)
            print("open \(outputURL.path)")
            
            if FileManager.default.fileExists(atPath: outputURL.path){
                
                let url = URL(fileURLWithPath: outputURL.path)
                let activityViewController: UIActivityViewController = UIActivityViewController(activityItems: [url], applicationActivities: nil)
                activityViewController.popoverPresentationController?.sourceView=self.view
                
                //If user on iPad
                if UIDevice.current.userInterfaceIdiom == .pad {
                    if activityViewController.responds(to: #selector(getter: UIViewController.popoverPresentationController)) {
                    }
                }
                present(activityViewController, animated: true, completion: nil)
                
            }
            else {
                print("document was not found")
            }
        }
    }
}

extension ScanVisitingCardVC: VNDocumentCameraViewControllerDelegate {
    
    func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
        guard scan.pageCount >= 1 else {
            controller.dismiss(animated: true)
            return
        }
        
        scanImageView.image = scan.imageOfPage(at: 0)
        processImage(scan.imageOfPage(at: 0))
        saveButton.isEnabled = true
        controller.dismiss(animated: true, completion: {
            self.saveDocument()
        })
    }
    
    func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFailWithError error: Error) {
        //Handle properly error
        controller.dismiss(animated: true)
    }
    
    func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
        controller.dismiss(animated: true)
    }
}
