//
//  VisitingCardVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 13/03/24.
//

import Foundation
import UIKit

class VisitingCardVC: UIViewController {
    
    @IBOutlet weak var viewVisitingCard: UIView!
    @IBOutlet weak var imgQR: UIImageView!
    @IBOutlet weak var btnShare: UIButton!
    @IBOutlet weak var btnSavedCard: UIButton!
    
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblMobile: UILabel!
    @IBOutlet weak var lblDeignation: UILabel!
    @IBOutlet weak var lblName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tap)
        Design()
    }
    
    @objc func handleTap() {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    func Design() {
        
        btnSavedCard.isHidden = true
        
        viewVisitingCard.layer.cornerRadius = 5
        viewVisitingCard.layer.borderColor = #colorLiteral(red: 0.5366806984, green: 0.7589941621, blue: 0.2418214977, alpha: 1)
        viewVisitingCard.layer.borderWidth = 1
        
        btnShare.layer.cornerRadius = 10
        btnSavedCard.layer.cornerRadius = 10
        
        lblName.text = GlobalConstants.loggedInMemberDetails.memberName
        lblEmail.text = GlobalConstants.loggedInMemberDetails.email
        lblMobile.text = "+91 \(GlobalConstants.loggedInMemberDetails.mobileNumber ?? "9999999999")"
        lblDeignation.text = UserDefaults.standard.string(forKey: Constants.myDesignation)
                
        createContactsQR()

    }
    
    @IBAction func btnSavedCardTapped(_ sender: UIButton) {
        let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SavedCardVC") as! SavedCardVC
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    @IBAction func btnShareTapped(_ sender: UIButton) {
        
        let pdfPath = viewVisitingCard.exportAsPdfFromView()
        let fileURL = NSURL(fileURLWithPath: pdfPath)
        var filesToShare = [Any]()
        filesToShare.append(fileURL)
        let activityViewController = UIActivityViewController(activityItems: filesToShare, applicationActivities: nil)
//        activityViewController.completionWithItemsHandler = { activityType, completed, returnedItems, activityError in
//
//        }
        activityViewController.completionWithItemsHandler = { (activityType: UIActivity.ActivityType?, completed: Bool, arrayReturnedItems: [Any]?, error: Error?) in
            if completed {
                print("share completed")
                return
            } else {
                print("share Not Completed")
            }
            if let shareError = error {
                print("error while sharing: \(shareError.localizedDescription)")
            }
        }

        self.present(activityViewController, animated: true, completion: nil)
        
    }
    
    
//    func createContactsQR() {
//        
//        let name = "Tarun Bhagat"
//        let phone = "+919727748679"
//        let URL = "https://www.zentechinfo.com"
//        let URL2 = ""
//        let email = "tarun.bhagat@zentechinfo.com"
//        let jobtitle = "Key Account Manager"
//        let company = "Zentech Info Solutions"
//        
//        let street = "Plot No. C, 810, Centrum IT Park, 3, SG Barve Rd, opp. Railadevi TMC Office, Wagle Industrial Estate,"
//        let city = "Thane"
//        let state = "Maharashtra"
//        let zipCode = "400604"
//        let country = "India"
//        
//        let stringForQR = "BEGIN:VCARD\nVERSION:2.1\nN:\(name)\nTEL;CELL:\(phone)\nURL:\(URL)\nURL:\(URL2)\nEMAIL:\(email)\nTITLE:\(jobtitle)\nORG:\(company)\nADR;WORK:;;\(street);\(city);\(state);\(zipCode);\(country) \nEND:VCARD"
//        
//        imgQR.image =  QRHelper.generateQRCode(from: stringForQR)
//    }
    
    func createContactsQR() {
            
        let name = GlobalConstants.loggedInMemberDetails.memberName
        let phone = GlobalConstants.loggedInMemberDetails.mobileNumber
        let URL = "https://www.zentechinfo.com"
        let email = GlobalConstants.loggedInMemberDetails.email
        let jobtitle = UserDefaults.standard.string(forKey: Constants.myDesignation)
        let company = "Zentech Info Solutions"
            
        let street = "Plot No. C, 810, Centrum IT Park, 3, SG Barve Rd, opp. Railadevi TMC Office, Wagle Industrial Estate,"
        let city = "Thane"
        let state = "Maharashtra"
        let zipCode = "400604"
        let country = "India"
        
        // Image URL
        let imageURL = "https://picsum.photos/200"
        
        // Construct the vCard string with image URL
        let stringForQR = "BEGIN:VCARD\nVERSION:3.0\nN:\(name)\nTEL;CELL:\(phone)\nURL:\(URL)\nEMAIL:\(email)\nTITLE:\(jobtitle)\nORG:\(company)\nADR;WORK:;;\(street);\(city);\(state);\(zipCode);\(country)\nPHOTO;VALUE=URL:\(imageURL)\nEND:VCARD"
        
        imgQR.image =  QRHelper.generateQRCode(from: stringForQR)
    }


    
    
}
