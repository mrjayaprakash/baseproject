//
//  IdCardVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 28/02/24.
//

import Foundation
import UIKit
import CoreImage

class IdCardVC: UIViewController {
    
    @IBOutlet weak var viewID: UIView!
    @IBOutlet weak var viewUpper: UIView!
    @IBOutlet weak var viewBackUpper: UIView!
    
    @IBOutlet weak var viewLower: UIView!
    @IBOutlet weak var viewBackLower: UIView!
    
    @IBOutlet weak var viewPhoto: UIView!
    @IBOutlet weak var imgProfile: UIImageView!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDesignation: UILabel!
    @IBOutlet weak var lblMobileNo: UILabel!
    @IBOutlet weak var lblDOJ: UILabel!
    @IBOutlet weak var lblBloodGroup: UILabel!
    
    @IBOutlet weak var imgBarCode: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Design()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tap)
        
    }
    
    func Design() {
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        viewPhoto.layer.cornerRadius = 20
        viewPhoto.layer.borderWidth = 2
        viewPhoto.layer.borderColor = UIColor.white.cgColor
        
        viewUpper.layer.cornerRadius = 50
        viewUpper.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]

        
        viewBackUpper.layer.cornerRadius = 50
        viewBackUpper.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        
        viewLower.layer.cornerRadius = 50
        viewLower.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        viewBackLower.layer.cornerRadius = 50
        viewBackLower.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        viewID.layer.borderWidth = 2
        viewID.layer.borderColor = UIColor.white.cgColor
        
        let QrNumber = "1183"
        
        let idCardDetails = IdCardModel(name: GlobalConstants.loggedInMemberDetails.memberName ?? "",
                                        designation: UserDefaults.standard.string(forKey: Constants.myDesignation) ?? "",
                                        image: GlobalConstants.loggedInMemberDetails.image ?? "",
                                        DOJ: "",
                                        bloodGroup: "",
                                        qrNumber: QrNumber)
        
        
        lblName.text = idCardDetails.name
        lblDesignation.text = idCardDetails.designation
        lblDOJ.text = idCardDetails.DOJ
        lblBloodGroup.text = idCardDetails.bloodGroup
        
        lblName.text = idCardDetails.name
        lblDesignation.text = idCardDetails.designation
        lblDOJ.text = idCardDetails.DOJ
        lblBloodGroup.text = idCardDetails.bloodGroup
        
        lblMobileNo.text = GlobalConstants.loggedInMemberDetails.mobileNumber
        
        imgBarCode.image = generateBarcode(from: QrNumber)

    }
    
    func generateBarcode(from string: String) -> UIImage? {
        // Convert the string to a data object
        guard let data = string.data(using: .ascii) else {
            print("Failed to convert string to data")
            return nil
        }
        
        // Create a CIFilter object
        guard let filter = CIFilter(name: "CICode128BarcodeGenerator") else {
            print("Failed to create CIFilter")
            return nil
        }
        
        // Set the input message for the filter
        filter.setValue(data, forKey: "inputMessage")
        
        // Get the output image from the filter
        guard let ciImage = filter.outputImage else {
            print("Failed to get output image from filter")
            return nil
        }
        
        // Convert the CIImage to a UIImage
        let scaleX = 200 / ciImage.extent.width
        let scaleY = 50 / ciImage.extent.height
        let transformedImage = ciImage.transformed(by: CGAffineTransform(scaleX: scaleX, y: scaleY))
        let uiImage = UIImage(ciImage: transformedImage)
        
        return uiImage
    }
    
    @objc func handleTap() {
        self.dismiss(animated: true)
    }
}
