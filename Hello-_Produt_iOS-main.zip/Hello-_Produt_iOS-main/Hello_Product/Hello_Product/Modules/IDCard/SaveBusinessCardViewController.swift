//
//  SaveBusinessCardViewController.swift
//  Hello_Product
//
//  Created by Zentech-038 on 27/03/24.
//

import UIKit
import Contacts
import ContactsUI
import AddressBookUI
import AddressBook

import MessageUI
import CoreLocation
import CoreLocationUI
import NaturalLanguage



class SaveBusinessCardViewController: UIViewController, CNContactViewControllerDelegate, MFMailComposeViewControllerDelegate {

    var scannedText:String = ""
    var scannedImage: UIImage = UIImage()
    var phoneNumbers:[String] = []
    
    
    @IBAction func callAction(_ sender: Any) {
        
        if phoneNumberTextField.text != "" {
            callNumber(phoneNumber: phoneNumberTextField.text ?? "")
        }
        
    }
    
    @IBAction func messageAction(_ sender: Any) {
        
        if emailTextField.text != "" {
            sendEmail(address: emailTextField.text ?? "")
        }
        
    }
    
    @IBAction func mapsAction(_ sender: Any) {
        if addressTextField.text != "" {
            
            let myAddress = addressTextField.text ?? ""
            let geoCoder = CLGeocoder()
            geoCoder.geocodeAddressString(myAddress) { (placemarks, error) in
                guard let placemarks = placemarks?.first else { return }
                let location = placemarks.location?.coordinate ?? CLLocationCoordinate2D()
                guard let url = URL(string:"http://maps.apple.com/?daddr=\(location.latitude),\(location.longitude)") else { return }
                UIApplication.shared.open(url)
            }
            
        }
    }
    
    @IBOutlet weak var saveBtn: UIButton!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var companyTextField: UITextField!
    @IBOutlet weak var designationTextField: UITextField!
    @IBOutlet weak var websiteTextField: UITextField!
    
    
    
    @IBOutlet weak var topNavBar: UIView!
    @IBOutlet weak var backArrowImage: UIImageView!
    @IBOutlet weak var topTitleLabel: UILabel!
    @IBOutlet weak var backBtn: UIButton!
    
    @IBOutlet weak var callBtn: UIButton!
    @IBOutlet weak var messageBtn: UIButton!
    @IBOutlet weak var mapsBtn: UIButton!
    
    @IBAction func backBtnAction(_ sender: Any) {
        self.dismiss(animated: true)
        
    }
    
    @IBAction func saveAction(_ sender: Any) {
        
        self.navigationController?.navigationBar.isHidden = false
        
        if nameTextField.text != "" || nameTextField.text != " " {
            addPhoneNumber(phNo: phoneNumberTextField.text ?? "", email: emailTextField.text ?? "", postalAddress: addressTextField.text ?? "")
            nameTextField.layer.borderWidth = 1.0
            nameTextField.layer.borderColor = UIColor.gray.cgColor
        } else {
            nameTextField.layer.borderWidth = 1.0
            nameTextField.layer.borderColor = UIColor.red.cgColor
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("OCR text : \(scannedText)")
        
        configureUI()
                
        /////// extract address
         extractAddressFromScannedText()
        
        
        /////// extract Company name
         extractCompanyNameFromScannedText()
        
        
        /////// phone number detection :
        let detector = try! NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue | NSTextCheckingResult.CheckingType.phoneNumber.rawValue)
        let matches = detector.matches(in: scannedText, options: [], range: NSRange(location: 0, length: scannedText.utf16.count))
        
        for match in matches {
            if match.resultType == .phoneNumber {
                guard let phoneNumber = match.phoneNumber else { continue }
                print(phoneNumber)
                phoneNumbers.append(phoneNumber)
                //phoneNumberTextField.text = phoneNumber
            }
        }
        
        if phoneNumbers.count > 0 {
            phoneNumberTextField.text = phoneNumbers[0]
        }
        
        
        /////// email detection :
        let emails = extractEmailAddrIn(text: scannedText)
        if emails.count > 0 {
            emailTextField.text = emails[0]
        }
        
        
        /////// full name detection :
        let names = extractFullNameIn(text: scannedText)
        if names.count > 0 {
            for nam in names {
                if nam.contains(" ") {
                    let components = nam.components(separatedBy: " ")
                    let firstComponent = components[0]
                    let secondComponent = components[1]
                    if (firstComponent == firstComponent.capitalized || firstComponent == firstComponent.uppercased()) && (secondComponent == secondComponent.capitalized || secondComponent == secondComponent.uppercased()) {
                        nameTextField.text = nam
                        break
                    }
                }
            }
        }
        
        /////// website detection :
        let website = extractWebsiteIn(text: scannedText)
        websiteTextField.text = website
        
        /////// designation detection :
        extractDesignationFromScannedText()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
        
        saveBtn.layer.cornerRadius = 5.0
    }
    
    func configureUI() {
        callBtn.layer.borderWidth = 1.5
        callBtn.layer.borderColor = UIColor.red.cgColor
        callBtn.layer.cornerRadius = 5.0
        callBtn.setTitleColor(.black, for: .normal)
        callBtn.titleLabel?.font = UIFont.systemFont(ofSize: 9.0)
        
        messageBtn.layer.borderWidth = 1.5
        messageBtn.layer.borderColor = UIColor.red.cgColor
        messageBtn.layer.cornerRadius = 5.0
        messageBtn.setTitleColor(.black, for: .normal)
        messageBtn.titleLabel?.font = UIFont.systemFont(ofSize: 9.0)
        
        mapsBtn.layer.borderWidth = 1.5
        mapsBtn.layer.borderColor = UIColor.red.cgColor
        mapsBtn.layer.cornerRadius = 5.0
        mapsBtn.setTitleColor(.black, for: .normal)
        mapsBtn.titleLabel?.font = UIFont.systemFont(ofSize: 9.0)
        
        if #available(iOS 13.0, *) {
            nameTextField.overrideUserInterfaceStyle = .light
            phoneNumberTextField.overrideUserInterfaceStyle = .light
            addressTextField.overrideUserInterfaceStyle = .light
            emailTextField.overrideUserInterfaceStyle = .light
            companyTextField.overrideUserInterfaceStyle = .light
            designationTextField.overrideUserInterfaceStyle = .light
            websiteTextField.overrideUserInterfaceStyle = .light
        } else {
            // Fallback on earlier versions
        }
                
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y = self.view.frame.origin.y - keyboardSize.height + 150
            }
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //uploadImage()
        
        self.navigationController?.navigationBar.isHidden = true
        backBtn.setTitle("", for: .normal)
    }
    
    
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    func addPhoneNumber(phNo : String, email:String, postalAddress:String) {
      if #available(iOS 9.0, *) {
          let store = CNContactStore()
          let contact = CNMutableContact()
          
          let homePhone = CNLabeledValue(label: CNLabelHome, value: CNPhoneNumber(stringValue :phNo ))
          let workEmail = CNLabeledValue(label:CNLabelWork, value:email as NSString)
          
          let name = nameTextField.text
          
          contact.givenName = name ?? ""
          contact.emailAddresses = [workEmail]
          contact.phoneNumbers = [homePhone]
          
          //address
          let address = CNMutablePostalAddress()
          address.street = postalAddress
          let home = CNLabeledValue<CNPostalAddress>(label:CNLabelHome, value:address)
          contact.postalAddresses = [home]
          
          let controller = CNContactViewController(forUnknownContact : contact)
          controller.contactStore = store
          controller.delegate = self
          self.navigationController?.setNavigationBarHidden(false, animated: true)
          self.navigationController!.pushViewController(controller, animated: true)
      }
    }
    
    
    func contactViewController(_ viewController: CNContactViewController, didCompleteWith contact: CNContact?) {

        self.dismiss(animated: true, completion: nil)
    }
    
    /////// extract email ID
    func extractEmailAddrIn(text: String) -> [String] {
        var results = [String]()

        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"
        let nsText = text as NSString
        do {
            let regExp = try NSRegularExpression(pattern: emailRegex, options: .caseInsensitive)
            let range = NSMakeRange(0, text.count)
            let matches = regExp.matches(in: text, options: .reportProgress, range: range)

            for match in matches {
                let matchRange = match.range
                results.append(nsText.substring(with: matchRange))
            }
        } catch (let error) {
            print(error)
        }

        return results
    }

    /////// extract full name
    func extractFullNameIn(text: String) -> [String] {
        var results = [String]()
        
        let emailRegex = "(?<! )[-a-zA-Z' ]{2,26}" // O.G.
        
        let nsText = text as NSString
        do {
            let regExp = try NSRegularExpression(pattern: emailRegex, options: .caseInsensitive)
            let range = NSMakeRange(0, text.count)
            let matches = regExp.matches(in: text, options: .reportProgress, range: range)

            for match in matches {
                let matchRange = match.range
                results.append(nsText.substring(with: matchRange))
            }
        } catch (let error) {
            print(error)
        }

        return results
    }
    
    /////// extract website url
    func extractWebsiteIn(text: String) -> String {
        var websiteURL = ""
        let components = text.components(separatedBy: "\n")
        
        for component in components {
            if component.lowercased().contains("www.") || component.lowercased().contains("https") || component.lowercased().contains("http") {
                websiteURL = component
            }
        }
        
        return websiteURL
    }
    
    /////// extract pin code
    func extractPinCodeIn(text: String) -> [String] {
        var results = [String]()

        let pincodeRegex = "^[1-9]{1}[0-9]{2}\\s{0, 1}[0-9]{3}$"
        let nsText = text as NSString
        do {
            let regExp = try NSRegularExpression(pattern: pincodeRegex, options: .caseInsensitive)
            let range = NSMakeRange(0, text.count)
            let matches = regExp.matches(in: text, options: .reportProgress, range: range)

            for match in matches {
                let matchRange = match.range
                results.append(nsText.substring(with: matchRange))
            }
        } catch (let error) {
            print(error)
        }

        return results
    }
    
    /*
    ///// extract address
    func extractAddressFromScannedText() {
        
        // search all cities , states , pin code
        
        let scannedComponents = scannedText.components(separatedBy: "\n")
        
        var addressString = ""
        for component in scannedComponents {

            for city in ScanCardConstants.cities {
                if component.lowercased().contains(city.lowercased()) {
                   addressString += component
                }
            }
            
            for state in ScanCardConstants.states {
                if component.lowercased().contains(state.lowercased()) {
                   addressString += component
                }
            }
            
            for str in ScanCardConstants.addressContents {
                if component.lowercased().contains(str.lowercased()) {
                   addressString += component
                }
            }
        }
        addressTextField.text = addressString
    } */
    
    
    ///// extract address
    
    func extractAddressFromScannedText() {
        
        // search all cities , states , pin code
        
        let scannedComponents = scannedText.components(separatedBy: "\n")
        
        var addressString = ""
        
        for ind in scannedComponents.indices {

            for city in ScanCardConstants.cities {
                if scannedComponents[ind].lowercased().contains(city.lowercased()) {
                    addressString = scannedComponents[ind]
                    //addressString += scannedComponents[ind]
                }
            }
            
            for state in ScanCardConstants.states {
                if scannedComponents[ind].lowercased().contains(state.lowercased()) {
                    addressString = scannedComponents[ind]
                    //addressString += scannedComponents[ind]
                }
            }
            
            for str in ScanCardConstants.addressContents {
                if scannedComponents[ind].lowercased().contains(str.lowercased()) {
                   addressString = scannedComponents[ind]
                    //addressString += scannedComponents[ind]
                }
            }
        }
        addressTextField.text = addressString
    }

    
    //////// extract address :
    /*
    func extractAddressFromScannedText() {
        
        // search all cities , states , pin code
        
        let scannedComponents = scannedText.components(separatedBy: "\n")
        
        var addressString = ""
        
        for ind in scannedComponents.indices {

            for city in ScanCardConstants.cities {
                if scannedComponents[ind].lowercased().contains(city.lowercased()) {
                   
                    if !addressString.contains(scannedComponents[ind]) {
                        addressString += scannedComponents[ind]
                        //addressString += scannedComponents[ind]
                    }
                    
                }
            }
            
            for state in ScanCardConstants.states {
                if scannedComponents[ind].lowercased().contains(state.lowercased()) {
                    if !addressString.contains(scannedComponents[ind]) {
                        addressString += scannedComponents[ind]
                        //addressString += scannedComponents[ind]
                    }
                }
            }
            
            for str in ScanCardConstants.addressContents {
                if scannedComponents[ind].lowercased().contains(str.lowercased()) {
                    if !addressString.contains(scannedComponents[ind]) {
                        addressString += scannedComponents[ind]
                        //addressString += scannedComponents[ind]
                    }
                }
            }
        }
        addressTextField.text = addressString
    } */
    
    ///// extract company name
    func extractCompanyNameFromScannedText() {
        
        let scannedComponents = scannedText.components(separatedBy: "\n")
        
        var companyString = ""
        for component in scannedComponents {
            
            for companyContent in ScanCardConstants.companyNameContents {
                if component.lowercased().contains(companyContent.lowercased()) && !strIsWebsite(text: component) {
                    companyString = component
                }
            }
        }
        companyTextField.text = companyString
    }
    
    ///// extract designation
    func extractDesignationFromScannedText() {
        
        let scannedComponents = scannedText.components(separatedBy: "\n")
        
        var companyString = ""
        for component in scannedComponents {
            
            for companyContent in ScanCardConstants.designationCompany {
                if component.lowercased().contains(companyContent.lowercased()) && !strIsWebsite(text: component) {
                    companyString = component
                }
            }
        }
        designationTextField.text = companyString
    }
    
    func strIsWebsite(text: String) -> Bool {
            if text.lowercased().contains("www.") || text.lowercased().contains("https") || text.lowercased().contains("http") {
               return true
            }
        return false
    }
    
    
    //MARK: Call number
    private func callNumber(phoneNumber:String) {
        
      var phoneNumber = phoneNumber.components(separatedBy: " ").joined()
      if let phoneCallURL = URL(string: "tel://\(phoneNumber)") {

        let application:UIApplication = UIApplication.shared
        if (application.canOpenURL(phoneCallURL)) {
            application.open(phoneCallURL, options: [:], completionHandler: nil)
        }
      }
    }

    //MARK: Create Email
    
    func sendEmail(address:String) {
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients([address])
            mail.setMessageBody("<p>Hello There</p>", isHTML: true)

            present(mail, animated: true)
        } else {
            // show failure alert
        }
    }

    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
}


extension SaveBusinessCardViewController {
    //MARK: Upload Image
    
    func uploadImage(){
            let image = scannedImage
            let imageData = image.jpegData(compressionQuality: 0.7)

            let url =  "https://app.covve.com/api/businesscards/scan"
            var urlRequest = URLRequest(url: URL(string: url)!)

            urlRequest.httpMethod = "post"
            let bodyBoundary = "--------------------------\(UUID().uuidString)"
            urlRequest.addValue("7a7f7525-115a-4ea2-9671-308a0431be8c", forHTTPHeaderField: "Authorization")
            urlRequest.addValue("multipart/form-data; boundary=\(bodyBoundary)", forHTTPHeaderField: "Content-Type")
          
            //attachmentKey is the api parameter name for your image do ask the API developer for this
           // file name is the name which you want to give to the file
            guard let imageData = imageData else { return }
        
            let requestData = createRequestBody(imageData: imageData, boundary: bodyBoundary, attachmentKey: "file", fileName: "myTestImage.jpg")
            
            urlRequest.addValue("\(requestData.count)", forHTTPHeaderField: "content-length")
            urlRequest.httpBody = requestData

            URLSession.shared.dataTask(with: urlRequest) { (data, httpUrlResponse, error) in

                if(error == nil && data != nil && data?.count != 0){
                    do{
                        let json = try JSONSerialization.jsonObject(with: data!, options: []) as? [String : Any]
                        print("Returned Json Data = \(String(describing: json))")
                        let addressData = json?["addresses"] as? [[String:Any]] ?? [[:]]
                        let address = addressData[0]["fullAddress"] ?? ""
                        print("Full Address is : \(address)")
                        DispatchQueue.main.async {
                            self.addressTextField.text = address as? String
                        }
                        
                        let jobs = json?["jobs"] as? [[String:Any]] ?? [[:]]
                        let company_name = jobs[0]["company"] as? String ?? ""
                        
                        let firstName = json?["firstName"] as? String ?? ""
                        let lastName = json?["lastName"] as? String ?? ""
                        
                        DispatchQueue.main.async {
                            if firstName != "" && lastName != "" {
                                self.nameTextField.text = "\(firstName) \(lastName)"
                            }
                            
                            if company_name != "" {
                                self.companyTextField.text = company_name
                            }
                        }
                        
                    } catch {
                        print("error Msg")
                    }
                }
            }.resume()
        }

        func createRequestBody(imageData: Data, boundary: String, attachmentKey: String, fileName: String) -> Data{
            let lineBreak = "\r\n"
            var requestBody = Data()

            requestBody.append("\(lineBreak)--\(boundary + lineBreak)" .data(using: .utf8)!)
            requestBody.append("Content-Disposition: form-data; name=\"\(attachmentKey)\"; filename=\"\(fileName)\"\(lineBreak)" .data(using: .utf8)!)
            requestBody.append("Content-Type: image/jpeg \(lineBreak + lineBreak)" .data(using: .utf8)!) // you can change the type accordingly if you want to
            requestBody.append(imageData)
            requestBody.append("\(lineBreak)--\(boundary)--\(lineBreak)" .data(using: .utf8)!)

            return requestBody
        }
}


extension UIButton {
    func setInsets(
        forContentPadding contentPadding: UIEdgeInsets,
        imageTitlePadding: CGFloat
    ) {
        self.contentEdgeInsets = UIEdgeInsets(
            top: contentPadding.top,
            left: contentPadding.left,
            bottom: contentPadding.bottom,
            right: contentPadding.right + imageTitlePadding
        )
        self.titleEdgeInsets = UIEdgeInsets(
            top: 0,
            left: imageTitlePadding,
            bottom: 0,
            right: -imageTitlePadding
        )
    }
}
