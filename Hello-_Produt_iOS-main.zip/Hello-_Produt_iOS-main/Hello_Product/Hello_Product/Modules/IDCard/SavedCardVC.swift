//
//  SavedCardVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 19/03/24.
//

import Foundation
import UIKit
import Vision
import VisionKit

class SavedCardVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var btnScanCard: UIButton!
    
    private var ocrRequest = VNRecognizeTextRequest(completionHandler: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Design()
    }
    
    func Design() {
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        btnBack.setTitle("", for: .normal)
        
        btnScanCard.layer.cornerRadius = 10
        
    }
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    @IBAction func btnScanCardTapped(_ sender: UIButton) {
        
        let scanVC = VNDocumentCameraViewController()
        scanVC.delegate = self
        present(scanVC, animated: true)
        
    }
    
}

extension SavedCardVC: VNDocumentCameraViewControllerDelegate {
    
    private func configureOCR() {
        ocrRequest = VNRecognizeTextRequest { (request, error) in
            guard let observations = request.results as? [VNRecognizedTextObservation] else { return }
            
            var ocrText = ""
            for observation in observations {
                guard let topCandidate = observation.topCandidates(1).first else { return }
                
                ocrText += topCandidate.string + "\n"
            }
            
            
            //            DispatchQueue.main.async {
            //                self.ocrTextView.text = ocrText
            //                self.scanButton.isEnabled = true
            //            }
        }
        
        ocrRequest.recognitionLevel = .accurate
        ocrRequest.recognitionLanguages = ["en-US", "en-GB"]
        ocrRequest.usesLanguageCorrection = true
    }
    
    private func processImage(_ image: UIImage) {
        guard let cgImage = image.cgImage else { return }

//        ocrTextView.text = ""
//        scanButton.isEnabled = false
        
        let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        do {
            try requestHandler.perform([self.ocrRequest])
        } catch {
            print(error)
        }
    }
    
    func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
        guard scan.pageCount >= 1 else {
            controller.dismiss(animated: true)
            return
        }
        
         let scanVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ScanVisitingCardVC") as? ScanVisitingCardVC ?? ScanVisitingCardVC()
        
        scanVC.scannedImage = scan.imageOfPage(at: 0)
        
        controller.dismiss(animated: true, completion: {
//            (UIApplication.topViewController() as! ViewController).handleTap()
//            (UIApplication.topViewController() as! ViewController).handleTap()
            UIApplication.topViewController()?.present(scanVC, animated: true)
            
        
            
        })
    }
    
    func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFailWithError error: Error) {
        //Handle properly error
        controller.dismiss(animated: true)
    }
    
    func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
        controller.dismiss(animated: true,completion: {
//            (UIApplication.topViewController() as! ViewController).handleTap()
//            (UIApplication.topViewController() as! ViewController).handleTap()
        })
    }
    
//    func playAlarmSound() {
//        guard let url = Bundle.main.url(forResource: "alarm", withExtension: "mp3") else { return }
//
//        do {
//            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
//            try AVAudioSession.sharedInstance().setActive(true)
//
//            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
//            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
//
//            /* iOS 10 and earlier require the following line:
//            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
//
//            guard let player = player else { return }
//
//            player.play()
//
//        } catch let error {
//            print(error.localizedDescription)
//        }
//    }
}

extension UIApplication {
    class func topViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController {
            return topViewController(base: nav.visibleViewController)
        }
        if let tab = base as? UITabBarController {
            if let selected = tab.selectedViewController {
                return topViewController(base: selected)
            }
        }
        if let presented = base?.presentedViewController {
            return topViewController(base: presented)
        }
        return base
    }
}
