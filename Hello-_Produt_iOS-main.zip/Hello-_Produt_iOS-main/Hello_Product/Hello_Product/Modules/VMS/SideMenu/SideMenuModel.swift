//
//  SideMenuModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 07/11/23.
//

import Foundation
import UIKit

struct SideMenuModel {
    var icon: UIImage
    var title: String
}
