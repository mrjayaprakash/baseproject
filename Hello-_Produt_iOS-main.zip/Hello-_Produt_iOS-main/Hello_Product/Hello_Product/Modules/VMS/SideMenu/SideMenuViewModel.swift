//
//  SideMenuViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 20/11/23.
//

//import Foundation
//import UIKit
//
//final class SideMenuViewModel {
//    
//    var memberDetails = MemberDetails()
//    var eventHandler: ((_ event: Event) -> Void)?
//    
//    func fetchMemberDetail(memberId: String) {
//        
//        self.eventHandler?(.loading)
//        
//        ApiManager.shared.request(
//            modelType: AllMember.self,
//            type: ManageUsersEndPoint.getMemberDetailsById(memberId: memberId)) { result in
//                switch result {
//                case .success(let memberDetails):
//                    
//                    let memberdetail = memberDetails.data[0]
//                    
//                    self.eventHandler?(.dataFatchedSuccessfully(memberDetail:memberdetail))
//                    
//                case .failure(let error):
//                    self.eventHandler?(.error(error))
//                }
//        }
//    }
//}
//
//extension SideMenuViewModel {
//
//    enum Event {
//        case loading
//        case stopLoading
//        case dataLoaded
//        case error(Error?)
//        case dataFatchedSuccessfully(memberDetail: MemberDetails)
//    }
//
//}
