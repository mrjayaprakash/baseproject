//
//  ManageUsersVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 13/11/23.
//

import Foundation
import UIKit
import SDWebImage

class ManageUsersVC: UIViewController {
    
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var btnAddUser: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var btnSOS: UIButton!
    
    private var viewModel = ManageUsersViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.navigationBar.isHidden = true
        design()
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "ManageUsersCell", bundle: nil), forCellReuseIdentifier: "ManageUsersCell")
        tableView.separatorStyle = .none
        tableView.bounces = false
        
        print(viewModel.allMemberArray.count)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        viewModel.fetchMembers()
        observeEvent()
    }
    
    func design() {
        
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        btnAddUser.layer.cornerRadius = 5
        
        btnAddUser.titleLabel?.font = UIFont.systemFont(ofSize: 12)
                
        btnBack.setTitle("", for: .normal)
        btnSOS.setTitle("", for: .normal)

        
        lblTitle.text = GlobalConstants.loggedInMemberDetails.siteName
        
        tableView.backgroundColor = .white
        
        navigationController?.navigationBar.isHidden = true
        
    }
    
    @IBAction func addUsersTapped(_ sender: UIButton) {
        
        let storyboard = UIStoryboard(name: "VMS", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "AddMemberVC") as! AddMemberVC
        
        self.navigationController?.pushViewController(vc, animated: true)

    }
    @IBAction func btnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSOSTapped(_ sender: UIButton) {
    }
}

extension ManageUsersVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.allMemberArray.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let data = viewModel.allMemberArray[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ManageUsersCell", for: indexPath) as! ManageUsersCell
        
        cell.memberID = data.memberId ?? 0
        cell.memberData = data
        
        cell.delegate = self
                
        cell.nameLbl.text = data.memberName
        cell.roleLbl.text = data.roleName
        
        cell.imgProfile.sd_setImage(with: URL(string: data.image ?? ""), placeholderImage: UIImage(named: "CircleProfileImage"))
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
}

extension ManageUsersVC: ManageUsersProtocol {
    
    func presentAlertViewForDeleteUser(alert: UIAlertController) {
        self.present(alert, animated: true)
    }
    
    func presentAlertView(alert: UIAlertController) {
        
//        self.present(alert, animated: true, completion: { [weak self] in
//            self?.fetchAllUsersAPI()
//        })
    }
    
    func showActIndicator() {
        print("showActivityIndicator")
        self.showActIndicator()
    }
    
    func hideActIndicator() {
        print("hideActivityIndicator")
        self.hideActivityIndicator()
    }
    
    func dismissScreen() {
        self.dismiss(animated: true)

    }
    
    func openEditScreen(data: MemberDetails) {
        
        print("Edit Tapped")
        let storyboard = UIStoryboard(name: "VMS", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "EditMemberVC") as! EditMemberVC
        vc.memberData = data
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func callDeleteMemberApi(memberId: String) {
        viewModel.deleteMember(memberid: memberId)
//        observeEvent()
    }
    
}

extension ManageUsersVC {
    
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            
            case .loading:
                print("Data Loading")
            case .stopLoading:
                print("Data Stoped Loading")
            case .dataLoaded:
                print("Data Loaded")
            case .error(let error):
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                }
            case .memberDetailFetched(memberDetail: let memberDetail):
                
//                print(memberDetail.data.count)
//                viewModel.allMemberArray = memberDetail.data
                viewModel.allMemberArray = filterMembersByRole(role: GlobalConstants.loggedInMemberDetails.roleName ?? "", allMembers: memberDetail.data ?? [], memberDetail: GlobalConstants.loggedInMemberDetails)
//                filterDataForLoggedInUser(loggedInData: GlobalConstants.loggedInMemberDetails, dataArray: memberDetail.data ?? [])
                
                
                if memberDetail.data?.count ?? 0 <= 0 {
                    DispatchQueue.main.async {
                        self.tableView.isHidden = true
                    }
                }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .memberDeletedSuccessfully:
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                viewModel.fetchMembers()
                print("Member Deleted Successfully")
            }
        }
    }
    
    
    func filterMembersByRole(role: String, allMembers: [MemberDetails], memberDetail: MemberDetails) -> [MemberDetails] {
        
        switch role {
        case "Super Admin":
            
            var array = [MemberDetails]()
            
            for member in allMembers {
                if member.memberId != memberDetail.memberId {
                    if member.clientId == memberDetail.clientId {
//                        if member.roleName != "Master Admin" && member.roleName != "Visitor Device"{
//                            array.append(member)
//                        }
                        if member.roleName == "Site Admin" {
                            array.append(member)
                        }
                    }
                }
            }
            
            return array
            
            
        case "Site Admin":
            
            var array = [MemberDetails]()
            
            for member in allMembers {
                if member.memberId != memberDetail.memberId {
                    if member.siteId == memberDetail.siteId {
//                        if member.roleName != "Super Admin" && member.roleName != "Site Admin" && member.roleName != "Master Admin" {
//                            array.append(member)
//                        }
                        
                        if member.roleName == "Unit Admin" {
                            array.append(member)
                        }
                        
                    }
                }
            }
            
            return array
            
        case "Unit Admin":
            var array = [MemberDetails]()

            for member in allMembers {
                if member.memberId != memberDetail.memberId {
                    if member.siteId == memberDetail.siteId {
                        if member.unitId == memberDetail.unitId {
                            if member.roleName == "Employee" {
                                array.append(member)
                            }
                        }
//                        if member.roleName != "Super Admin" && member.roleName != "Site Admin" && member.roleName != "Master Admin" && member.roleName != "Visitor Device"{
//                            array.append(member)
//                        }
                    }
                }
            }
            
            return array
            
        default:
            return []
        }
    }
}

