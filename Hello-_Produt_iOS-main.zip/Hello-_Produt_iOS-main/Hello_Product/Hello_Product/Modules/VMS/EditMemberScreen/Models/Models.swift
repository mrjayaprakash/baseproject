//
//  Models.swift
//  Hello_Product
//
//  Created by Zentech-038 on 23/11/23.
//

import Foundation

struct Gender {
    var id: Int
    var name: String
    
    init(id: Int, name: String) {
        self.id = id
        self.name = name
    }
}

