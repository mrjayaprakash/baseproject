//
//  EdimMemberViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 23/11/23.
//

import Foundation

class EditMemberViewModel {
    
    var eventHandler: ((_ event: Event) -> Void)?
    
    var editMemberDetail: AddMemberDetail?
    
    func callUpdateMemberDetail(memberId: String) {
        var multipart = MultipartRequest()
        
        let siteId = editMemberDetail?.siteId ?? 0
        let memberName = editMemberDetail?.memberName ?? ""
        let mobileNumber = editMemberDetail?.mobileNumber ?? ""
        let email = editMemberDetail?.email ?? ""
        let address = editMemberDetail?.address ?? ""
        let genderId = editMemberDetail?.genderId ?? 0
        let roleId = editMemberDetail?.roleId ?? 0
        let unitId = editMemberDetail?.unitId ?? 0
        let createdBy = editMemberDetail?.createdBy ?? ""
        
        for field in [
            "siteId": siteId,
            "memberName": memberName,
            "mobileNumber": mobileNumber,
            "email": email,
            "address": address,
            "statusId": 1,
            "genderId": genderId,
            "roleId": roleId,
            "unitId": unitId,
            "employeeTechAccessId": 1,
            "createdBy": createdBy,
            "isActiveId": 1
        ] as [String : Any] {
            multipart.add(key: field.key, value: "\(field.value)")
        }

        if let data = editMemberDetail?.image?.pngData() {
            multipart.add(
                key: "image",
                fileName: "visitorpic.png",
                fileMimeType: "image/png",
                fileData: data
            )
        } else {
            print("No Image Found")
        }

        
        var success_param:Bool = false
        
        /// Create a regular HTTP URL request & use multipart components
        let url = URL(string: "https://helloproduct.azurewebsites.net/api/ManageUsers/putUsers/\(memberId)")!
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue(multipart.httpContentTypeHeaderValue, forHTTPHeaderField: "Content-Type")
        request.httpBody = multipart.httpBody

        let session = URLSession(configuration: .default)
        session.dataTask(with: request) { (data, response, error) in
            if error != nil {
                self.eventHandler?(.error(error))
            } else {
                
                //Data received.
                guard let data = data,
                        let response = response as? HTTPURLResponse,
                        error == nil
                    else {
                    
                        print("error", error ?? URLError(.badServerResponse))
                        return
                    }

                if response.statusCode == 200 {
                    print("HTTP Success")
                } else {
                    print("HTTP Error code = \(response.statusCode)")
                    if response.statusCode == 401 {
                       // self.logoutDueToTimeout()
                    }
                }

                if let json = try? JSONSerialization.jsonObject(with: data) as? [String:Any] {
//                    print("Data received = \(json)")
                    let isSuccess = json["isSuccess"] as? Bool ?? false
                    let message = json["message"] as? String ?? ""
                    success_param = isSuccess
                    
                    if isSuccess {
                        self.eventHandler?(.memberEditedSuccessfully(message: message))
                    } else {
                        self.eventHandler?(.memberEditUnsuccessfully(message: message))
                    }
                    
                } else {
                    print(data)
                    self.eventHandler?(.memberEditUnsuccessfully(message: "Something went wrong"))
                }
            }
        }.resume()
    }
    
}

extension EditMemberViewModel {
    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case memberEditedSuccessfully(message: String)
        case memberEditUnsuccessfully(message: String)

    }
}
