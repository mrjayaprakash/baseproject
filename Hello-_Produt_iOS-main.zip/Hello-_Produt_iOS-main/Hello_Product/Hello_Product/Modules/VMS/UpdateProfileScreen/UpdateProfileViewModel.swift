//
//  UpdateProfileViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 20/11/23.
//

import Foundation
import UIKit

class UpdateProfileViewModel {
    
    var eventHandler: ((_ event: Event) -> Void)?

//    // Define maximum size in bytes (500 KB)
//    let maxSizeInBytes = 500 * 1024 // 500 KB
//
//    // Define compression settings
//    let compressionQuality: CGFloat = 0.5 // Set your desired compression quality (0.0 - 1.0)

    
    var updateProfileDetail: UpdateProfilrDetail?
    
    func createMultipartRequest(with data: UpdateProfilrDetail, image: UIImage) {
        let boundary = "Boundary-\(UUID().uuidString)"
        let url = URL(string: "YOUR_API_ENDPOINT_HERE")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        let body = NSMutableData()

        // Append text fields
        for (key, value) in [
            "id": "\(data.id)",
            "memberName": data.memberName,
            "mobileNumber": data.mobileNumber,
            "email": data.email,
            "address": data.address
        ] {
            body.appendString("--\(boundary)\r\n")
            body.appendString("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
            body.appendString("\(value)\r\n")
        }
        
        // Append image data
        let imageData = image.jpegData(compressionQuality: 0.5)!
        body.appendString("--\(boundary)\r\n")
        body.appendString("Content-Disposition: form-data; name=\"image\"; filename=\"image.jpg\"\r\n")
        body.appendString("Content-Type: image/jpeg\r\n\r\n")
        body.append(imageData)
        body.appendString("\r\n")

        body.appendString("--\(boundary)--\r\n")

        request.httpBody = body as Data

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error)")
                // Handle error here
                return
            }

            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else {
                print("Invalid response")
                // Handle invalid response here
                return
            }

            if let data = data {
                // Handle success response with data
                print("Response data: \(String(data: data, encoding: .utf8) ?? "")")
            }
        }.resume()
    }
    
//    func compressImageIfNeeded(_ image: UIImage, maxSizeInBytes: Int, compressionQuality: CGFloat) -> Data? {
//        guard let imageData = image.jpegData(compressionQuality: 1.0) else {
//            return nil
//        }
//        
//        // Check if the image size exceeds the maximum allowed size
//        if imageData.count > maxSizeInBytes {
//            let scaleFactor = CGFloat(maxSizeInBytes) / CGFloat(imageData.count)
//            let targetSize = CGSize(width: image.size.width * scaleFactor, height: image.size.height * scaleFactor)
//            return resizeAndCompressImage(image, targetSize: targetSize, compressionQuality: compressionQuality)
//        } else {
//            return imageData
//        }
//    }
//    
//    // Function to resize and compress the image
//    func resizeAndCompressImage(_ image: UIImage, targetSize: CGSize, compressionQuality: CGFloat) -> Data? {
//        UIGraphicsBeginImageContextWithOptions(targetSize, false, 1.0)
//        image.draw(in: CGRect(origin: .zero, size: targetSize))
//        guard let resizedImage = UIGraphicsGetImageFromCurrentImageContext() else {
//            UIGraphicsEndImageContext()
//            return nil
//        }
//        UIGraphicsEndImageContext()
//        
//        return resizedImage.jpegData(compressionQuality: compressionQuality)
//    }

    func callUpdateMemberDetail() {
        
        self.eventHandler?(.loading)
                
        var multipart = MultipartRequest()
        
        let id = updateProfileDetail?.id ?? 0
        let memberName = updateProfileDetail?.memberName ?? ""
        let mobileNumber = updateProfileDetail?.mobileNumber ?? ""
        let email = updateProfileDetail?.email ?? ""
        let address = updateProfileDetail?.address ?? ""

        
        for field in [
            "memberName": memberName,
            "mobileNumber": mobileNumber,
            "email": email,
            "address": address
        ] as [String : Any] {
            multipart.add(key: field.key, value: "\(field.value)")
        }
        if let data = updateProfileDetail?.image?.pngData() {
            multipart.add(
                key: "image",
                fileName: "visitorpic.png",
                fileMimeType: "image/png",
                fileData: data
            )
        } else {
            print("No Image Found")
        }

        
        var success_param:Bool = false
        
        /// Create a regular HTTP URL request & use multipart components
        let url = URL(string: "https://helloproduct.azurewebsites.net/api/ManageUsers/putUsers/\(id)")!
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue(multipart.httpContentTypeHeaderValue, forHTTPHeaderField: "Content-Type")
        request.httpBody = multipart.httpBody

        let session = URLSession(configuration: .default)
        session.dataTask(with: request) { (data, response, error) in
            if error != nil {
                self.eventHandler?(.error(error))
            } else {
                
                //Data received.
                guard let data = data,
                        let response = response as? HTTPURLResponse,
                        error == nil
                    else {
                        print("error", error ?? URLError(.badServerResponse))
                        return
                    }

                if response.statusCode == 200 {
                    print("HTTP Success")
                } else {
                    print("HTTP Error code = \(response.statusCode)")
                    if response.statusCode == 401 {
                       // self.logoutDueToTimeout()
                        self.eventHandler?(.error(error))
                    }
                }

                if let json = try? JSONSerialization.jsonObject(with: data) as? [String:Any] {
//                    print("Data received = \(json)")
                    let isSuccess = json["isSuccess"] as? Bool ?? false
                    let message = json["message"] as? String ?? ""
                    if isSuccess {
                        self.eventHandler?(.updateSuccessfully(message: message))
                    } else {
                        self.eventHandler?(.updateUnsuccessful(message: message))
                    }
                    success_param = isSuccess
                } else {
                    print(data)
                }
            }
        }.resume()
    }
    
}

extension UpdateProfileViewModel {
    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case updateSuccessfully(message: String)
        case updateUnsuccessful(message: String)


    }
}
