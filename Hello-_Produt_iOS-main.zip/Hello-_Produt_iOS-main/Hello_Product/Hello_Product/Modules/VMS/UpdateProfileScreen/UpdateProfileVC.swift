//
//  UpdateProfileVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 13/11/23.
//

import Foundation
import UIKit
import AVFoundation
import Photos

class UpdateProfileVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var btnImagePicker: UIButton!
    @IBOutlet weak var btnUpdate: UIButton!
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtMobileNo: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    
    
    let viewModel = UpdateProfileViewModel()
//    var imagePicked: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        design()
    }

    @IBAction func btnBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btnUpdateTapped(_ sender: UIButton) {
        
        if txtName.text != "" && txtMobileNo.text != "" && txtAddress.text != "" && txtEmail.text != "" {
            
            if !isValidIndianMobileNumber(txtMobileNo.text ?? "") {
                self.hideActivityIndicator()
                self.view.makeToast("Please enter valid Mobile number")
                return
            }
                        
            if !isValidEmail(txtEmail.text ?? "") {
                self.hideActivityIndicator()
                self.view.makeToast("Please enter valid email id")
                return
            }
            
            if !isValidName(txtName.text ?? "") {
                self.hideActivityIndicator()
                self.view.makeToast("Please enter valid Name")
                return
            }

            
    
//            let details = UpdateProfilrDetail(id: Int(GlobalConstants.memberId) ?? 0,
            let details = UpdateProfilrDetail(id: GlobalConstants.loggedInMemberDetails.memberId ?? 0,
                                              memberName: txtName.text ?? "",
                                              mobileNumber: txtMobileNo.text ?? "",
                                              email: txtEmail.text ?? "",
                                              address: txtAddress.text ?? "",
                                              image: imgProfile.image)
            
            viewModel.updateProfileDetail = details
            
            observeEvent()
            
            
//            viewModel.createMultipartRequest(with: details, image: details.image)
            
            viewModel.callUpdateMemberDetail()
            
        } else {
            
            DispatchQueue.main.async {
                self.view.makeToast("Please fill All the Details")
            }
        }
        
        
        print("Update Details Here")
    }
    @IBAction func btnImagePickerTapped(_ sender: UIButton) {
        showImagePickerOptions()
    }
    
    
    func design() {
        
        navigationController?.navigationBar.isHidden = true
        
        btnBack.setTitle("", for: .normal)
        btnUpdate.layer.cornerRadius = 15
        btnImagePicker.layer.cornerRadius = btnImagePicker.layer.frame.height / 2
        btnImagePicker.setTitle("", for: .normal)
//        btnImagePicker.layer.borderWidth = 1
//        btnImagePicker.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        
        imgProfile.layer.borderWidth = 3
        imgProfile.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        imgProfile.layer.cornerRadius = 20
        
        btnImagePicker.layer.cornerRadius = 5

        
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        txtName.text = GlobalConstants.loggedInMemberDetails.memberName
        txtMobileNo.text = GlobalConstants.loggedInMemberDetails.mobileNumber
        txtEmail.text = GlobalConstants.loggedInMemberDetails.email
        txtAddress.text = GlobalConstants.loggedInMemberDetails.address
        
        
        self.imgProfile.sd_setImage(with: URL(string: GlobalConstants.loggedInMemberDetails.image ?? ""), placeholderImage: UIImage(named: "CircleProfileImage"))
        
        txtMobileNo.isUserInteractionEnabled = false
    }
    
    // Function to present options for selecting/capturing an image
//    func showImagePickerOptions() {
//        let picker = UIImagePickerController()
//        picker.delegate = self
//            
//        let alertController = UIAlertController(title: "Select Image", message: nil, preferredStyle: .actionSheet)
//            
//        let pickFromGalleryAction = UIAlertAction(title: "Pick from Gallery", style: .default) { _ in
//            self.checkPhotoLibraryPermission()
//        }
//            
//        let clickImageAction = UIAlertAction(title: "Click Image", style: .default) { _ in
//            self.checkCameraPermission()
//        }
//            
//        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
//            
//        alertController.addAction(pickFromGalleryAction)
//        alertController.addAction(clickImageAction)
//        alertController.addAction(cancelAction)
//            
//        // Present the options
//        self.present(alertController, animated: true, completion: nil)
//    }
    
    
    func showImagePickerOptions() {
        let picker = UIImagePickerController()
        picker.delegate = self
        
        let alertController = UIAlertController(title: "Select Image", message: nil, preferredStyle: .actionSheet)
        
        let pickFromGalleryAction = UIAlertAction(title: "Pick from Gallery", style: .default) { _ in
            self.checkPhotoLibraryPermission()
        }
        
        let clickImageAction = UIAlertAction(title: "Click Image", style: .default) { _ in
            self.checkCameraPermission()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertController.addAction(pickFromGalleryAction)
        alertController.addAction(clickImageAction)
        alertController.addAction(cancelAction)
        
        // Set the popover presentation controller properties for iPad
        if let popoverPresentationController = alertController.popoverPresentationController {
            popoverPresentationController.sourceView = self.view
            popoverPresentationController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            popoverPresentationController.permittedArrowDirections = []
        }
        
        // Present the options
        self.present(alertController, animated: true, completion: nil)
    }

    
    
    func checkPhotoLibraryPermission() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            let status = PHPhotoLibrary.authorizationStatus()
            switch status {
            case .authorized:
                self.showPhotoPicker()
            case .notDetermined:
                PHPhotoLibrary.requestAuthorization { status in
                    if status == .authorized {
                        DispatchQueue.main.async {
                            self.showPhotoPicker()
                        }
                    } else {
                        // Handle when permission is denied
                    }
                }
            case .denied, .restricted:
                // Handle when permission is denied or restricted
                break
            @unknown default:
                break
            }
        }
    }
    
    // Function to check and request permission for camera
    func checkCameraPermission() {
        let authStatus = AVCaptureDevice.authorizationStatus(for: .video)
        switch authStatus {
        case .authorized:
            self.showCamera()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                if granted {
                    self.showCamera()
                } else {
                    // Handle when permission is denied
                }
            }
        case .denied, .restricted:
            // Handle when permission is denied or restricted
            break
        @unknown default:
            break
        }
    }
    
    func showPhotoPicker() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .photoLibrary
            self.present(picker, animated: true, completion: nil)
        }
    }
        
    func showCamera() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .camera
            self.present(picker, animated: true, completion: nil)
        }
    }

        
    // Delegate method to handle the selected image
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            // Set the selected image to your UIImageView
            imgProfile.image = selectedImage
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    // Delegate method to handle cancellation
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

extension UpdateProfileVC {
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                DispatchQueue.main.async {
                    self.showActivityIndicator()
                }
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Data Loaded")
            case .error(let error):
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                }
                print(error?.localizedDescription)
                
            case .updateSuccessfully(message: let message):
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    self.view.makeToast(message)
                }
            case .updateUnsuccessful(message: let message):
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    self.view.makeToast(message)
                }
            }
            
        }
    }
}

