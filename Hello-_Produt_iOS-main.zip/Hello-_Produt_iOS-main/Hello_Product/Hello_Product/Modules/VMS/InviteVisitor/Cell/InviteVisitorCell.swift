//
//  InviteVisitorCell.swift
//  Hello_Product
//
//  Created by Zentech-038 on 27/11/23.
//

import UIKit

protocol InviteModificationProtocol {
    func cancelInvitation(visitorID:Int, visitorInfo: VisitorDetail)
    func rescheduleInvitation(visitorInfo: VisitorDetail)
}

class InviteVisitorCell: UITableViewCell {
    
    var delegate: InviteModificationProtocol?
    var visitorID: Int = 0
    var visitorMobileNumber: String = ""
    var visitorInfo: VisitorDetail = VisitorDetail()
    var memberName: String = ""
    var memberId: String = String(GlobalConstants.loggedInMemberDetails.memberId ?? 0)
    
    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var numberLbl: UILabel!
    @IBOutlet weak var visitingFrom: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var rescheduleBtn: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBAction func btnCancelTapped(_ sender: UIButton) {
        delegate?.cancelInvitation(visitorID: visitorID, visitorInfo: visitorInfo)
    }
    @IBAction func btnRecheduleTapped(_ sender: UIButton) {
        delegate?.rescheduleInvitation(visitorInfo: visitorInfo)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        innerView.backgroundColor = ColorConstants.cellBackgroundColor
        innerView.layer.cornerRadius = 8
                
        let attrFont = UIFont.systemFont(ofSize: 13.0)
        let title = cancelBtn.titleLabel!.text!
        let attrTitle = NSAttributedString(string: title, attributes: [NSAttributedString.Key.font: attrFont])
        cancelBtn.setAttributedTitle(attrTitle, for: UIControl.State.normal)
    
        let title2 = rescheduleBtn.titleLabel!.text!
        let attrTitle2 = NSAttributedString(string: title2, attributes: [NSAttributedString.Key.font: attrFont])
        rescheduleBtn.setAttributedTitle(attrTitle2, for: UIControl.State.normal)
    
    }
    
}
