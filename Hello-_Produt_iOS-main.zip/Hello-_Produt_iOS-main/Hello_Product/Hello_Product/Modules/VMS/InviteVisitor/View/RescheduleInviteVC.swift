//
//  RescheduleInviteVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 28/11/23.
//

import Foundation
import UIKit

protocol RescheduleProtocol {
    func refreshScreenAfterReschedule(response: InviteResponse)
}

class RescheduleInviteVC: UIViewController {
    
    @IBOutlet weak var viewPopUp: UIView!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var btnReschedule: UIButton!
    @IBOutlet weak var viewEntryDate: UIView!
    @IBOutlet weak var viewExitDate: UIView!
    @IBOutlet weak var txtEntryDate: UITextField!
    @IBOutlet weak var txtExitDate: UITextField!
    @IBOutlet weak var btnEntryDateCalendar: UIButton!
    @IBOutlet weak var btnExitDateCalendar: UIButton!
    
    let viewModel = InviteVisitorViewModel()
    var visitorInfo = VisitorDetail()
    var Delegate: RescheduleProtocol?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnReschedule.setTitle("Reschedule", for: .normal)
        btnCancel.setTitle("Cancel", for: .normal)
//        btnReschedule.tintColor = .white
//        btnReschedule.backgroundColor = ColorConstants.HDFCRedColor
//        dismissBtn.backgroundColor = ColorConstants.ThemeGrayColor
//        dismissBtn.tintColor = ColorConstants.HDFCRedColor
//        topTitleLabel.backgroundColor = ColorConstants.HDFCRedColor
        
        btnEntryDateCalendar.setTitle("", for: .normal)
        btnExitDateCalendar.setTitle("", for: .normal)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tap)
        view.backgroundColor = .black.withAlphaComponent(0.8)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.txtEntryDate.setDatePickerAsInputViewFor(target: self, selector: #selector(self.doneButtonPressed))
        self.txtExitDate.setDatePickerAsInputViewFor(target: self, selector: #selector(self.doneButtonPressed2))
        
        viewEntryDate.layer.cornerRadius = 8.0
        viewEntryDate.layer.borderWidth = 1.0
        viewEntryDate.layer.borderColor = UIColor.lightGray.cgColor
        
        viewExitDate.layer.cornerRadius = 8.0
        viewExitDate.layer.borderWidth = 1.0
        viewExitDate.layer.borderColor = UIColor.lightGray.cgColor
        
    }
    @IBAction func btnEntryDateCalendarTapped(_ sender: UIButton) {
        txtEntryDate.becomeFirstResponder()
    }
    @IBAction func btnExitDateCalendarTapped(_ sender: UIButton) {
        txtExitDate.becomeFirstResponder()
    }
    @IBAction func btnCancelTapped(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
    @IBAction func btnRescheduleTapped(_ sender: UIButton) {
        
        if txtEntryDate.text != "" && txtExitDate.text != "" {
            let dateFormatter = DateFormatter()
            dateFormatter.locale = Locale(identifier: "en_US_POSIX") // set locale to reliable US_POSIX
            dateFormatter.dateFormat = "MM-dd-yyyy HH:mm:ss"
            let entryDate = dateFormatter.date(from:txtEntryDate.text ?? "")!
            let exitDate = dateFormatter.date(from:txtExitDate.text ?? "")!
            
            if entryDate >= exitDate {
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Alert", message: "Exit date needs to be greater than Entry date !", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                        switch action.style{
                        case .default:
                            print("default")
                        case .cancel:
                            print("cancel")
                        case .destructive:
                            print("destructive")
                        }
                    }))
                    self.present(alert, animated: true)
                }
                return
            }
            
//            let details = RescheduleDetails(visitorId: visitorInfo.visitorId ?? 0,
//                                            expectedEntryTime: txtEntryDate.text ?? "",
//                                            expectedExitTime: txtExitDate.text ?? "",
//                                            memberId: GlobalConstants.loggedInMemberDetails.memberId ?? 0,
//                                            createdBy: GlobalConstants.loggedInMemberDetails.memberId ?? 0)
            
            let details = RescheduleDetails(visitorId: visitorInfo.visitorId ?? 0,
                                            visitorName: visitorInfo.visitorName ?? "",
                                            visitorMobileNumber: visitorInfo.visitorMobileNumber ?? "",
                                            visitorEmailId: visitorInfo.visitorEmailId ?? "",
                                            comments: "Reschedule",
                                            expectedEntryTime: txtEntryDate.text ?? "",
                                            expectedExitTime: txtExitDate.text ?? "",
                                            memberId: GlobalConstants.loggedInMemberDetails.memberId ?? 0,
                                            createdBy: GlobalConstants.loggedInMemberDetails.memberId ?? 0)
            observeEvent()
            viewModel.rescheduleInvitation(details: details, id: String(visitorInfo.visitorId ?? 0))
            
        } else {
            self.view.makeToast("Please enter all fields to continue!", duration: 2.0, position: .center)
        }
        
    }
    
    @objc func doneButtonPressed() {
        if let  datePicker = self.txtEntryDate.inputView as? UIDatePicker {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM-dd-yyyy HH:mm:ss"
            //dateFormatter.dateStyle = .medium
            self.txtEntryDate.text = dateFormatter.string(from: datePicker.date)
        }
        self.txtEntryDate.resignFirstResponder()
     }
    
    @objc func doneButtonPressed2() {
        if let  datePicker = self.txtExitDate.inputView as? UIDatePicker {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM-dd-yyyy HH:mm:ss"
            //dateFormatter.dateStyle = .medium
            self.txtExitDate.text = dateFormatter.string(from: datePicker.date)
        }
        self.txtExitDate.resignFirstResponder()
     }
    
    @objc func handleTap() {
        self.dismiss(animated: true)
    }
}

extension RescheduleInviteVC {
    
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Data Loaded")
            case .error(let error):
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                }
                print(error?.localizedDescription)
                
            case .InvitedVisitorftchedSuccessfully(visitosrDetails: let visitosrDetails):
                print("Invite Visitor")
                
            case .InvitationCanceled(cancelResponse: let cancelResponse):
                print("Invite Visitor")
                
            case .InviteSendSuccessful(response: let response):
                print(response.message)

            case .InviteUnsuccessful(message: let message):
                print(message)
                
            case .RescheduleSuccessful(response: let response):
                
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    self.dismiss(animated: true) {
                        self.Delegate?.refreshScreenAfterReschedule(response: response)
                    }
                }
                
                
            case .RescheduleUnsuccessful(response: let response):
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    self.dismiss(animated: true) {
                        self.Delegate?.refreshScreenAfterReschedule(response: response)
                    }
                }

            case .dataFatchedSuccessfully(response: let response):
                print(response)
            }
        }
    }
    
}
