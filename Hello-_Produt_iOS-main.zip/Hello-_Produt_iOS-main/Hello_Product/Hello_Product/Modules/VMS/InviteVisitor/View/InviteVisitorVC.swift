//
//  InviteVisitorVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 13/11/23.
//

import Foundation
import UIKit

class InviteVisitorVC: UIViewController {
    
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var btnInvite: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    
    let viewModel = InviteVisitorViewModel()
    var visitorDetails = [VisitorDetail]()
    var cancelInviteInnfo = CancelInvite()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        observeEvent()
//        viewModel.fetchVisitor(memberId: String(GlobalConstants.loggedInMemberDetails.memberId ?? 0))
        
        self.navigationController?.navigationBar.isHidden = true
        design()
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "InviteVisitorCell", bundle: nil), forCellReuseIdentifier: "InviteVisitorCell")
        tableView.separatorStyle = .none
        tableView.bounces = false
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        observeEvent()
        viewModel.fetchVisitor(memberId: String(GlobalConstants.loggedInMemberDetails.memberId ?? 0))
    }
    
    func design() {
        
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        btnInvite.layer.cornerRadius = 5
        btnBack.setTitle("", for: .normal)
        lblTitle.text = GlobalConstants.loggedInMemberDetails.siteName

    }
    
    @IBAction func btnInviteTapped(_ sender: UIButton) {
        
        let storyboard = UIStoryboard(name: "VMS", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "SendInvitationVC") as! SendInvitationVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func backTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func convertToFormattedTime(inputDateTimeString: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"

        if let date = dateFormatter.date(from: inputDateTimeString) {
            dateFormatter.dateFormat = "dd MMM hh:mm a"
            let formattedTime = dateFormatter.string(from: date)
            return formattedTime
        } else {
            return "Invalid Date"
        }
    }

    
//    func formatDateString(_ dateString: String) -> String? {
//        let inputFormatter = DateFormatter()
//        inputFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
//        inputFormatter.locale = Locale(identifier: "en_US_POSIX")
//        inputFormatter.timeZone = TimeZone(secondsFromGMT: 0)
//        
//        if let date = inputFormatter.date(from: dateString) {
//            let outputFormatter = DateFormatter()
//            outputFormatter.dateFormat = "d MMM - h:mm a"
//            outputFormatter.locale = Locale(identifier: "en_US_POSIX")
//            outputFormatter.amSymbol = "AM"
//            outputFormatter.pmSymbol = "PM"
//            
//            return outputFormatter.string(from: date)
//        }
//        
//        return nil
//    }
}

extension InviteVisitorVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return visitorDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "InviteVisitorCell") as! InviteVisitorCell
        let data = visitorDetails[indexPath.row]
        cell.nameLbl.text = data.visitorName
        cell.numberLbl.text = data.visitorMobileNumber
        cell.visitingFrom.text = "Visiting From: \(data.visitorLocation ?? "")"
        cell.selectionStyle = .none
        cell.delegate = self
        cell.visitorID = data.visitorId ?? 0
        cell.visitorInfo = data
        
        var startTime: String = data.expectedEntryTime ?? ""
        var endTime: String = data.expectedExitTime ?? ""
        
        startTime = convertToFormattedTime(inputDateTimeString: startTime)
        endTime = convertToFormattedTime(inputDateTimeString: endTime)
        
        cell.lblTime.text = "From \(startTime) To \(endTime)"
        
//        cell.visitorMobileNumber = data.visitorMobileNumber
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 135.0
    }
    
    
}

extension InviteVisitorVC: InviteModificationProtocol {
    func cancelInvitation(visitorID: Int, visitorInfo: VisitorDetail) {
        
        let alertController = UIAlertController(title: "Cancel Invitation", message: "Are you sure you want to cancel the invitation?", preferredStyle: .alert)

        // Action for the "Cancel" button
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
            // Do nothing or any action needed upon cancel button tap
            print("Don't Cancel")
        }

        // Action for the "Yes" button
        let yesAction = UIAlertAction(title: "Yes", style: .destructive) { _ in
            // Code for cancelling the invitation
            // Replace this block with your cancel invitation logic
            
            self.viewModel.cancelInvite(visitorID: visitorID,
                                   comments: "Cancel",
                                        visitorInfo: visitorInfo)
            
            print("Invitation Cancelled")
        }

        // Add both actions to the alert controller
        alertController.addAction(cancelAction)
        alertController.addAction(yesAction)

        // Present the alert
        // 'self' assumes this code is inside a UIViewController subclass
        self.present(alertController, animated: true, completion: nil)

    }
    
    func rescheduleInvitation(visitorInfo: VisitorDetail) {
        
        let storyboard = UIStoryboard(name: "VMS", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "RescheduleInviteVC") as! RescheduleInviteVC
        vc.visitorInfo = visitorInfo
        vc.Delegate = self
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
        
        print("Invitation Rescheduled")
    }
}

extension InviteVisitorVC: RescheduleProtocol {
    func refreshScreenAfterReschedule(response: InviteResponse) {
        
        if response.isSuccess {
            DispatchQueue.main.async {
                self.view.makeToast(response.message)
//                self.view.makeToast("Rescheduled Successfully")
            }
        } else {
            DispatchQueue.main.async {
                self.view.makeToast(response.message)
//                self.view.makeToast("Something went wrong!")
            }
        }
        
        observeEvent()
        viewModel.fetchVisitor(memberId: String(GlobalConstants.loggedInMemberDetails.memberId ?? 0))
        print(response.message)
    }
}

extension InviteVisitorVC {
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Data Loaded")
            case .error(let error):
                self.hideActivityIndicator()
                print(error?.localizedDescription)
                
            case .InvitedVisitorftchedSuccessfully(visitosrDetails: let visitosrDetails):
                self.visitorDetails = visitosrDetails
                self.hideActivityIndicator()
                
                if visitosrDetails.count <= 0 {
                    DispatchQueue.main.async {
                        self.tableView.isHidden = true
                    }
                }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
            case .InvitationCanceled(cancelResponse: let cancelResponse):
                DispatchQueue.main.async {
                    self.view.makeToast(cancelResponse.message)
                    self.viewModel.fetchVisitor(memberId: String(GlobalConstants.loggedInMemberDetails.memberId ?? 0))
                }
                
            case .InviteSendSuccessful(response: let response):
                print(response.message)
                
            case .InviteUnsuccessful(message: let message):
                print(message)
                
            case .RescheduleSuccessful(response: let response):
                print(response)

            case .RescheduleUnsuccessful(response: let response):
                print(response)

            case .dataFatchedSuccessfully(response: let response):
                print(response)
            }
        }
    }
}
