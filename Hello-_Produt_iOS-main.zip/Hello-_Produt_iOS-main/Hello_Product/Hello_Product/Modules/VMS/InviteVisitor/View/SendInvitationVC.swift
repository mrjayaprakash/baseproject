//
//  SendInvitationVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 27/11/23.
//

import Foundation
import UIKit
import Toast_Swift

class SendInvitationVC: UIViewController {
    
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnInvite: UIButton!
    @IBOutlet weak var tlblTitle: UILabel!
    
    @IBOutlet weak var txtMobile: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtEntryTime: UITextField!
    @IBOutlet weak var txtExitTime: UITextField!
    
    
    let viewModel = InviteVisitorViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        design()
        txtMobile.delegate = self
        txtEntryTime.setDatePickerAsInputViewFor(target: self, selector: #selector(self.doneButtonPressed))
        txtExitTime.setDatePickerAsInputViewFor(target: self, selector: #selector(self.doneButtonPressed2))
        
    }
    
    @objc func doneButtonPressed() {
        if let  datePicker = self.txtEntryTime.inputView as? UIDatePicker {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM-dd-yyyy HH:mm:ss"
            self.txtEntryTime.text = dateFormatter.string(from: datePicker.date)
        }
        self.txtEntryTime.resignFirstResponder()
     }
    
    @objc func doneButtonPressed2() {
        if let  datePicker = self.txtExitTime.inputView as? UIDatePicker {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM-dd-yyyy HH:mm:ss"
            self.txtExitTime.text = dateFormatter.string(from: datePicker.date)
        }
        self.txtExitTime.resignFirstResponder()
     }
    
    func design() {
        btnBack.setTitle("", for: .normal)
        
        viewBackground.layer.cornerRadius = 20
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        tlblTitle.text = GlobalConstants.loggedInMemberDetails.siteName
        
        btnInvite.layer.cornerRadius = 15
    }
    
    @IBAction func btnInviteTapped(_ sender: UIButton) {
        
        
        if txtMobile.text?.count != 0 && txtName.text?.count != 0 && txtemail.text?.count != 0 && txtAddress.text?.count != 0 && txtEntryTime.text?.count != 0 && txtExitTime.text?.count != 0 {
            
            if isValidIndianMobileNumber(txtMobile.text ?? "") {
                if isValidEmail(txtemail.text ?? "") {
                    
                    if isValidName(txtName.text ?? "") {
                        let dateFormatter = DateFormatter()
                        dateFormatter.locale = Locale(identifier: "en_US_POSIX") // set locale to reliable US_POSIX
                        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm:ss"
                        let entryDate = dateFormatter.date(from:txtEntryTime.text ?? "")!
                        let exitDate = dateFormatter.date(from:txtExitTime.text ?? "")!
                        
                        if entryDate >= exitDate {
                            DispatchQueue.main.async {
                                let alert = UIAlertController(title: "Alert", message: "Exit date needs to be greater than Entry date !", preferredStyle: .alert)
                                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                                    switch action.style{
                                    case .default:
                                        print("default")
                                    case .cancel:
                                        print("cancel")
                                    case .destructive:
                                        print("destructive")
                                    }
                                }))
                                self.present(alert, animated: true)
                            }
                            return
                        }
                        
                        let detail = SendInvitationDetail(siteId: GlobalConstants.loggedInMemberDetails.siteId ?? 0,
                                                          unitId: GlobalConstants.loggedInMemberDetails.unitId ?? 0,
                                                          visitorName: txtName.text ?? "",
                                                          visitorLocation: txtAddress.text ?? "",
                                                          visitorMobileNumber: txtMobile.text ?? "",
                                                          visitorEmailId: txtemail.text ?? "",
                                                          expectedEntryTime: txtEntryTime.text ?? "",
                                                          expectedExitTime: txtExitTime.text ?? "",
                                                          comments: "Hello Welcome!",
                                                          memberName: GlobalConstants.loggedInMemberDetails.memberName ?? "",
                                                          memberId: GlobalConstants.loggedInMemberDetails.memberId ?? 0,
                                                          createdBy: String(GlobalConstants.loggedInMemberDetails.memberId ?? 0))
                        observeEvent()
                        viewModel.sendInvitation(details: detail)
                    } else {
                        DispatchQueue.main.async {
                            self.view.makeToast("Please enter valid Name")
                            return
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        self.view.makeToast("Please enter valid email id")
                        return
                    }
                }

            } else {
                DispatchQueue.main.async {
                    self.view.makeToast("Please enter valid Mobile number")
                    return
                }
            }
            
        } else {
            self.view.makeToast("Please fill all the fields")
        }
    }
    @IBAction func btnBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func convertToFormattedTime(inputDateTimeString: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"

        if let date = dateFormatter.date(from: inputDateTimeString) {
            dateFormatter.dateFormat = "dd MMM hh:mm a"
            let formattedTime = dateFormatter.string(from: date)
            return formattedTime
        } else {
            return "Invalid Date"
        }
    }
}

extension SendInvitationVC: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == self.txtMobile {
            let maxLength = 10
            let currentString = (textField.text ?? "") as NSString
            let newString = currentString.replacingCharacters(in: range, with: string)
            
            if newString.count == 10 {
                let numberText = txtMobile.text!
                let number = "\(numberText)\(string)"
                
                observeEvent()
                viewModel.populateDataIfAvailable(mobileNo: number)
                
//                populateProfileDetailsFromServer(mobileNumber: number)
                return true
            }
            return newString.count <= maxLength
        }
        return true
    }
}

extension SendInvitationVC {
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Data Loaded")
            case .error(let error):
                print(error?.localizedDescription)
                
            case .InvitedVisitorftchedSuccessfully(visitosrDetails: let visitosrDetails):
                print(visitosrDetails)
                
            case .InvitationCanceled(cancelResponse: let cancelResponse):
                print(cancelResponse)
                
                
            case .InviteSendSuccessful(response: let response):
                
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    
                    if response.message != "" {
                        self.view.makeToast(response.message)
                        
                        self.txtemail.text = ""
                        self.txtName.text = ""
                        self.txtMobile.text = ""
                        self.txtAddress.text = ""
                        self.txtEntryTime.text = ""
                        self.txtExitTime.text = ""
                    } else {
                        
                        if response.data?.count ?? 0 <= 0 {
                            self.view.makeToast("Already invited in this time slot")
                        } else {
                            // Create an empty string for entry and exit times
                            var entryExitTimes = ""

                            if let data = response.data {
                                // Loop through the data and append entry and exit times to the string

                                for entry in data {
                                    let entryTime = self.convertToFormattedTime(inputDateTimeString: entry.expectedEntryTime ?? "")
                                    let exitTime = self.convertToFormattedTime(inputDateTimeString: entry.expectedExitTime ?? "")
                                    
                                    entryExitTimes += "\(entryTime) - \(exitTime)\n"
                                    
                                }
                                
                                let message = "\n This Visitor is Already invited between \n\n \(entryExitTimes)"
                                
                                let alert  = UIAlertController(title: "Already Invited", message: message, preferredStyle: .alert)
                                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in
                                    self.dismiss(animated: true)
                                    }))
                                self.present(alert, animated: true, completion: nil)

                            }
                        }
                    }
                }
            case .InviteUnsuccessful(message: let message):
                
                print(message)
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    self.view.makeToast(message)
                }
            case .RescheduleSuccessful(response: let response):
                print(response)

            case .RescheduleUnsuccessful(response: let response):
                print(response)

            case .dataFatchedSuccessfully(response: let response):
                
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                }
                
                if response.data?.count ?? 0 >= 1 {
                    let data = response.data?[0]
                    
                    DispatchQueue.main.async {
                        self.txtName.text = data?.visitorName
                        self.txtemail.text = data?.emailId
                    }
                    
                } else {
                    print("Something Went Wrong")
                }
            }
        }
    }
}
