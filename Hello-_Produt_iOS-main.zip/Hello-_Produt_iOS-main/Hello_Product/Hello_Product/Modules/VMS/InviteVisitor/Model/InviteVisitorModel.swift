//
//  InviteVisitorModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 27/11/23.
//

import Foundation

//struct VisitorData: Codable {
//    var isSuccess: Bool?
//    var message: String?
//    var data: [VisitorDetail]?
//}

struct VisitorData: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [VisitorDetail]?

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        isSuccess = try container.decodeIfPresent(Bool.self, forKey: .isSuccess)
        message = try container.decodeIfPresent(String.self, forKey: .message)
        
        // Handle 'data' decoding
        data = try container.decodeIfPresent([VisitorDetail].self, forKey: .data)
    }
}

struct InvitedVisitorData: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [InvitedVisitorDetail]?
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        isSuccess = try container.decodeIfPresent(Bool.self, forKey: .isSuccess)
        message = try container.decodeIfPresent(String.self, forKey: .message)
        
        // Handle 'data' decoding
        data = try container.decodeIfPresent([InvitedVisitorDetail].self, forKey: .data)
    }
}



struct VisitorDetail: Codable {
    var visitorId: Int?
    var siteId: Int?
    var unitId: Int?
    var visitorName: String?
    var visitorLocation: String?
    var visitorMobileNumber: String?
    var visitorEmailId: String?
    var qrNumber: String?
    var expectedEntryTime: String?
    var expectedExitTime: String?
}

struct InvitedVisitorDetail: Codable {
   
    var visitorName: String?
    var emailId: String
}



struct CancelInvite: Codable {
    var comments: String?
    var visitorId: Int?
    var memberId: Int?
    var visitorEmailId: String?
    
    init(comments: String, visitorId: Int, memberId: Int, visitorEmailId: String) {
        self.comments = comments
        self.visitorId = visitorId
        self.memberId = memberId
        self.visitorEmailId = visitorEmailId
    }
    
    init() {}
}

struct InviteResponse: Codable {
    var isSuccess: Bool
    var message: String?
}

struct SendInvitationDetail: Codable {
    var siteId: Int?
    var unitId: Int?
    var visitorName: String?
    var visitorLocation: String?
    var visitorMobileNumber: String?
    var visitorEmailId: String?
    var expectedEntryTime: String?
    var expectedExitTime: String?
    var comments: String?
    var memberName: String?
    var memberId: Int?
    var createdBy: String?
    
    init(siteId: Int, unitId: Int, visitorName: String, visitorLocation: String, visitorMobileNumber: String, visitorEmailId: String, expectedEntryTime: String, expectedExitTime: String, comments: String, memberName: String, memberId: Int, createdBy: String) {
        self.siteId = siteId
        self.unitId = unitId
        self.visitorName = visitorName
        self.visitorLocation = visitorLocation
        self.visitorMobileNumber = visitorMobileNumber
        self.visitorEmailId = visitorEmailId
        self.expectedEntryTime = expectedEntryTime
        self.expectedExitTime = expectedExitTime
        self.comments = comments
        self.memberName = memberName
        self.memberId = memberId
        self.createdBy = createdBy
    }
    
    init () {}
}


struct RescheduleDetails: Codable {
    
    var visitorId: Int?
    var visitorName: String?
    var visitorMobileNumber: String?
    var visitorEmailId: String?
    var comments: String?
    var expectedEntryTime: String?
    var expectedExitTime: String?
    var memberId: Int?
    var createdBy: Int?
    
    init(visitorId: Int, visitorName: String, visitorMobileNumber: String, visitorEmailId: String, comments: String, expectedEntryTime: String, expectedExitTime: String, memberId: Int, createdBy: Int) {
        self.visitorId = visitorId
        self.visitorName = visitorName
        self.visitorMobileNumber = visitorMobileNumber
        self.visitorEmailId = visitorEmailId
        self.comments = comments
        self.expectedEntryTime = expectedEntryTime
        self.expectedExitTime = expectedExitTime
        self.memberId = memberId
        self.createdBy = createdBy
    }
    
    init () {}
}

//"visitorId": "<integer>",
//  "siteId": "<integer>",
//  "unitId": "<integer>",
//  "visitorName": "<string>",
//  "visitorLocation": "<string>",
//  "visitorMobileNumber": "<string>",
//  "visitorEmailId": "<string>",
//  "image": "<string>",
//  "qrNumber": "<string>",
//  "expectedEntryTime": "<dateTime>",
//  "expectedExitTime": "<dateTime>",
//  "comments": "<string>",
//  "memberName": "<string>",
//  "memberId": "<integer>",
//  "createdBy": "<string>"


//struct postInviteVisttorResponse: Codable {
//    var isSuccess: Bool?
//    var message: String?
//    var dataArray: [postInviteDataResponse]?
//}

struct postInviteVisttorResponse: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [postInviteDataResponse]?

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        isSuccess = try container.decodeIfPresent(Bool.self, forKey: .isSuccess)
        message = try container.decodeIfPresent(String.self, forKey: .message)
        
        // Handle 'dataArray' decoding
        if let dataResponseArray = try? container.decodeIfPresent([postInviteDataResponse].self, forKey: .data) {
            data = dataResponseArray ?? [] // If 'dataResponseArray' is nil, assign an empty array
        } else {
            data = [] // Set default value if decoding fails
        }
    }
}


class postInviteDataResponse: Codable {
    var expectedEntryTime: String?
    var expectedExitTime: String?
    
    init(expectedEntryTime: String, expectedExitTime: String) {
        self.expectedEntryTime = expectedEntryTime
        self.expectedExitTime = expectedExitTime
    }
    
    init() {}
}
