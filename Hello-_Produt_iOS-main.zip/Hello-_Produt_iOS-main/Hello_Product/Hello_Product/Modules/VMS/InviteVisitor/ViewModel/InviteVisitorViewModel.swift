//
//  InviteVisitorViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 24/11/23.
//

import Foundation
import UIKit

protocol InviteVisitorViewModelProtocol {
    func fetchVisitor(memberId: String)
}

class InviteVisitorViewModel: InviteVisitorViewModelProtocol {
    func fetchVisitor(memberId: String) {
        self.eventHandler?(.loading)
        
        ApiManager.shared.request(
            modelType: VisitorData.self,
            type: ManageUsersEndPoint.getAllInvitedVisitor(memberId: memberId)) { result in
                switch result {
                    
                case .success(let visitorData):
                    let visitorData = visitorData
                    self.eventHandler?(.InvitedVisitorftchedSuccessfully(visitosrDetails: visitorData.data ?? []))
                    
                case .failure(let error):
                    self.eventHandler?(.error(error))
                    
                }
            }
    }
    
    var eventHandler: ((_ event: Event) -> Void)?


    
    func cancelInvite(visitorID: Int, comments: String, visitorInfo: VisitorDetail) {
        
        let cancelDetail = CancelInvite(comments: "Cancel",
                                        visitorId: visitorInfo.visitorId ?? 0,
                                        memberId: GlobalConstants.loggedInMemberDetails.memberId ?? 0,
                                        visitorEmailId: visitorInfo.visitorEmailId ?? "")
        
        ApiManager.shared.request(
            modelType: InviteResponse.self,
            type: ManageUsersEndPoint.cancelInvite(visitorId: String(visitorID),
            cancelDetails: cancelDetail)) { result in
                switch result {
                                                           
                    case .success(let data):
                        self.eventHandler?(.InvitationCanceled(cancelResponse: data))
                    case .failure(let error):
                        self.eventHandler?(.error(error))
                }
            }
    }
    
    func sendInvitation(details: SendInvitationDetail) {
        self.eventHandler?(.loading)
        ApiManager.shared.request(modelType: postInviteVisttorResponse.self,
                                  type: ManageUsersEndPoint.sendInvite(details: details)) { result in
            switch result {
                
            case .success(let response):
                if response.isSuccess ?? false {
                    self.eventHandler?(.InviteSendSuccessful(response: response))
                } else {
                    self.eventHandler?(.InviteUnsuccessful(message: response.message ?? ""))
                }
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
    }
    
    func rescheduleInvitation(details: RescheduleDetails, id: String) {
        
        self.eventHandler?(.loading)
        ApiManager.shared.request(modelType: InviteResponse.self,
                                  type: ManageUsersEndPoint.rescheduleInvite(details: details, id: id)) { result in
            switch result {
                
            case .success(let response):
                if response.isSuccess {
                    self.eventHandler?(.RescheduleSuccessful(response: response))
                } else {
                    self.eventHandler?(.RescheduleUnsuccessful(response: response))
                }
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
    }
    
    func populateDataIfAvailable(mobileNo: String) {
        self.eventHandler?(.loading)
        
        ApiManager.shared.request(modelType: InvitedVisitorData.self,
                                  type: ManageUsersEndPoint.fetchVisitorByMobile(mobileNo: mobileNo))
        { result in
            switch result {
                
            case .success(let response):
                self.eventHandler?(.dataFatchedSuccessfully(response: response))
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
        
    }
    
}

extension InviteVisitorViewModel {
    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case InvitedVisitorftchedSuccessfully(visitosrDetails: [VisitorDetail])
        case InvitationCanceled(cancelResponse: InviteResponse)
        case InviteSendSuccessful(response: postInviteVisttorResponse)
        case InviteUnsuccessful(message: String)
        case RescheduleSuccessful(response: InviteResponse)
        case RescheduleUnsuccessful(response: InviteResponse)
        case dataFatchedSuccessfully(response: InvitedVisitorData)
    }
}
