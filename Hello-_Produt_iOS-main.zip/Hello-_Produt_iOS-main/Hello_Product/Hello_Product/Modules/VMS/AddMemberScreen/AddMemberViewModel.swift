//
//  AddMemberViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 21/11/23.
//

import Foundation

class AddMemberViewModel {
    
    var eventHandler: ((_ event: Event) -> Void)?
    
    func callAddMember(addMemberDetails: AddMemberDetail) {
        self.eventHandler?(.loading)
        var multipart = MultipartRequest()
        
        let siteId = addMemberDetails.siteId ?? 0
        let memberName = addMemberDetails.memberName ?? ""
        let mobileNumber = addMemberDetails.mobileNumber ?? ""
        let email = addMemberDetails.email ?? ""
        let address = addMemberDetails.address ?? ""
        let genderId = addMemberDetails.genderId ?? 0
        let roleId = addMemberDetails.roleId ?? 0
        let unitId = addMemberDetails.unitId ?? 0
        let createdBy = addMemberDetails.createdBy ?? ""
        let techId = UserDefaults.standard.string(forKey: Constants.techId)
        let techIdInt = Int(techId ?? "")
        let rfidId = addMemberDetails.rfidId
        

        for field in [
            "siteId": siteId,
            "memberName": memberName,
            "mobileNumber": mobileNumber,
            "email": email,
            "address": address,
            "statusId": 1,
            "genderId": genderId,
            "roleId": roleId,
            "unitId": unitId,
            "employeeTechAccessId": techIdInt ?? 0,
            "createdBy": createdBy,
            "isActiveId": 1,
            "rfidId": rfidId ?? 0
        ] as [String : Any] {
            multipart.add(key: field.key, value: "\(field.value)")
        }
        
        
        if let data = addMemberDetails.image?.pngData() {
            multipart.add(
                key: "image",
                fileName: "visitorpic.png",
                fileMimeType: "image/png",
                fileData: data
            )
        } else {
            print("No Image Found")
        }

        var success_param:Bool = false
        
        /// Create a regular HTTP URL request & use multipart components
        let url = URL(string: "https://helloproduct.azurewebsites.net/api/ManageUsers/postUsers")!
//        let url = URL(string: "http://192.168.1.17:5000/api/ManageUsers/postUsers")!

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue(multipart.httpContentTypeHeaderValue, forHTTPHeaderField: "Content-Type")
        request.httpBody = multipart.httpBody

        let session = URLSession(configuration: .default)
        session.dataTask(with: request) { (data, response, error) in
            if error != nil {
                
            } else {
                
                //Data received.
                guard let data = data,
                        let response = response as? HTTPURLResponse,
                        error == nil
                    else {
                        print("error", error ?? URLError(.badServerResponse))
                        return
                    }

                if response.statusCode == 200 {
                    print("HTTP Success")
                } else {
                    print("HTTP Error code = \(response.statusCode)")
                    if response.statusCode == 401 {
                       // self.logoutDueToTimeout()
                    }
                }

                if let json = try? JSONSerialization.jsonObject(with: data) as? [String:Any] {
//                    print("Data received = \(json)")
                    let isSuccess = json["isSuccess"] as? Bool ?? false
                    let message = json["message"] as? String ?? ""
                    
                    if isSuccess {
                        self.eventHandler?(.memberAddedSuccessfully(message: message))
                    } else {
                        self.eventHandler?(.memberNotAddedSuccessfully(message: message))
                    }
                    success_param = isSuccess
                } else {
                    print(data)
                }
            }
        }.resume()
    }
}

extension AddMemberViewModel {
    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case memberAddedSuccessfully(message: String)
        case memberNotAddedSuccessfully(message: String)

    }
}
