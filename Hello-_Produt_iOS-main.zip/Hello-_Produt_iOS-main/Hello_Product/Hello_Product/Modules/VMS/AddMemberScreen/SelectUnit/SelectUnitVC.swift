//
//  SelectUnitVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 15/01/24.
//

import Foundation
import UIKit

class SelectUnitVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
    }
}

extension SelectUnitVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SelectUnitCell", for: indexPath) as! SelectUnitCell
        
        return cell
    }
    
    
}



