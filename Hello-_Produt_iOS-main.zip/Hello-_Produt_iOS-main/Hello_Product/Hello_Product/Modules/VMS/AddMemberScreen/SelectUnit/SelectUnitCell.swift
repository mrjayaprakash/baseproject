//
//  SelectUnitCell.swift
//  Hello_Product
//
//  Created by Zentech-038 on 15/01/24.
//

import UIKit

class SelectUnitCell: UITableViewCell {

    @IBOutlet weak var viewOuter: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        viewOuter.applyCardEffect()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
