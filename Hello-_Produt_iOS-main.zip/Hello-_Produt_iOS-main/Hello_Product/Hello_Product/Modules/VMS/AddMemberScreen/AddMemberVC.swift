//
//  AddMemberVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 21/11/23.
//

import Foundation
import UIKit
import DropDown
import Toast_Swift
import MBProgressHUD
import AVFoundation
import Photos

class AddMemberVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var btnImagePicker: UIButton!
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var viewBackground: UIView!
    
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtMobile: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var lblGender: UILabel!
    @IBOutlet weak var imgDropGender: UIImageView!
    @IBOutlet weak var btnDropGender: UIButton!
    @IBOutlet weak var viewGender: UIView!
    
    @IBOutlet weak var lblUnit: UILabel!
    @IBOutlet weak var imgDropUnit: UIImageView!
    @IBOutlet weak var btnDropUnit: UIButton!
    @IBOutlet weak var viewUnit: UIView!
    
    @IBOutlet weak var lblRole: UILabel!
    @IBOutlet weak var imgDropRole: UIImageView!
    @IBOutlet weak var btnDropRole: UIButton!
    @IBOutlet weak var viewRole: UIView!
    
    @IBOutlet weak var lblSite: UILabel!
    @IBOutlet weak var imgDropSite: UIImageView!
    @IBOutlet weak var btnDropSite: UIButton!
    @IBOutlet weak var viewSite: UIView!
    
    @IBOutlet weak var rfidContainerView: UIView!
    @IBOutlet weak var lblRFID: UILabel!
    @IBOutlet weak var btnDropRFID: UIButton!
    @IBOutlet weak var imgDropRFID: UIImageView!
    @IBOutlet weak var viewRFID: UIView!
    
    
    let viewModel = AddMemberViewModel()
    let vmsViewModel = VMSViewModel()
    
    let dropDownGender = DropDown()
    var dropdownGenderTypes: [Gender] = []
    var genderNames: [String] = []
    
    
    let dropDownRole = DropDown()
    var dropdownRoleTypes: [RoleDetail] = []
    var roleNames: [String] = []
    
    let dropDownUnit = DropDown()
    var dropdownUnitTypes: [UnitDetail] = []
    var unitNames: [String] = []
    
    let dropdownSite = DropDown()
    var dropdownSiteTypes: [SiteDetail] = []
    var siteNames: [String] = []
    
    let dropDownRFID = DropDown()
    var dropdownRFIDTypes: [RFIDsDetail] = []
    var RFIDNames: [String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        design()
        integrateDropDown()
        
        vmsViewModel.getAllRole()
        vmsViewModel.getAllsites()
        vmsViewModel.getAllUnits()
        vmsViewModel.getAllRFIDs()
        
        observeEvent()
        
    }
    
    func integrateDropDown() {
        
        // Gender DropDown Integration
        
        self.dropdownGenderTypes = GlobalConstants.genderConstants
        
        for gender in self.dropdownGenderTypes {
            self.genderNames.append(gender.name )
        }
        self.dropDownGender.dataSource = self.genderNames
        
        self.btnDropGender.setTitle("", for: .normal)
        self.btnDropGender.backgroundColor = UIColor.clear
        self.dropDownGender.anchorView = self.btnDropGender
        self.dropDownGender.bottomOffset = CGPoint(x: 0, y:(self.dropDownGender.anchorView?.plainView.bounds.height)!)
        self.dropDownGender.direction = .bottom
        self.dropDownGender.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.lblGender.text = self.genderNames[index]
            UIView.animate(withDuration: 0.5) {
                self.imgDropGender.transform = CGAffineTransform.identity
            }
        }
        self.dropDownGender.cancelAction = { [unowned self] in
            print("Drop down dismissed")
            UIView.animate(withDuration: 0.5) {
                self.imgDropGender.transform = CGAffineTransform.identity
            }
        }
        self.dropDownGender.willShowAction = { [unowned self] in
            print("Drop down will show")
            UIView.animate(withDuration: 0.5) {
                self.imgDropGender.transform = CGAffineTransform(rotationAngle: .pi)
            }
        }
        
        
        
        // Unit DropDown Integration
        self.btnDropUnit.setTitle("", for: .normal)
        self.btnDropUnit.backgroundColor = UIColor.clear
        self.dropDownUnit.anchorView = self.btnDropUnit
        self.dropDownUnit.bottomOffset = CGPoint(x: 0, y:(self.dropDownUnit.anchorView?.plainView.bounds.height)!)
        self.dropDownUnit.direction = .bottom
        self.dropDownUnit.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.lblUnit.text = self.unitNames[index]
            UIView.animate(withDuration: 0.5) {
                self.imgDropUnit.transform = CGAffineTransform.identity
            }
        }
        self.dropDownUnit.cancelAction = { [unowned self] in
            print("Drop down dismissed")
            UIView.animate(withDuration: 0.5) {
                self.imgDropUnit.transform = CGAffineTransform.identity
            }
        }
        self.dropDownUnit.willShowAction = { [unowned self] in
            print("Drop down will show")
            UIView.animate(withDuration: 0.5) {
                self.imgDropUnit.transform = CGAffineTransform(rotationAngle: .pi)
            }
        }
        
        
        // Role DropDown Integration
        self.btnDropRole.setTitle("", for: .normal)
        self.btnDropRole.backgroundColor = UIColor.clear
        self.dropDownRole.anchorView = self.btnDropRole
        self.dropDownRole.bottomOffset = CGPoint(x: 0, y:(self.dropDownRole.anchorView?.plainView.bounds.height)!)
        self.dropDownRole.direction = .bottom
        self.dropDownRole.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.lblRole.text = self.roleNames[index]
            UIView.animate(withDuration: 0.5) {
                self.imgDropRole.transform = CGAffineTransform.identity
            }
        }
        self.dropDownRole.cancelAction = { [unowned self] in
            print("Drop down dismissed")
            UIView.animate(withDuration: 0.5) {
                self.imgDropRole.transform = CGAffineTransform.identity
            }
        }
        self.dropDownRole.willShowAction = { [unowned self] in
            print("Drop down will show")
            UIView.animate(withDuration: 0.5) {
                self.imgDropRole.transform = CGAffineTransform(rotationAngle: .pi)
            }
        }
        
        // Role DropDown Integration
        self.btnDropSite.setTitle("", for: .normal)
        self.btnDropSite.backgroundColor = UIColor.clear
        self.dropdownSite.anchorView = self.btnDropSite
        self.dropdownSite.bottomOffset = CGPoint(x: 0, y:(self.dropdownSite.anchorView?.plainView.bounds.height)!)
        self.dropdownSite.direction = .bottom
        self.dropdownSite.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.lblSite.text = self.siteNames[index]
            UIView.animate(withDuration: 0.5) {
                self.imgDropSite.transform = CGAffineTransform.identity
            }
        }
        self.dropdownSite.cancelAction = { [unowned self] in
            print("Drop down dismissed")
            UIView.animate(withDuration: 0.5) {
                self.imgDropSite.transform = CGAffineTransform.identity
            }
        }
        self.dropdownSite.willShowAction = { [unowned self] in
            print("Drop down will show")
            UIView.animate(withDuration: 0.5) {
                self.imgDropSite.transform = CGAffineTransform(rotationAngle: .pi)
            }
        }
        
        // RFID DropDown Integration
        self.btnDropRFID.setTitle("", for: .normal)
        self.btnDropRFID.backgroundColor = UIColor.clear
        self.dropDownRFID.anchorView = self.btnDropRFID
        self.dropDownRFID.bottomOffset = CGPoint(x: 0, y:(self.dropDownRFID.anchorView?.plainView.bounds.height)!)
        self.dropDownRFID.direction = .bottom
        self.dropDownRFID.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.lblRFID.text = self.RFIDNames[index]
            UIView.animate(withDuration: 0.5) {
                self.imgDropRFID.transform = CGAffineTransform.identity
            }
        }
        self.dropDownRFID.cancelAction = { [unowned self] in
            print("Drop down dismissed")
            UIView.animate(withDuration: 0.5) {
                self.imgDropRFID.transform = CGAffineTransform.identity
            }
        }
        self.dropDownRFID.willShowAction = { [unowned self] in
            print("Drop down will show")
            UIView.animate(withDuration: 0.5) {
                self.imgDropRFID.transform = CGAffineTransform(rotationAngle: .pi)
            }
        }
    }
    
    
    func sendCreateUserData() {
        
        let profileImage = (imgProfile.image)
        let createdBy = GlobalConstants.loggedInMemberDetails.memberId
        
        var genderID = 0
        let gender = lblGender.text
        
        for gen in dropdownGenderTypes {
            if gender == gen.name {
                genderID = gen.id
            }
        }
        
        var roleID = 0
        let role = lblRole.text
        
        for rol in dropdownRoleTypes {
            if role == rol.roleName {
                roleID = rol.roleId ?? 0
            }
        }
        
        var siteId = 0
        let site = lblSite.text
        
        for sit in dropdownSiteTypes {
            if site == sit.siteName {
                siteId = sit.id
            }
        }
        
        var unitId = 0
        let unit = lblUnit.text ?? ""
        var unitNumber = ""
        
        for char in unit {
            // Check if the character is a digit
            if char.isNumber {
                // Append the digit to the numeric part
                unitNumber.append(char)
            } else {
                // Break the loop when a non-digit character is encountered
                break
            }
        }
        
        for uni in dropdownUnitTypes {
            
            if unitNumber == uni.unitNumberName {
                unitId = uni.id
            }
        }
        
        
        var rfidId = 0
        let rfidNumber = lblRFID.text
        
        for rfid in dropdownRFIDTypes {
            if rfidNumber == String(rfid.rfidNumber) {
                rfidId = rfid.id
            }
        }
        
        let newMemberDetail = AddMemberDetail(siteId: GlobalConstants.loggedInMemberDetails.siteId ?? 0,
                                              memberName: txtName.text ?? "",
                                              mobileNumber: txtMobile.text ?? "",
                                              email: txtEmail.text ?? "",
                                              address: txtAddress.text ?? "",
                                              genderId: genderID,
                                              roleId: roleID,
                                              unitId: unitId,
                                              createdBy: String(GlobalConstants.loggedInMemberDetails.memberId ?? 0),
                                              image: (profileImage ?? UIImage(named: "CircleProfileImage"))!,
                                              rfidId: rfidId)
        
        viewModel.callAddMember(addMemberDetails: newMemberDetail)
        
    }
    
    @IBAction func backTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func addTapped(_ sender: UIButton) {
        if txtName.text != "" && txtMobile.text != "" && txtEmail.text != "" && txtAddress.text != "" && lblSite.text != "Select Site" && lblGender.text != "Select Gender" && lblUnit.text != "Select Unit" && lblRole.text != "Select Role" {
            
            let techId = UserDefaults.standard.string(forKey: Constants.techId)

            if techId == "5" {
                if lblRFID.text == "Select RFID No." {
                    self.hideActivityIndicator()
                    self.view.makeToast("Please Select RFID Number.")
                    return
                }
            }
            
            if !isValidIndianMobileNumber(txtMobile.text ?? "") {
                self.hideActivityIndicator()
                self.view.makeToast("Please enter valid Mobile number")
                return
            }
            
            if !isValidEmail(txtEmail.text ?? "") {
                self.hideActivityIndicator()
                self.view.makeToast("Please enter valid email id")
                return
            }
            
            if !isValidName(txtName.text ?? "") {
                self.hideActivityIndicator()
                self.view.makeToast("Please enter valid Name")
                return
            }
            
            sendCreateUserData()
            
        }
    }
    @IBAction func btnImagePickerTapped(_ sender: UIButton) {
        showImagePickerOptions()
    }
    
    func design() {
        
        btnAdd.layer.cornerRadius = 15
        
        btnBack.setTitle("", for: .normal)
        btnImagePicker.setTitle("", for: .normal)
        
        imgProfile.layer.borderWidth = 3
        imgProfile.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        imgProfile.layer.cornerRadius = 20
        
        btnImagePicker.layer.cornerRadius = 5
        
        viewGender.layer.borderWidth = 0.5
        viewGender.layer.borderColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        viewGender.layer.cornerRadius = 5
        
        viewRole.layer.borderWidth = 0.5
        viewRole.layer.borderColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        viewRole.layer.cornerRadius = 5
        
        viewSite.layer.borderWidth = 0.5
        viewSite.layer.borderColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        viewSite.layer.cornerRadius = 5
        
        viewUnit.layer.borderWidth = 0.5
        viewUnit.layer.borderColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        viewUnit.layer.cornerRadius = 5
        
        viewRFID.layer.borderWidth = 0.5
        viewRFID.layer.borderColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        viewRFID.layer.cornerRadius = 5
        
        
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
            
        let techId = UserDefaults.standard.string(forKey: Constants.techId)
        
        if techId != "5" {
            rfidContainerView.isHidden = true
        } else {
            rfidContainerView.isHidden = false
        }

        
    }
    
    @IBAction func btnDropGenderTapped(_ sender: UIButton) {
        dropDownGender.show()
    }
    @IBAction func btnDropUnittapped(_ sender: UIButton) {
        dropDownUnit.show()
    }
    @IBAction func btnDropRoleTapped(_ sender: UIButton) {
        dropDownRole.show()
    }
    @IBAction func btnDropSiteTapped(_ sender: UIButton) {
        dropdownSite.show()
    }
    @IBAction func btnDropRFIDTapped(_ sender: UIButton) {
        dropDownRFID.show()
    }
    
    
    
    func getRoleDataSource(roles: [RoleDetail]) -> [RoleDetail] {
        
        var array = [RoleDetail]()
        if GlobalConstants.loggedInMemberDetails.roleName == "Super Admin" {
        
            for rol in roles {
                if rol.roleName == "Site Admin"{
                    array.append(rol)
                }
            }
        } else if GlobalConstants.loggedInMemberDetails.roleName == "Site Admin" {
            for rol in roles {
                if rol.roleName == "Unit Admin" {
                    array.append(rol)
                }
            }
        } else if GlobalConstants.loggedInMemberDetails.roleName == "Unit Admin" {
            for rol in roles {
                if rol.roleName == "Employee" {
                    array.append(rol)
                }
            }
        } else {
            
        }
        
        return array
    }
    
    func getSiteDataSource(sites: [SiteDetail]) -> [SiteDetail] {
        var array = [SiteDetail]()
        
        if GlobalConstants.loggedInMemberDetails.roleName == "Super Admin" {
            for sit in sites {
                if sit.clientId == GlobalConstants.loggedInMemberDetails.clientId {
                    array.append(sit)
                }
            }
        } else  {
//            GlobalConstants.loggedInMemberDetails.roleName == "Site Admin"
            for sit in sites {
                if sit.id == GlobalConstants.loggedInMemberDetails.siteId {
                    array.append(sit)
                }
            }
        }
        
        return array
    }
    
    
    func getUnitDataSource(units: [UnitDetail]) -> [UnitDetail] {
        
        var array = [UnitDetail]()
        if GlobalConstants.loggedInMemberDetails.roleName == "Super Admin" {
            for uni in units {
                if uni.clientId == GlobalConstants.loggedInMemberDetails.clientId {
                    array.append(uni)
                }
            }
            
        } else if GlobalConstants.loggedInMemberDetails.roleName == "Site Admin" {
            for uni in units {
                if uni.siteId == GlobalConstants.loggedInMemberDetails.siteId {
                    array.append(uni)
                }
            }
        } else if GlobalConstants.loggedInMemberDetails.roleName == "Unit Admin" {
            for uni in units {
                if uni.id == GlobalConstants.loggedInMemberDetails.unitId {
                    array.append(uni)
                }
            }
        }
        
        return array
    }
    
    func getRFIDsDataSource(RFIDs: [RFIDsDetail]) -> [RFIDsDetail] {
        var array = [RFIDsDetail]()
        
        if GlobalConstants.loggedInMemberDetails.roleName == "Super Admin" {
            for rfid in RFIDs {
                if GlobalConstants.loggedInMemberDetails.clientId == rfid.clientId {
                    array.append(rfid)
                }
            }
            
        } else if GlobalConstants.loggedInMemberDetails.roleName == "Site Admin" {
            for rfid in RFIDs {
                if GlobalConstants.loggedInMemberDetails.clientId == rfid.clientId {
                    if GlobalConstants.loggedInMemberDetails.siteId == rfid.siteId {
                        array.append(rfid)
                    }
                }
            }
        } else if GlobalConstants.loggedInMemberDetails.roleName == "Unit Admin" {
            for rfid in RFIDs {
                if GlobalConstants.loggedInMemberDetails.clientId == rfid.clientId {
                    if GlobalConstants.loggedInMemberDetails.siteId == rfid.siteId {
                        if GlobalConstants.loggedInMemberDetails.unitId == rfid.unitId {
                            array.append(rfid)
                        }
                    }
                }
            }
        }
        
        return array
    }
    
    
    // Function to present options for selecting/capturing an image
//    func showImagePickerOptions() {
//        let picker = UIImagePickerController()
//        picker.delegate = self
//            
//        let alertController = UIAlertController(title: "Select Image", message: nil, preferredStyle: .actionSheet)
//            
//        let pickFromGalleryAction = UIAlertAction(title: "Pick from Gallery", style: .default) { _ in
//            self.checkPhotoLibraryPermission()
//        }
//            
//        let clickImageAction = UIAlertAction(title: "Click Image", style: .default) { _ in
//            self.checkCameraPermission()
//        }
//            
//        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
//            
//        alertController.addAction(pickFromGalleryAction)
//        alertController.addAction(clickImageAction)
//        alertController.addAction(cancelAction)
//            
//        // Present the options
//        self.present(alertController, animated: true, completion: nil)
//    }
    
    func showImagePickerOptions() {
        let picker = UIImagePickerController()
        picker.delegate = self
        
        let alertController = UIAlertController(title: "Select Image", message: nil, preferredStyle: .actionSheet)
        
        let pickFromGalleryAction = UIAlertAction(title: "Pick from Gallery", style: .default) { _ in
            self.checkPhotoLibraryPermission()
        }
        
        let clickImageAction = UIAlertAction(title: "Click Image", style: .default) { _ in
            self.checkCameraPermission()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertController.addAction(pickFromGalleryAction)
        alertController.addAction(clickImageAction)
        alertController.addAction(cancelAction)
        
        // Set the popover presentation controller properties for iPad
        if let popoverPresentationController = alertController.popoverPresentationController {
            popoverPresentationController.sourceView = self.view
            popoverPresentationController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            popoverPresentationController.permittedArrowDirections = []
        }
        
        // Present the options
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    func checkPhotoLibraryPermission() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            let status = PHPhotoLibrary.authorizationStatus()
            switch status {
            case .authorized:
                self.showPhotoPicker()
            case .notDetermined:
                PHPhotoLibrary.requestAuthorization { status in
                    if status == .authorized {
                        DispatchQueue.main.async {
                            self.showPhotoPicker()
                        }
                    } else {
                        // Handle when permission is denied
                    }
                }
            case .denied, .restricted:
                // Handle when permission is denied or restricted
                break
            @unknown default:
                break
            }
        }
    }
    
    // Function to check and request permission for camera
    func checkCameraPermission() {
        let authStatus = AVCaptureDevice.authorizationStatus(for: .video)
        switch authStatus {
        case .authorized:
            self.showCamera()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                if granted {
                    self.showCamera()
                } else {
                    // Handle when permission is denied
                }
            }
        case .denied, .restricted:
            // Handle when permission is denied or restricted
            break
        @unknown default:
            break
        }
    }
    
    func showPhotoPicker() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .photoLibrary
            self.present(picker, animated: true, completion: nil)
        }
    }
        
    // Function to present camera
    func showCamera() {
        DispatchQueue.main.async {
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .camera
            self.present(picker, animated: true, completion: nil)
        }
    }
        
    // Delegate method to handle the selected image
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            // Set the selected image to your UIImageView
            imgProfile.image = selectedImage
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    // Delegate method to handle cancellation
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
}


extension AddMemberVC {
    func observeEvent() {
        vmsViewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Loaded")
            case .error(let error):
                print("Error In Api Call :- \(error)")
                
            case .allRolesFatchedSuccessfully(allRoles: let allRoles):
                
                let allRoles = getRoleDataSource(roles: allRoles)
                
                self.dropdownRoleTypes = allRoles
                for rol in self.dropdownRoleTypes {
                    self.roleNames.append(rol.roleName ?? "")
                }
                self.dropDownRole.dataSource =  self.roleNames

                
            case .allSitesFatchedSuccessfully(allSites: let allSites):
                
                let allSites = getSiteDataSource(sites: allSites)
                
                self.dropdownSiteTypes = allSites
                for site in self.dropdownSiteTypes {
                    self.siteNames.append(site.siteName)
                }
                self.dropdownSite.dataSource = self.siteNames
                
            case .allUnitsFatchedSuccessfully(allUnits: let allUnits):
                
                let allUnits = getUnitDataSource(units: allUnits)
                
                self.dropdownUnitTypes = allUnits
                for site in self.dropdownUnitTypes {
//                    self.unitNames.append(site.unitNumberName)
                    self.unitNames.append("\(site.unitNumberName) - \(site.name)")
                }
                self.dropDownUnit.dataSource = self.unitNames
                
            case .allRFIDsFetchedSuccessfully(allRFIDs: let allRFIDs):
                
                let allRFIDs = getRFIDsDataSource(RFIDs: allRFIDs)
                
                self.dropdownRFIDTypes = allRFIDs
                for rfid in self.dropdownRFIDTypes {
                    self.RFIDNames.append(String(rfid.rfidNumber))
                }
                self.dropDownRFID.dataSource = self.RFIDNames
            }
        }
        
        
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
                
            case .loading:
                self.showActivityIndicator()
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Data Loaded")
            case .error(let error):
                print("Error :- \(error)")
                
            case .memberAddedSuccessfully(message: let message):
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    self.view.makeToast(message)
                    
                    self.txtName.text = ""
                    self.txtEmail.text = ""
                    self.txtMobile.text = ""
                    self.txtAddress.text = ""
                    self.lblRole.text = "Select Role"
                    self.lblSite.text = "Select Site"
                    self.lblUnit.text = "Select Unit"
                    self.lblGender.text = "Select Gender"
                    self.imgProfile.image = nil
                }
                
            case .memberNotAddedSuccessfully(message: let message):
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    self.view.makeToast(message)
                }
            }
            
        }
    }
}
