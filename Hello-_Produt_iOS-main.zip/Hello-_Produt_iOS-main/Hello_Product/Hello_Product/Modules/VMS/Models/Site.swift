//
//  Site.swift
//  Hello_Product
//
//  Created by Zentech-038 on 22/11/23.
//

import Foundation
import UIKit

struct Site: Codable {
    var isSuccess: Bool
    var message: String
    var data: [SiteDetail]
}

struct SiteDetail: Codable {
    var id: Int
    var clientId: Int
    var siteName: String
    var organisationName: String
    var countryName: String
    var stateName: String
    var cityName: String
}
