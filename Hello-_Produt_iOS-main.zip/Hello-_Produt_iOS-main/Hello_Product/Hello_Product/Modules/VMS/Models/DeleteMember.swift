//
//  DeleteMember.swift
//  Hello_Product
//
//  Created by Zentech-038 on 22/11/23.
//

import Foundation

struct DeleteMember: Codable {
    var isSuccess: Bool?
    var message: String?
}
