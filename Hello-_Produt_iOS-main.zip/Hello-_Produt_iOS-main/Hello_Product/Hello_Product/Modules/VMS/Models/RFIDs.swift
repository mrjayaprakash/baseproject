//
//  RFIDs.swift
//  Hello_Product
//
//  Created by Zentech-038 on 09/01/24.
//

import Foundation
import UIKit

struct RFIDs: Codable {
    
    var isSuccess: Bool
    var message: String
    var data: [RFIDsDetail]
}

struct RFIDsDetail: Codable {
    var id: Int
    var clientId: Int
    var siteId: Int
    var siteName: String
    var unitId: Int
    var unitName: String
    var rfidNumber: Int
}
