//
//  UpdateProfilrDetail.swift
//  Hello_Product
//
//  Created by Zentech-038 on 21/11/23.
//

import Foundation
import UIKit

struct UpdateProfilrDetail {
    var id: Int
    var memberName: String
    var mobileNumber: String
    var email: String
    var address: String
    var image: UIImage?
    
    init(id: Int, memberName: String, mobileNumber: String, email: String, address: String, image: UIImage?) {
        self.id = id
        self.memberName = memberName
        self.mobileNumber = mobileNumber
        self.email = email
        self.address = address
        self.image = image
    }
        
}
