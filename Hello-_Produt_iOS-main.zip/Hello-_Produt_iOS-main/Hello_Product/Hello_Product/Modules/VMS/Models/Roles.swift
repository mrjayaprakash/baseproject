//
//  Roles.swift
//  Hello_Product
//
//  Created by Zentech-038 on 21/11/23.
//

import Foundation
import UIKit

struct Roles: Codable {
    
    var isSuccess: Bool?
    var message: String?
    var data: [RoleDetail]
}

struct RoleDetail : Codable {
    
    var roleId: Int?
    var roleName: String?
    
    init(roleId: Int, roleName: String) {
        self.roleId = roleId
        self.roleName = roleName
    }
    
    init() {}
}
