//
//  PendingRequest.swift
//  Hello_Product
//
//  Created by Zentech-038 on 25/11/23.
//

import Foundation

//struct PendingRequest: Codable {
//    
//    var isSuccess: Bool?
//    var message: String?
//    var data: [PendingRequestDetails]
//}

struct PendingRequest: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [PendingRequestDetails]

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        isSuccess = try container.decodeIfPresent(Bool.self, forKey: .isSuccess)
        message = try container.decodeIfPresent(String.self, forKey: .message)
        
        // Handle 'data' decoding
        if let detailsArray = try? container.decodeIfPresent([PendingRequestDetails].self, forKey: .data) {
            data = detailsArray ?? [] // If 'detailsArray' is nil, assign an empty array
        } else {
            data = [] // Set default value if decoding fails
        }
    }
}


struct PendingRequestDetails : Codable {
    
    var visitorId: Int?
    var unitName: String?
    var siteId: Int?
    var siteName: String?
    var unitId: Int?
    var unitNumber: String?
    var visitorName: String?
    var mobileNumber: String?
    var emailId: String?
    var checkInStatus: Bool?
    var location: String?
    var qrNumber: String?
    var image: String?
    var status: String?
    
    init(visitorId: Int, unitName: String, siteId: Int, siteName: String, unitId: Int, unitNumber: String, visitorName: String, mobileNumber: String, emailId: String, checkInStatus: Bool, location: String, qrNumber: String, image: String, status: String) {
        self.visitorId = visitorId
        self.unitName = unitName
        self.siteId = siteId
        self.siteName = siteName
        self.unitId = unitId
        self.unitNumber = unitNumber
        self.visitorName = visitorName
        self.mobileNumber = mobileNumber
        self.emailId = emailId
        self.checkInStatus = checkInStatus
        self.location = location
        self.qrNumber = qrNumber
        self.image = image
        self.status = status
    }
    
//    init() {}
}

struct RequestResponse: Codable {
    var isSuccess: Bool?
    var message: String?
}


