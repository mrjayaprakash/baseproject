//
//  Units.swift
//  Hello_Product
//
//  Created by Zentech-038 on 21/11/23.
//

import Foundation
import UIKit

struct Units: Codable {
    
    var isSuccess: Bool
    var message: String
    var data: [UnitDetail]
}

struct UnitDetail : Codable {
    
    var id: Int
    var clientId: Int
    var siteId: Int
    var wingId: Int
    var floorId: Int
    var unitNumberId: Int
    var siteName: String
    var wingName: String
    var floorName: String
    var unitNumberName: String
    var name: String
}

