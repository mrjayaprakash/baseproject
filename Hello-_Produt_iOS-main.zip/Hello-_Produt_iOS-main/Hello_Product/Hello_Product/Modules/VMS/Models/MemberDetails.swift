//
//  MemberDetails.swift
//  Hello_Product
//
//  Created by Zentech-038 on 19/11/23.
//

import Foundation
import UIKit

//struct AllMember: Codable {
//    
//    var isSuccess: Bool?
//    var message: String?
//    var data: [MemberDetails]?
//}

struct AllMember: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [MemberDetails]?

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        isSuccess = try container.decodeIfPresent(Bool.self, forKey: .isSuccess)
        message = try container.decodeIfPresent(String.self, forKey: .message)
        
        // Handle 'data' decoding
        data = try container.decodeIfPresent([MemberDetails].self, forKey: .data)
    }
}




struct MemberDetails : Codable {
    
    var memberId: Int?
    var clientId: Int?
    var clientName: String?
    var siteId: Int?
    var siteName: String?
    var unitId: Int?
    var unitNumber: String?
    var unitName: String?
    var memberName: String?
    var mobileNumber: String?
    var email: String?
    var address: String?
    var gender: String?
    var status: String?
    var roleName: String?
    var image: String?
    var hostName: String?
    var hostEmailId: String?
    
    init(memberId: Int, clientId: Int, clientName: String, siteId: Int, siteName: String, unitId: Int, unitNumber: String, unitName: String, memberName: String, mobileNumber: String, email: String, address: String, gender: String, status: String, roleName: String, image: String, hostName: String, hostEmailId: String) {
        self.memberId = memberId
        self.clientId = clientId
        self.clientName = clientName
        self.siteId = siteId
        self.siteName = siteName
        self.unitId = unitId
        self.unitNumber = unitNumber
        self.unitName = unitName
        self.memberName = memberName
        self.mobileNumber = mobileNumber
        self.email = email
        self.address = address
        self.gender = gender
        self.status = status
        self.roleName = roleName
        self.image = image
        self.hostName = hostName
        self.hostEmailId = hostEmailId
    }
    
    init() {}
}

//struct VersionInfo {
//    var version: Double?
//    var platformUrl: String?
//    
//    init(version: Double, platformUrl: String) {
//        self.version = version
//        self.platformUrl = platformUrl
//    }
//    
//    init () {}
//}
