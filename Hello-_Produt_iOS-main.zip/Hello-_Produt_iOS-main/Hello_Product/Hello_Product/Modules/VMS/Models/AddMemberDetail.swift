//
//  AddMemberDetail.swift
//  Hello_Product
//
//  Created by Zentech-038 on 22/11/23.
//

import Foundation
import UIKit

struct AddMemberDetail {
    var siteId: Int?
    var memberName: String?
    var mobileNumber: String?
    var email: String?
    var address: String?
    var genderId: Int?
    var roleId: Int?
    var unitId: Int?
    var createdBy: String?
    var image: UIImage?
    var rfidId: Int?
    
    init(siteId: Int, memberName: String, mobileNumber: String, email: String, address: String, genderId: Int, roleId: Int, unitId: Int, createdBy: String, image: UIImage, rfidId: Int) {
        self.siteId = siteId
        self.memberName = memberName
        self.mobileNumber = mobileNumber
        self.email = email
        self.address = address
        self.genderId = genderId
        self.roleId = roleId
        self.unitId = unitId
        self.createdBy = createdBy
        self.image = image
        self.rfidId = rfidId
    }
}



