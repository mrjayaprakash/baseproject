//
//  VMSViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 23/11/23.
//

import Foundation
import UIKit

class VMSViewModel {
    
    var eventHandler: ((_ event: Event) -> Void)?
    
    func getAllRole() {
        
        ApiManager.shared.request(modelType: Roles.self,
                                  type: ManageUsersEndPoint.getAllRole) { result in
            switch result {
                
            case .success(let allRoles):
                
                let roles = allRoles.data
                
                self.eventHandler?(.allRolesFatchedSuccessfully(allRoles: roles))
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
    }
    
    
    
    func getAllsites() {
        
        ApiManager.shared.request(modelType: Site.self,
                                  type: ManageUsersEndPoint.getAllSites) { result in
            switch result {
                
            case .success(let allSites):
                
                let sites = allSites.data
                
                self.eventHandler?(.allSitesFatchedSuccessfully(allSites: sites))
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
    }
    
    
    func getAllUnits() {
        ApiManager.shared.request(modelType: Units.self,
                                  type: ManageUsersEndPoint.getAllUnits) { result in
            switch result {
                
            case .success(let allUnits):
                
                let units = allUnits.data
                
                self.eventHandler?(.allUnitsFatchedSuccessfully(allUnits: units))
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
        
    }
    
    func getAllRFIDs() {
        ApiManager.shared.request(modelType: RFIDs.self,
                                  type: ManageUsersEndPoint.getAllRFIDs) { result in
            switch result {
            case .success(let allRFIDs):
                let RFIDs = allRFIDs.data
                self.eventHandler?(.allRFIDsFetchedSuccessfully(allRFIDs: RFIDs))
                
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
    }
    
}

extension VMSViewModel {
    
    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case allRolesFatchedSuccessfully(allRoles: [RoleDetail])
        case allSitesFatchedSuccessfully(allSites: [SiteDetail])
        case allUnitsFatchedSuccessfully(allUnits: [UnitDetail])
        case allRFIDsFetchedSuccessfully(allRFIDs: [RFIDsDetail])
    }
    
}
