//
//  PendinfRequestVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 13/11/23.
//

import Foundation
import UIKit
import Toast_Swift

class PendinfRequestVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnBACK: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var lblTitle: UILabel!
    
    let viewModel = PendingRequestViewModel()
    var memberDetails = MemberDetails()
    var pendingRequest = [PendingRequestDetails]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let id = String(GlobalConstants.loggedInMemberDetails.unitId ?? 0)
        
        design()
        
//        viewModel.getAllPendingRequest(unitId: id)
//        observeEvent()
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "PendingRequestCell", bundle: nil), forCellReuseIdentifier: "PendingRequestCell")
        tableView.separatorStyle = .none
        tableView.bounces = false
        lblTitle.text = GlobalConstants.loggedInMemberDetails.siteName

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let id = String(GlobalConstants.loggedInMemberDetails.unitId ?? 0)
        viewModel.getAllPendingRequest(unitId: id)
        observeEvent()
    }
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func design() {
        
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        self.navigationController?.navigationBar.isHidden = true
        btnBACK.setTitle("", for: .normal)
        
    }
}

extension PendinfRequestVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pendingRequest.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PendingRequestCell") as! PendingRequestCell
        cell.delegate = self
        cell.selectionStyle = .none
        
        let request = pendingRequest[indexPath.row]
        
        cell.mobileNo = request.mobileNumber ?? ""
        cell.userNameLbl.text = request.visitorName
        cell.roleLbl.text = request.mobileNumber
        cell.profileImageView.sd_setImage(with: URL(string: request.image ?? ""), placeholderImage: UIImage(named: "CircleProfileImage"))
//        cell.delegate = self
//        cell.requestMobileNumber = request.mobileNumber
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
    
    
}

extension PendinfRequestVC: PendingRequestProtocol {
    func AcceptRequest(mobileNo: String) {
        
        observeEvent()
        viewModel.acceptRequest(mobileNo: mobileNo)
        
    }
    
    func RejectRequest(mobileNo: String) {
        
        observeEvent()
        viewModel.rejectRequest(mobileNo: mobileNo)
    }
    
    func showActIndicator() {
        DispatchQueue.main.async {
            self.showActivityIndicator()
        }
    }
    
    func hideActIndicator() {
        DispatchQueue.main.async {
            self.hideActIndicator()
        }
    }
    
    func refreshRequestsScreen() {
        let id = String(GlobalConstants.loggedInMemberDetails.unitId ?? 0)
        viewModel.getAllPendingRequest(unitId: id)
    }
    
    func presentAlertView(alert: UIAlertController) {
        self.present(alert, animated: true)
    }
}

extension PendinfRequestVC {
    
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
                
            case .loading:
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Data Loaded")
            case .error(let error):
                DispatchQueue.main.async {
                    self.view.makeToast(error?.localizedDescription)
                }
            case .allPendingRequestFetchSuccessfully(PendingRequest: let PendingRequest):
                self.pendingRequest = PendingRequest
                
                if PendingRequest.count <= 0 {
                    DispatchQueue.main.async {
                        self.tableView.isHidden = true
                    }
                }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .requestAccepted(response: let response):
                
                if response.isSuccess ?? false{
                    let id = String(GlobalConstants.loggedInMemberDetails.unitId ?? 0)
                    viewModel.getAllPendingRequest(unitId: id)
                }
                DispatchQueue.main.async {
                    self.view.makeToast(response.message)
                }
            case .requestReject(response: let response):
                if response.isSuccess ?? false{
                    let id = String(GlobalConstants.loggedInMemberDetails.unitId ?? 0)
                    viewModel.getAllPendingRequest(unitId: id)
                }
                DispatchQueue.main.async {
                    self.view.makeToast(response.message)
                }
            }
        }
    }
}
