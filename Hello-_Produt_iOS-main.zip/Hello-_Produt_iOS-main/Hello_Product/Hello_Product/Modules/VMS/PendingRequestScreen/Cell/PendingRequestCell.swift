//
//  PendingRequestCell.swift
//  Hello_Product
//
//  Created by Zentech-038 on 24/11/23.
//

import UIKit

protocol PendingRequestProtocol {
    
    func presentAlertView(alert: UIAlertController)
    func showActIndicator()
    func hideActIndicator()
    func refreshRequestsScreen()
    func AcceptRequest(mobileNo: String)
    func RejectRequest(mobileNo: String)
    
}

class PendingRequestCell: UITableViewCell {
    
    @IBOutlet weak var innerView: UIView!
    
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var userNameLbl: UILabel!
    @IBOutlet weak var roleLbl: UILabel!
    @IBOutlet weak var acceptBtn: UIButton!
    @IBOutlet weak var rejectBtn: UIButton!
    
    var delegate: PendingRequestProtocol?
    
    var mobileNo = ""
//    let visitorInfo = VisitorDetail()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        innerView.layer.cornerRadius = 8.0
        innerView.backgroundColor = ColorConstants.cellBackgroundColor

        
        profileImageView.layer.cornerRadius = profileImageView.frame.size.width/2
        profileImageView.contentMode = .scaleAspectFill
        
//        userNameLbl.textColor = ColorConstants.ThemeColor
//        roleLbl.textColor = ColorConstants.ThemeColor
        
//        rejectBtn.titleLabel?.textColor = ColorConstants.TextFieldBorderColor
//        acceptBtn.titleLabel?.textColor = ColorConstants.ThemeColor
//        rejectBtn.tintColor = ColorConstants.TextFieldBorderColor
//        acceptBtn.tintColor = ColorConstants.ThemeColor
        
        if let attrFont = UIFont(name: "Poppins-Regular", size: 13) {
            let title = "Accept"
            let attrTitle = NSAttributedString(string: title, attributes: [NSAttributedString.Key.font: attrFont])
            acceptBtn.setAttributedTitle(attrTitle, for: UIControl.State.normal)
        }
        
        if let attrFont = UIFont(name: "Poppins-Regular", size: 13) {
            let title = "Reject"
            let attrTitle = NSAttributedString(string: title, attributes: [NSAttributedString.Key.font: attrFont])
            rejectBtn.setAttributedTitle(attrTitle, for: UIControl.State.normal)
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func btnAcceptTapped(_ sender: UIButton) {
        print("accept button clicked")
        let alert = UIAlertController(title: "Alert", message: "Are you sure you want to Accept ?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            switch action.style{
                case .default:
                print("default")
                self.delegate?.AcceptRequest(mobileNo: self.mobileNo)
                
                case .cancel:
                print("cancel")
                
                case .destructive:
                print("destructive")
                
            }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
            switch action.style{
                case .default:
                print("default")
                
                case .cancel:
                print("cancel")
                
                case .destructive:
                print("destructive")
                
            }
        }))
        delegate?.presentAlertView(alert: alert)
        
        
    }
    
    @IBAction func btnRejectTapped(_ sender: UIButton) {
        
        print("Reject action")
        let alert = UIAlertController(title: "Alert", message: "Are you sure you want to reject request ?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            switch action.style{
                case .default:
                    print("Rejected")
                    self.delegate?.RejectRequest(mobileNo: self.mobileNo)

                
                case .cancel:
                    print("cancel")
                
                case .destructive:
                    print("destructive")
                
            }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
            switch action.style{
                case .default:
                print("default")
                
                case .cancel:
                print("cancel")
                
                case .destructive:
                print("destructive")
                
            }
        }))
        delegate?.presentAlertView(alert: alert)
    }
    
}
