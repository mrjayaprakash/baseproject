//
//  PendingRequestViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 25/11/23.
//

import Foundation

final class PendingRequestViewModel {
    
    var eventHandler: ((_ event: Event) -> Void)?
    
    func getAllPendingRequest(unitId: String) {
        self.eventHandler?(.loading)
        
        ApiManager.shared.request(modelType: PendingRequest.self,
                                  type: ManageUsersEndPoint.getAllPendingRequest(unitId: unitId)) { result in
            switch result {
                
            case .success(let pendingRequest):
                self.eventHandler?(.allPendingRequestFetchSuccessfully(PendingRequest: pendingRequest.data))

            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
    }
    
    func acceptRequest(mobileNo: String) {
        self.eventHandler?(.loading)
        
        let status = Status(statusId: 1)
        
        ApiManager.shared.request(modelType: RequestResponse.self,
                                  type: ManageUsersEndPoint.acceptRequest(status: status, mobileNo: mobileNo)) { result in
            switch result {
                
            case .success(let response):
                self.eventHandler?(.requestAccepted(response: response))
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
    }
    
    
    func rejectRequest(mobileNo: String) {
        self.eventHandler?(.loading)
        
        let status = Status(statusId: 3)
        
        ApiManager.shared.request(modelType: RequestResponse.self,
                                  type: ManageUsersEndPoint.rejectRequest(status: status, mobileNo: mobileNo)) { result in
            switch result {
                
            case .success(let response):
                self.eventHandler?(.requestReject(response: response))
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
    }
    
}

extension PendingRequestViewModel {
    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case allPendingRequestFetchSuccessfully(PendingRequest: [PendingRequestDetails])
        case requestAccepted(response: RequestResponse)
        case requestReject(response: RequestResponse)

    }
}

struct Status: Codable {
    var statusId: Int?
    
    init(statusId: Int) {
        self.statusId = statusId
    }
    
    init () {}
}



