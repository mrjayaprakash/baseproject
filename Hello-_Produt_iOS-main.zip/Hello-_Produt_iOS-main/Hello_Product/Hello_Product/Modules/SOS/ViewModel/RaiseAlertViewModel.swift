//
//  RaiseAlertViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 09/02/24.
//

import Foundation
import UIKit

final class RaiseAlertViewModel {
    
    var eventHandler: ((_ event: Event) -> Void)?
  
    // Define maximum size in bytes (500 KB)
    let maxSizeInBytes = 500 * 1024 // 500 KB

    // Define compression settings
    let compressionQuality: CGFloat = 0.5 // Set your desired compression quality (0.0 - 1.0)
    
    func raiseAlert(details: Alert) {
        self.eventHandler?(.loading)
        var multipart = MultipartRequest()
        
        let memberId = details.memberId ?? ""
        let alertType = details.alertType ?? ""
        let alertDescription = details.alertDescription ?? ""
        
        
        for field in [
            "memberId": memberId,
            "alertType": alertType,
            "alertDescription": alertDescription,
        ] as [String : Any] {
            multipart.add(key: field.key, value: "\(field.value)")
        }
        
        if let originalImage = details.image {
            if let compressedImageData = compressImageIfNeeded(originalImage, maxSizeInBytes: maxSizeInBytes, compressionQuality: compressionQuality) {
                // Add the compressed image data to multipart
                multipart.add(
                    key: "image",
                    fileName: "visitorpic.png",
                    fileMimeType: "image/png",
                    fileData: compressedImageData
                )
            } else {
                print("Failed to compress image")
            }
        } else {
            print("No Image Found")
        }
        
        

        var success_param:Bool = false
        
        
        /// Create a regular HTTP URL request & use multipart components
        let url = URL(string: "https://helloproduct.azurewebsites.net/api/EmergencyAlert/SetEmergencyAlertAsync")!
    //        let url = URL(string: "http://192.168.1.17:5000/api/ManageUsers/postUsers")!

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue(multipart.httpContentTypeHeaderValue, forHTTPHeaderField: "Content-Type")
        request.httpBody = multipart.httpBody

        let session = URLSession(configuration: .default)
        session.dataTask(with: request) { (data, response, error) in
            if error != nil {
                
            } else {
                
                //Data received.
                guard let data = data,
                        let response = response as? HTTPURLResponse,
                        error == nil
                    else {
                        print("error", error ?? URLError(.badServerResponse))
                        return
                    }

                if response.statusCode == 200 {
                    print("HTTP Success")
                } else {
                    print("HTTP Error code = \(response.statusCode)")
                    if response.statusCode == 401 {
                       // self.logoutDueToTimeout()
                    }
                }

                if let json = try? JSONSerialization.jsonObject(with: data) as? [String:Any] {
//                    print("Data received = \(json)")
                    let isSuccess = json["isSuccess"] as? Bool ?? false
                    let message = json["message"] as? String ?? ""
                    
                    if isSuccess {
                        self.eventHandler?(.alertRaisedSuccessfully)
                    } else {
                        self.eventHandler?(.error(error))
                    }
                    success_param = isSuccess
                } else {
                    print(data)
                }
            }
        }.resume()
        
//        ApiManager.shared.request(modelType: AlertResponse.self,
//                                  type: RaiseAlertEndPoint.raiseAlert(details: details)) { result in
//            switch result {
//                
//            case .success(let data):
//                print(data)
//                self.eventHandler?(.alertRaisedSuccessfully)
//            case .failure(let error):
//                self.eventHandler?(.error(error))
//            }
//        }
    }
    
    func compressImageIfNeeded(_ image: UIImage, maxSizeInBytes: Int, compressionQuality: CGFloat) -> Data? {
        guard let imageData = image.jpegData(compressionQuality: 1.0) else {
            return nil
        }
        
        // Check if the image size exceeds the maximum allowed size
        if imageData.count > maxSizeInBytes {
            let scaleFactor = CGFloat(maxSizeInBytes) / CGFloat(imageData.count)
            let targetSize = CGSize(width: image.size.width * scaleFactor, height: image.size.height * scaleFactor)
            return resizeAndCompressImage(image, targetSize: targetSize, compressionQuality: compressionQuality)
        } else {
            return imageData
        }
    }
    
    // Function to resize and compress the image
    func resizeAndCompressImage(_ image: UIImage, targetSize: CGSize, compressionQuality: CGFloat) -> Data? {
        UIGraphicsBeginImageContextWithOptions(targetSize, false, 1.0)
        image.draw(in: CGRect(origin: .zero, size: targetSize))
        guard let resizedImage = UIGraphicsGetImageFromCurrentImageContext() else {
            UIGraphicsEndImageContext()
            return nil
        }
        UIGraphicsEndImageContext()
        
        return resizedImage.jpegData(compressionQuality: compressionQuality)
    }
    
    
}

extension RaiseAlertViewModel {

    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case alertRaisedSuccessfully
    }

}
