//
//  RaiseAlertModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 15/02/24.
//

import Foundation
import UIKit

struct Alert {
    
    var memberId: String?
    var alertType: String?
    var alertDescription: String?
    var image: UIImage?
    
    init(memberId: String, alertType: String, alertDescription: String, image: UIImage) {
        self.memberId = memberId
        self.alertType = alertType
        self.alertDescription = alertDescription
        self.image = image
    }
}

struct AlertResponse: Codable {
    
}
