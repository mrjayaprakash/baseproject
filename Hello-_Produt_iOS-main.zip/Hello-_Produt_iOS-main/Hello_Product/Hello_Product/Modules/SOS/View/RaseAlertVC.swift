//
//  RaseAlertVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 25/01/24.
//

import Foundation
import UIKit
import AVFoundation
import Photos


class RaseAlertVC: UIViewController {
    
    @IBOutlet weak var viewPopover: UIView!
    @IBOutlet weak var viewHeader: UIView!
    @IBOutlet weak var viewContainer: UIStackView!
    @IBOutlet weak var btnCamera: UIButton!
    @IBOutlet weak var ViewFooter: UIStackView!
    
    @IBOutlet weak var viewFire: UIView!
    @IBOutlet weak var viewLift: UIView!
    @IBOutlet weak var viewAnimal: UIView!
    @IBOutlet weak var viewVisitor: UIView!
    
    @IBOutlet weak var txtDescription: UITextField!
    
    var selectedView: UIView?
    var image = UIImage(named: "ticket.png")
    
    private var viewModel = PushViewModel()
    private var raiseViewModel = RaiseAlertViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Design()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tap)
        view.backgroundColor = .black.withAlphaComponent(0.8)
        
        addTapGestureRecognizer(to: viewFire, withTag: 1)
        addTapGestureRecognizer(to: viewLift, withTag: 2)
        addTapGestureRecognizer(to: viewAnimal, withTag: 3)
        addTapGestureRecognizer(to: viewVisitor, withTag: 4)
        
//        btnCamera.isHidden = true
        
    }
    
    
    func addTapGestureRecognizer(to view: UIView, withTag tag: Int) {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleViewTap(_:)))
        view.addGestureRecognizer(tapGesture)
        view.tag = tag
    }
    
    @objc func handleViewTap(_ sender: UITapGestureRecognizer) {
        if let tappedView = sender.view {
            selectView(tappedView)
        }
    }
    
    func selectView(_ view: UIView) {
        // Unselect the previously selected view
        selectedView?.layer.borderWidth = 0

        // Select the tapped view
        view.layer.cornerRadius = 15
        view.layer.borderWidth = 2.0
        view.layer.borderColor = UIColor.red.cgColor

        // Update the selected view
        selectedView = view
    }
    
    func Design() {
        
        viewPopover.layer.cornerRadius = 20
        viewPopover.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        viewHeader.layer.cornerRadius = 20
//        viewHeader.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        viewContainer.layer.cornerRadius = 15
        viewContainer.layer.borderWidth = 1.5
        viewContainer.layer.borderColor = UIColor.lightGray.cgColor
        
        btnCamera.setTitle("", for: .normal)
        
        ViewFooter.layer.borderWidth = 1.5
        ViewFooter.layer.borderColor = UIColor.lightGray.cgColor
    }
    @IBAction func btncameraTapped(_ sender: UIButton) {
        checkCameraPermission()
    }
    
    func checkCameraPermission() {
        let authStatus = AVCaptureDevice.authorizationStatus(for: .video)
        switch authStatus {
        case .authorized:
            self.showCamera()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                if granted {
                    self.showCamera()
                } else {
                    // Handle when permission is denied
                }
            }
        case .denied, .restricted:
            // Handle when permission is denied or restricted
            break
        @unknown default:
            break
        }
    }
    
    func showCamera() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .camera
            self.present(picker, animated: true, completion: nil)
        }
    }
    
    @IBAction func raiseAlarmTapped(_ sender: UIButton) {
        if let selectedView = selectedView {
            let viewTag = selectedView.tag
            print("Selected View: \(viewTag)")
            
            switch viewTag {
            case 1: 
                
                let memberId = GlobalConstants.loggedInMemberDetails.memberId ?? 0
                let alertType = "Fire Alert !"
                let alertDescription = txtDescription.text ?? ""
                
                showAlert(details: Alert(memberId: String(memberId),
                                         alertType: alertType,
                                         alertDescription: alertDescription,
                                         image: image!))
                
            case 2:
                
                let memberId = GlobalConstants.loggedInMemberDetails.memberId ?? 0
                let alertType = "Someone stuck in lift."
                let alertDescription = txtDescription.text ?? ""
                
                showAlert(details: Alert(memberId: String(memberId),
                                         alertType: alertType,
                                         alertDescription: alertDescription,
                                         image: image!))
                
            case 3:
                
                let memberId = GlobalConstants.loggedInMemberDetails.memberId ?? 0
                let alertType = "Animal Alert !"
                let alertDescription = txtDescription.text ?? ""
                
                showAlert(details: Alert(memberId: String(memberId),
                                         alertType: alertType,
                                         alertDescription: alertDescription,
                                         image: image!))
            case 4:
                let memberId = GlobalConstants.loggedInMemberDetails.memberId ?? 0
                let alertType = "Visitor Alert !"
                let alertDescription = txtDescription.text ?? ""
                
                showAlert(details: Alert(memberId: String(memberId),
                                         alertType: alertType,
                                         alertDescription: alertDescription,
                                         image: image!))
            default:
                self.view.makeToast("Some thing went wrong")
            }
            
        } else {
            print("No view selected.")
        }
    }
    
    @objc func handleTap() {
        self.dismiss(animated: true)
    }
    
    
    func showAlert(details: Alert) {
        let alertController = UIAlertController(title: "Alert", message: "Are you sure you want to raise alert? Alert raised whithout any reason shoud be fined by 2000 Rs.", preferredStyle: .alert)
        
        // Add a cancel action
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
            print("Cancel button tapped")
        }
        alertController.addAction(cancelAction)
        
        // Add a custom action
        let raiseAlertAction = UIAlertAction(title: "Raise Alert", style: .default) { _ in
            self.observeEvent()
            self.raiseViewModel.raiseAlert(details: details)
            
        }
        alertController.addAction(raiseAlertAction)
        
        // Present the alert
        present(alertController, animated: true, completion: nil)
    }
    
    func raiseAnotherAlert() {
        let anotherAlertController = UIAlertController(title: "Successful", message: "Alert Raise Successfully!", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        anotherAlertController.addAction(okAction)
        
        present(anotherAlertController, animated: true, completion: nil)
    }
    
    
}

extension RaseAlertVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//    // Delegate method to handle the selected image
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//        if let selectedImage = info[.originalImage] as? UIImage {
//            // Set the selected image to your UIImageView
//            image = selectedImage
//        }
//        picker.dismiss(animated: true, completion: nil)
//    }
//    
//    // Delegate method to handle cancellation
//    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//        picker.dismiss(animated: true, completion: nil)
//    }
}

extension RaseAlertVC {
    
    func observeEvent() {
        raiseViewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
                
            case .loading:
                print("Loading")
            case .stopLoading:
                print("Stop Loading")

            case .dataLoaded:
                print("Data Loaded")

            case .error(_):
                print("Error Occure")

            case .alertRaisedSuccessfully:
//                raiseAnotherAlert()
                DispatchQueue.main.async {
                    self.view.makeToast("Alert Raised Successfully")
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
    
