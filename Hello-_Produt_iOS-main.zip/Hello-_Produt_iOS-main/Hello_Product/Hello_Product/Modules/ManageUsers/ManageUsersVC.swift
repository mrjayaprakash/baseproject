//
//  ManageUsersVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 26/11/23.
//

import Foundation
import UIKit
import SDWebImage

class ManageUsersVC: UIViewController {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var btnSOS: UIButton!
    @IBOutlet weak var btnAdd: UIButton!
    
    private var viewModel = ManageUsersViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewModel.fetchMembers()
        self.showActivityIndicator()
        
        observeEvent()
        
        navigationController?.navigationBar.isHidden = true
        design()
        
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "ManageUsersCell", bundle: nil), forCellReuseIdentifier: "ManageUsersCell")
        tableView.separatorStyle = .none
        tableView.bounces = false
        
        print(viewModel.allMemberArray.count)
    }
    
    func design() {
        
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        btnAdd.layer.cornerRadius = 5
        
        btnAdd.titleLabel?.font = UIFont.systemFont(ofSize: 12)
                
        btnBack.setTitle("", for: .normal)
        btnSOS.setTitle("", for: .normal)
        
        
        navigationController?.navigationBar.isHidden = true
        
    }
    
    @IBAction func addUsersTapped(_ sender: UIButton) {
        
        let storyboard = UIStoryboard(name: "VMS", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "AddMemberVC") as! AddMemberVC
        
        self.navigationController?.pushViewController(vc, animated: true)

    }
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
        
    }
    @IBAction func btnSOSTapped(_ sender: Any) {
    }
    
    
}

extension ManageUsersVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.allMemberArray.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let data = viewModel.allMemberArray[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ManageUsersCell", for: indexPath) as! ManageUsersCell
        
        cell.memberID = data.memberId ?? 0
        cell.memberData = data
        
        cell.delegate = self
                
        cell.nameLbl.text = data.memberName
        cell.roleLbl.text = data.roleName
        
        cell.imgProfile.sd_setImage(with: URL(string: data.image ?? ""), placeholderImage: UIImage(named: "CircleProfileImage"))

        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}

extension ManageUsersVC: ManageUsersProtocol {
    
    func presentAlertViewForDeleteUser(alert: UIAlertController) {
        self.present(alert, animated: true)
    }
    
    func presentAlertView(alert: UIAlertController) {
        
//        self.present(alert, animated: true, completion: { [weak self] in
//            self?.fetchAllUsersAPI()
//        })
    }
    
    func showActIndicator() {
        print("showActivityIndicator")
        self.showActivityIndicator()
    }
    
    func hideActIndicator() {
        print("hideActivityIndicator")
        self.hideActivityIndicator()
    }
    
    func dismissScreen() {
        self.dismiss(animated: true)

    }
    
    func openEditScreen(data: MemberDetails) {
        
        print("Edit Tapped")
        let storyboard = UIStoryboard(name: "VMS", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "EditMemberVC") as! EditMemberVC
        vc.memberData = data
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func callDeleteMemberApi(memberId: String) {
        viewModel.deleteMember(memberid: memberId)
//        observeEvent()
    }

}

extension ManageUsersVC {
    
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            
            case .loading:
                print("Data Loading")
                DispatchQueue.main.async {
                    self.showActivityIndicator()
                }
            case .stopLoading:
                print("Data Stoped Loading")
                self.hideActivityIndicator()
            case .dataLoaded:
                print("Data Loaded")
            case .error(let error):
                print(error)
            case .memberDetailFetched(memberDetail: let memberDetail):
                print(memberDetail.data?.count)
//                viewModel.allMemberArray = memberDetail.data
                viewModel.allMemberArray = filterDataForLoggedInUser(loggedInData: GlobalConstants.loggedInMemberDetails, dataArray: memberDetail.data ?? [])
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .memberDeletedSuccessfully:
                
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    self.tableView.reloadData()
                }
                viewModel.fetchMembers()
                print("Member Deleted Successfully")
            }
        }
    }
    
    func filterDataForLoggedInUser(loggedInData: MemberDetails, dataArray: [MemberDetails]) -> [MemberDetails] {
        // Check the role of the logged-in user
        guard let userRole = loggedInData.roleName else {
            // If role information is not available, return an empty array
            return []
        }

        switch userRole {
            
        case "Super Admin":
            
            var array = dataArray.filter { $0.clientId == loggedInData.clientId }
                        
            return array.filter { $0.roleName == "Site Admin" }

        case "Site Admin":
            
            var array = dataArray.filter { $0.clientId == loggedInData.clientId }
            
            array = array.filter { $0.siteId == loggedInData.siteId }
            
            return array.filter { $0.roleName == "Unit Admin" }


        case "Unit Admin":
            
            var array = dataArray.filter { $0.clientId == loggedInData.clientId }
            
            array = array.filter { $0.siteId == loggedInData.siteId }
            
            array = array.filter { $0.unitId == loggedInData.unitId }
            
            return array.filter { $0.roleName == "Employee" }


        default:
            // For other roles, return an empty array (you can modify this as needed)
            return []
        }
    }
}
