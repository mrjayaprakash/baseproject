//
//  ManageUsersCell.swift
//  Hello_Product
//
//  Created by Zentech-038 on 19/11/23.
//

import UIKit

protocol ManageUsersProtocol {
    func presentAlertViewForDeleteUser(alert: UIAlertController)
    func presentAlertView(alert: UIAlertController)
    func showActIndicator()
    func hideActIndicator()
    func dismissScreen()
    func openEditScreen(data: MemberDetails)
    func callDeleteMemberApi(memberId: String)
}

class ManageUsersCell: UITableViewCell {
    
    var memberID:Int = 0
    var memberData = MemberDetails()

    @IBOutlet weak var imgProfile: UIImageView!
    
    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var roleLbl: UILabel!
    @IBOutlet weak var editBtn: UIButton!
    @IBOutlet weak var deleteBtn: UIButton!
    
//    let viewModel = ManageUsersViewModel()
    var delegate: ManageUsersProtocol?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Initialization code
        innerView.layer.cornerRadius = 8.0
        innerView.backgroundColor = ColorConstants.cellBackgroundColor
        editBtn.setTitle("", for: .normal)
        deleteBtn.setTitle("", for: .normal)

        imgProfile.layer.cornerRadius = imgProfile.frame.size.width/2
        imgProfile.contentMode = .scaleAspectFill

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func deleteTapped(_ sender: UIButton) {
        print("Delete action")
        let alert = UIAlertController(title: "Alert", message: "Are you sure you want to delete user ?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            switch action.style{
                case .default:
                
                print("MemberId: \(self.memberID)")
                let id = String(self.memberID)
                self.delegate?.callDeleteMemberApi(memberId: id)

                case .cancel:
                print("cancel")
                
                case .destructive:
                print("destructive")
                
            }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
            switch action.style{
                case .default:
                print("default")
                
                case .cancel:
                print("cancel")
                
                case .destructive:
                print("destructive")
                
            }
        }))
        self.delegate?.presentAlertViewForDeleteUser(alert: alert)
        
    }
    
    @IBAction func editTapped(_ sender: UIButton) {
        self.delegate?.openEditScreen(data: memberData)
    }

    
}
