//
//  MenuViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 26/11/23.
//

import Foundation
import UIKit

final class MenuViewModel {
    
    var eventHandler: ((_ event: Event) -> Void)?
    
    
    var memberDetails = MemberDetails()

    var BannerData = [BannerDetails]()
    
    // fetch all member
    func fetchMemberDetail(memberId: String) {
        
        self.eventHandler?(.loading)
        
        ApiManager.shared.request(
            modelType: AllMember.self,
            type: ManageUsersEndPoint.getMemberDetailsById(memberId: memberId)) { result in
                switch result {
                case .success(let memberDetails):
                    
                    var memberdetail = MemberDetails()
                    if memberDetails.data?.count ?? 0 >= 1 {
                        memberdetail = memberDetails.data?[0] ?? MemberDetails()
                    } else  {
                        print("No data found")
                    }
                    
                    self.eventHandler?(.dataFatchedSuccessfully(memberDetail:memberdetail))
                    
                case .failure(let error):
                    self.eventHandler?(.error(error))
                }
        }
    }
    
    func fetchPlatformVersionInformation() {
        
        self.eventHandler?(.loading)
        
        ApiManager.shared.request(modelType: VersionInfoResponse.self,
                                  type: ManageUsersEndPoint.fetchVersionPletform) { result in
            switch result {
                
            case .success(let data):
                if data.isSuccess == true {
                    
                    if let versionData = data.data {
                        for versionInfo in versionData {
                            if versionInfo.platform == "iOS" {
                                self.eventHandler?(.versionFatchedSuccessfully(versionInfo: versionInfo))

                            }
                        }
                    } else {
                        self.eventHandler?(.noVersionFound)
                    }
                    
                } else {
                    self.eventHandler?(.noVersionFound)
                }
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
    }
    
    func fetchBannerDetails(id: String) {
        self.eventHandler?(.loading)
        
        ApiManager.shared.request(modelType: BannerResponse.self,
                                  type: ManageUsersEndPoint.getBannerImage(id: id)) { result in
            switch result {
                
            case .success(let data):
                self.eventHandler?(.bannerFetchedSuccessfully(data: data.data ?? []))

            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }

    }
}

extension MenuViewModel {

    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case dataFatchedSuccessfully(memberDetail: MemberDetails)
        case versionFatchedSuccessfully(versionInfo: VersionInfo)
        case noVersionFound
        case bannerFetchedSuccessfully(data: [BannerDetails])
    }

}
