//
//  MenuVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 25/11/23.
//

import Foundation
import UIKit
import JWTDecode

class MenuVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblUnit: UILabel!
//    @IBOutlet weak var lblOrgName: UILabel!
    
    @IBOutlet weak var viewQR: UIView!
    @IBOutlet weak var imgQR: UIImageView!
    
    @IBOutlet weak var mainViewMyProfile: UIView!
    @IBOutlet weak var viewMyProfile: UIView!
    @IBOutlet weak var btnMyProfile: UIButton!
    
    @IBOutlet weak var mainViewInviteMember: UIView!
    @IBOutlet weak var viewInviteMember: UIView!
    @IBOutlet weak var btnInviteMember: UIButton!
    
    @IBOutlet weak var mainViewPendingRequest: UIView!
    @IBOutlet weak var viewPendingRequest: UIView!
    @IBOutlet weak var btnPendingRequest: UIButton!
    
    @IBOutlet weak var mainViewManageUsers: UIView!
    @IBOutlet weak var viewManageUsers: UIView!
    @IBOutlet weak var btnManageUsers: UIButton!
    
    @IBOutlet weak var mainViewParking: UIView!
    @IBOutlet weak var viewParking: UIView!
    @IBOutlet weak var btnParking: UIButton!
    
    @IBOutlet weak var mainViewLogout: UIView!
    @IBOutlet weak var viewLogout: UIView!
    @IBOutlet weak var btnLogout: UIButton!
    
    @IBOutlet weak var mainViewSOS: UIView!
    @IBOutlet weak var viewSOS: UIView!
    @IBOutlet weak var btnSOS: UIButton!
    
    @IBOutlet weak var mainViewTickets: UIView!
    @IBOutlet weak var viewTickets: UIView!
    @IBOutlet weak var btnTickets: UIButton!
    
    @IBOutlet weak var mainViewIdCard: UIView!
    @IBOutlet weak var viewIdCard: UIView!
    @IBOutlet weak var btnIdCard: UIButton!
    
    @IBOutlet weak var stackViewAdmin: UIStackView!
    @IBOutlet weak var stackViewIdCard: UIStackView!
        
    @IBOutlet weak var viewBanner: UIView!
    @IBOutlet weak var bannerCollectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    
    let viewModel = MenuViewModel()
    private var pushViewModel = PushViewModel()

    var mobileNo = ""
    var memberId = ""
    var qrString = "0"
    
    var timer: Timer?
    var currentPage = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        decodeJwt()
        designView()
        
        bannerCollectionView.delegate = self
        bannerCollectionView.dataSource = self
                    
        observeEvent()
//        viewModel.fetchPlatformVersionInformation()

        imgQR.isUserInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
        imgQR.addGestureRecognizer(tapGesture)
        
        // Configure collection view layout
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 0
        bannerCollectionView.collectionViewLayout = layout
        
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let pageWidth = bannerCollectionView.frame.width
        currentPage = Int((scrollView.contentOffset.x + pageWidth / 2) / pageWidth)
        pageControl.currentPage = currentPage
    }
    
    func startAutoScroll() {
        timer = Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(autoScrollToNextPage), userInfo: nil, repeats: true)
    }
    
    @objc func autoScrollToNextPage() {
        currentPage = (currentPage + 1) % viewModel.BannerData.count
        let indexPath = IndexPath(item: currentPage, section: 0)
        bannerCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        pageControl.currentPage = currentPage
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        observeEvent()
        viewModel.fetchPlatformVersionInformation()
        viewModel.fetchMemberDetail(memberId: memberId)

    }
    
    
    
    func decodeJwt() {
        let stored_jwt = UserDefaults.standard.value(forKey: Constants.loginTockenConstant) as? String
        
        let jwt = try? decode(jwt: stored_jwt ?? "")
        
        if jwt != nil {
            
            let memberId = jwt?.body["memberId"] as? String ?? ""
            let userName = jwt?.body["memberName"] as? String ?? ""
            let qrNumber = jwt?.body["qrNumber"] as? String ?? ""
            let roleName = jwt?.body["roleName"] as? String ?? ""
            let techId = jwt?.body["employeeTechAccessId"] as? String ?? ""
            let unitName = jwt?.body["unitName"] as? String ?? ""
            let myUnitNo = jwt?.body["unitNumber"] as? String ?? ""

            UserDefaults.standard.set(memberId, forKey: Constants.memberIdConstant)
            UserDefaults.standard.set(userName, forKey: Constants.memberNameConstant)
            UserDefaults.standard.set(qrNumber, forKey: Constants.qrNumverConstant)
            UserDefaults.standard.set(roleName, forKey: Constants.roleConstant)
            UserDefaults.standard.set(techId, forKey: Constants.techId)
            UserDefaults.standard.set(unitName, forKey: Constants.unitName)
            UserDefaults.standard.set(myUnitNo, forKey: Constants.myUnitNo)

            
            lblName.text = userName
            lblUnit.text = unitName
            self.memberId = memberId
            self.qrString = qrNumber
        }
    }
    
    @objc func imageTapped() {
        presentQRViewController(string: self.qrString, forBanner: false)
    }
    
    @IBAction func btnMyProfileTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "VMS", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "UpdateProfileVC") as! UpdateProfileVC
        self.navigationController?.pushViewController(vc, animated: true)
        print("My Profile Tapped")
    }
    
    @IBAction func btnInviteMemberTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "VMS", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "InviteVisitorVC") as! InviteVisitorVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnPendingRequestTapped(_ sender: UIButton) {
        if GlobalConstants.loggedInMemberDetails.roleName == "Employee" || GlobalConstants.loggedInMemberDetails.roleName == "Visitor Device" {
            self.view.makeToast("You don't have access for this tab!")
        } else {
            let storyboard = UIStoryboard(name: "VMS", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "PendinfRequestVC") as! PendinfRequestVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func btnManageUsersTapped(_ sender: UIButton) {
        
        if GlobalConstants.loggedInMemberDetails.roleName == "Employee" || GlobalConstants.loggedInMemberDetails.roleName == "Visitor Device" {
            self.view.makeToast("You don't have access for this tab!")
        } else {
            let storyboard = UIStoryboard(name: "VMS", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "ManageUsersVC") as! ManageUsersVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func btnParkingTapped(_ sender: UIButton) {
        
//        if GlobalConstants.loggedInMemberDetails.roleName == "Guard" {
            let storyboard = UIStoryboard(name: "PMS", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "ParkingMenuVC") as! ParkingMenuVC
            self.navigationController?.pushViewController(vc, animated: true)
//        } else {
            
//        }
    }
    
    @IBAction func btnTicketsTapped(_ sender: UIButton) {
        
        let storyboard = UIStoryboard(name: "Ticketing", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "GrevanceVC") as! GrevanceVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func btnLogoutTapped(_ sender: Any) {
        
        let logoutAlert = UIAlertController(title: "Logout", message: "Are you sure you want to logout?", preferredStyle: .alert)
            
        let yesAction = UIAlertAction(title: "Yes", style: .default) { _ in
            // Perform logout action here, such as resetting user sessions or navigating to login screen
            // Example: self.performLogout()
            print("Logging out...") // Replace this with your logout logic
            self.logoutPressed()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            
        logoutAlert.addAction(yesAction)
        logoutAlert.addAction(cancelAction)
            
        present(logoutAlert, animated: true, completion: nil)
    }
    
    @IBAction func btnSOSTapped(_ sender: UIButton) {
        print("SOS Tapped")
        
        let storyboard = UIStoryboard(name: "SOS", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "RaseAlertVC") as! RaseAlertVC
        
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)        
    }
    
    func showDesignationAlert(on viewController: UIViewController, saveAction: @escaping (String) -> Void) {
        // Create the alert controller
        let alert = UIAlertController(title: "Enter Designation", message: nil, preferredStyle: .alert)
        
        // Add a text field to the alert
        alert.addTextField { textField in
            textField.placeholder = "Designation"
        }
        
        // Add the Save button to the alert
        let saveButton = UIAlertAction(title: "Save", style: .default) { _ in
            // Get the text from the text field
            if let designation = alert.textFields?.first?.text {
                // Call the saveAction closure and pass the entered designation
                saveAction(designation)
            }
        }
        
        // Add the cancel button to the alert
        let cancelButton = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        // Add the actions to the alert
        alert.addAction(saveButton)
        alert.addAction(cancelButton)
        
        // Present the alert on the view controller
        viewController.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func btnIdCardTapped(_ sender: UIButton) {
        
        if UserDefaults.standard.string(forKey: Constants.myDesignation) == nil {
            
            showDesignationAlert(on: self) { designation in
                // Perform your action with the entered designation here
                UserDefaults.standard.setValue(designation, forKey: Constants.myDesignation)

            }
            
        } else {
            
            // Create the alert controller
            let alertController = UIAlertController(title: "Choose Card Type", message: nil, preferredStyle: .alert)

            // Create actions for each button
            let idCardAction = UIAlertAction(title: "ID Card", style: .default) { _ in
                // Handle ID Card button action
                let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "IdCardVC") as! IdCardVC
                VC.modalPresentationStyle = .overFullScreen
                self.present(VC, animated: true)
            }

            let visitingCardAction = UIAlertAction(title: "Visiting Card", style: .default) { _ in
                // Handle Visiting Card button action
                let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "VisitingCardVC") as! VisitingCardVC
                
                self.navigationController?.pushViewController(VC, animated: true)

            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            cancelAction.setValue(UIColor.red, forKey: "titleTextColor")

            // Add actions to the alert controller
            alertController.addAction(idCardAction)
            alertController.addAction(visitingCardAction)
            alertController.addAction(cancelAction)


            // Present the alert controller
            present(alertController, animated: true, completion: nil)
            
        }
        
    }
    
    func logoutPressed() {
        
        UserDefaults.standard.removeObject(forKey: Constants.loginTockenConstant)
        UserDefaults.standard.removeObject(forKey: Constants.memberIdConstant)
        UserDefaults.standard.removeObject(forKey: Constants.memberNameConstant)
        UserDefaults.standard.removeObject(forKey: Constants.qrNumverConstant)
        UserDefaults.standard.removeObject(forKey: Constants.roleConstant)
        UserDefaults.standard.removeObject(forKey: Constants.techId)
        UserDefaults.standard.removeObject(forKey: Constants.unitName)
        UserDefaults.standard.removeObject(forKey: Constants.myDesignation)
        
        DispatchQueue.main.async {
            let storyboard = UIStoryboard(name: "Login", bundle: nil) // Replace "Main" with your actual storyboard name
            guard let loginViewController = storyboard.instantiateViewController(withIdentifier: "LoginVC") as? LoginVC else {
                return // Ensure the view controller is created successfully
            }
            
            // Reset navigation stack if using a navigation controller
            if let navigationController = UIApplication.shared.keyWindow?.rootViewController as? UINavigationController {
                navigationController.setViewControllers([loginViewController], animated: true)
            } else {
                // Set login view controller as the root view controller
                if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
                    appDelegate.window?.rootViewController = loginViewController
                }
            }
        }
    }
    
    func designView() {
        
        navigationController?.navigationBar.isHidden = true
        
        btnMyProfile.setTitle("", for: .normal)
        viewMyProfile.layer.cornerRadius = 10
        viewMyProfile.applyCardEffect()
        
        btnInviteMember.setTitle("", for: .normal)
        viewInviteMember.layer.cornerRadius = 10
        viewInviteMember.applyCardEffect()
        
        btnPendingRequest.setTitle("", for: .normal)
        btnPendingRequest.layer.cornerRadius = 10
        viewPendingRequest.applyCardEffect()
        
        btnManageUsers.setTitle("", for: .normal)
        btnPendingRequest.layer.cornerRadius = 10
        viewManageUsers.applyCardEffect()
        
        btnParking.setTitle("", for: .normal)
        btnParking.layer.cornerRadius = 10
        viewParking.applyCardEffect()
        
        btnLogout.setTitle("", for: .normal)
        btnLogout.layer.cornerRadius = 10
        viewLogout.applyCardEffect()
        
        btnSOS.setTitle("", for: .normal)
        btnSOS.layer.cornerRadius = 10
        viewSOS.applyCardEffect()
        
        btnTickets.setTitle("", for: .normal)
        btnTickets.layer.cornerRadius = 10
        viewTickets.applyCardEffect()
        
        btnIdCard.setTitle("", for: .normal)
        btnIdCard.layer.cornerRadius = 10
        viewIdCard.applyCardEffect()

        
        viewQR.applyCardEffect()
                
        imgProfile.layer.cornerRadius = imgProfile.layer.frame.height / 2
        imgProfile.layer.borderColor = UIColor.white.cgColor
        imgProfile.layer.borderWidth = 5
        
        let qrImage = QRHelper.generateQRCode(from: qrString)
        imgQR.image = qrImage
        
        viewBackground.layer.cornerRadius = 50
        viewBackground.layer.maskedCorners = [ .layerMaxXMinYCorner, .layerMinXMinYCorner]
        
//        mainViewTickets.isHidden = true
        
        if UserDefaults.standard.string(forKey: Constants.roleConstant) == "Employee" ||  UserDefaults.standard.string(forKey: Constants.roleConstant) == "Guard" {
            stackViewAdmin.isHidden = true
        }
        
//        if UserDefaults.standard.string(forKey: Constants.roleConstant) == "Guard" {
//            mainViewParking.isHidden = false
//        } else {
//            mainViewParking.isHidden = true
//        }
        
        if UserDefaults.standard.string(forKey: Constants.roleConstant) == "Guard" {
            mainViewInviteMember.isHidden = false
        }
        
        print("Unit Id :- \(UserDefaults.standard.string(forKey: Constants.myUnitNo))")
        
        if UserDefaults.standard.string(forKey: Constants.myUnitNo) == "810" {
            stackViewIdCard.isHidden = false
        } else {
            stackViewIdCard.isHidden = true
        }
        
        
//        viewBanner.isHidden = true
    }
    
    func presentQRViewController(string: String, forBanner: Bool) {
        let qrVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "QRPopUpVC") as! QRPopUpVC
        qrVC.modalPresentationStyle = .overFullScreen
        qrVC.qrString = string
        qrVC.forBanner = forBanner
        self.present(qrVC, animated: true)
    }
}

extension MenuVC {
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                print("Data Loading")
                DispatchQueue.main.async {
                    self.showActivityIndicator()
                }
            case .stopLoading:
                print("Data Stop Loading")
            case .dataLoaded:
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                }
                print("Data Loaded")
            case .error(let error):
                print("Error :- \(String(describing: error?.localizedDescription))")
                self.hideActivityIndicator()
            case .dataFatchedSuccessfully(memberDetail: let memberDetail):
                
                self.hideActivityIndicator()

//                print("MemberDetail :- \(memberDetail)")
                
                let memberId = String(memberDetail.memberId ?? 0 )
                UserDefaults.standard.set(memberId, forKey: Constants.memberIdConstant)
                
                GlobalConstants.memberImageString = memberDetail.image ?? ""
                
                GlobalConstants.loggedInMemberDetails = memberDetail
                
                viewModel.fetchBannerDetails(id: String(GlobalConstants.loggedInMemberDetails.siteId ?? 0))
                
                DispatchQueue.main.async {
                    
                    self.lblName.text = memberDetail.memberName
                    self.lblUnit.text = String(memberDetail.unitNumber ?? "" ) + " - " + (memberDetail.unitName ?? "")
//                    self.lblOrgName.text = memberDetail.unitName
                                    
                    self.imgProfile.sd_setImage(with: URL(string: memberDetail.image ?? "" ), placeholderImage: UIImage(named: "CircleProfileImage"))
                }
                
                var deviceToken = UserDefaults.standard.value(forKey: Constants.deviceToken) as? String ?? ""
                
                if deviceToken != "" {
                    let details = PushModel(memberId: memberDetail.memberId ?? 0,
                                            deviceToken: deviceToken,
                                            deviceType: "Apple")
                    
                    pushViewModel.registerDeviceForPushNotification(deviceDetails: details)
                    observePushEvent()
                    
                } else {
                    
                }
                
                
                
            case .versionFatchedSuccessfully(versionInfo: let versionInfo):
                
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    
                    let server_version = Double(versionInfo.version ?? "")
                    print(server_version)

                    if let appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String {
                        let bundle_version = Double(appVersion) ?? 0.0
                        
                        if server_version ?? 0.0 > bundle_version {
//                            guard let url = URL(string: "https://apps.apple.com/us/app/hello-zentechinfo/id6474166725") else {
//                              return
//                            }
                            
                            guard let url = URL(string: versionInfo.platformUrl ?? "") else {
                              return
                            }
                            self.showUpdateAlert(url: url)
                        } else {
    //                        self?.callGetAllEmergencyNumbersAPI()
                        }
                    } else {
                       print("your platform does not support this feature.")
                    }
                }
                
            case .noVersionFound:
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                }
                
            case .bannerFetchedSuccessfully(data: let data):
                
                
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    if data.count > 0 {
                        self.viewBanner.isHidden = false
                        self.viewModel.BannerData = data
                        // Configure page control
                        self.pageControl.numberOfPages = self.viewModel.BannerData.count
                        self.pageControl.currentPage = 0
                        // Start auto-scrolling
                        self.startAutoScroll()
                        self.bannerCollectionView.reloadData()
                    } else {
                        self.viewBanner.isHidden = true
                    }
                }
            }
        }
    }
    
    func observePushEvent() {
        pushViewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                print("Data Loading")
            case .stopLoading:
                print("Data Stoped Loading")
            case .dataLoaded:
                print("Data Loaded")
            case .error(let error):
                print(error)
            case .registeredSuccessfully(response: let response):
                print(response)
            }
        }
    }
}

extension MenuVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.BannerData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let data = viewModel.BannerData[indexPath.row]
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BannerCell", for: indexPath) as! BannerCell
        cell.imgBanner.layer.cornerRadius = 20
                
        cell.imgBanner.sd_setImage(with: URL(string: data.image ?? "" ), placeholderImage: UIImage(named: "CircleProfileImage"))
        return cell
    }
        
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView.bounds.size
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        presentQRViewController(string: viewModel.BannerData[indexPath.row].image ?? "", forBanner: true)
    }
    
}
