//
//  QRPopUpVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 26/11/23.
//

import Foundation
import UIKit

class QRPopUpVC: UIViewController {
    
    @IBOutlet weak var imgQR: UIImageView!
    @IBOutlet weak var viewQR: UIView!
    
    var qrString = ""
    var forBanner = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if forBanner {
            imgQR.sd_setImage(with: URL(string: qrString), placeholderImage: UIImage(named: "CircleProfileImage"))

        } else {
            let qrImage = QRHelper.generateQRCode(from: qrString)
            imgQR.image = qrImage
        }
        
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        viewQR.layer.cornerRadius = 10
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tap)
    }
    
    @objc func handleTap() {
        self.dismiss(animated: true)
    }
}
