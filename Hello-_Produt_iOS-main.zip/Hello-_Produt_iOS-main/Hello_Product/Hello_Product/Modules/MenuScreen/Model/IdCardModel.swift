//
//  IdCardModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 28/02/24.
//

import Foundation
import UIKit

struct IdCardModel {
    var name: String?
    var designation: String?
    var image: String?
    var DOJ: String?
    var bloodGroup: String?
    var qrNumber: String?
    
    init(name: String, designation: String, image: String, DOJ: String, bloodGroup: String, qrNumber: String) {
        self.name = name
        self.designation = designation
        self.image = image
        self.DOJ = DOJ
        self.bloodGroup = bloodGroup
        self.qrNumber = qrNumber
    }
}
