//
//  MenuModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 13/12/23.
//

import Foundation

struct VersionInfoResponse: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [VersionInfo]?
}


struct BannerResponse: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [BannerDetails]?
}

struct BannerDetails: Codable {
    var id: Int?
    var siteId: Int?
    var siteName: String?
    var image: String?
    
    init(id: Int, siteId: Int, siteName: String, image: String) {
        self.id = id
        self.siteId = siteId
        self.siteName = siteName
        self.image = image
    }
    
    init() {
    }
}

struct VersionInfo: Codable {
    
    var version: String?
    var platformUrl: String?
    var platform: String?
    
    init(version: String, platformUrl: String, platform: String) {
        self.version = version
        self.platformUrl = platformUrl
        self.platform = platform
    }
    
    init() {}
}
