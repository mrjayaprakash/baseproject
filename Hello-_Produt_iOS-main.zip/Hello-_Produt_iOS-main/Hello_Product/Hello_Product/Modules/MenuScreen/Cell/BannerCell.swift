//
//  BannerCell.swift
//  Hello_Product
//
//  Created by Zentech-038 on 29/04/24.
//

import UIKit

class BannerCell: UICollectionViewCell {
    
    @IBOutlet weak var imgBanner: UIImageView!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
