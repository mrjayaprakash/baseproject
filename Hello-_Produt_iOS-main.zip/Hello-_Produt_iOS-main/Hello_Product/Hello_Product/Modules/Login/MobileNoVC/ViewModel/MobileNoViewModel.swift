//
//  MobileNoViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 17/11/23.
//

import Foundation

final class MobileNoViewModel {
    
    var eventHandler: ((_ event: Event) -> Void)?
    
    func varifyMobileNo(mobileNo: String) {
        
        self.eventHandler?(.loading)
        
        ApiManager.shared.request(
            modelType: AvailableStatus.self,
            type: LoginEndPoint.checkUserAvailable(mobileNo: mobileNo)) { result in
                switch result {
                    
                case .success(let status):
                    self.eventHandler?(.memberAvailable(status: status.status ?? false))
                case .failure(let error):
                    self.eventHandler?(.error(error))
                }
            }
    }
    
    
    func sendOTP(rendomOTP: String, mobileNo: String) {
        
        guard let url = URL(string: "https://sms.cell24x7.in/smsReceiver/sendSMS?user=zentech&pwd=apizentech&sender=ZTISPL&mobile=\(mobileNo)&msg=Your+login+OTP+is+\(rendomOTP)+Use+this+OTP+to+validate+your+login.+-Zentechinfo+Solutions+Private+Limited&mt=0") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.allHTTPHeaderFields = [
            "Content-Type": "application/json"
        ]
        
        URLSession.shared.dataTask(with: request) { Data, response, error in
            
            
//            //Data received.
//            guard let response = response as? HTTPURLResponse, error == nil else {
//                print("error", error ?? URLError(.badServerResponse))
//                return
//            }
//            
//            if response.statusCode == 200 {
//                print("HTTP Success")
//                print("OTP sent Successfully")
//                self.eventHandler?(.dataLoaded)
//            } else {
//                print("HTTP Error code = \(response.statusCode)")
//                self.eventHandler?(.error(error))
//                print("OTP Not Sent")
//                if response.statusCode == 401 {
//                    //self.logoutDueToTimeout()
//                }
//            }
            
            
            if error == nil {
                print("OTP sent Successfully")
                self.eventHandler?(.dataLoaded)
            } else {
                self.eventHandler?(.error(error))
                print("OTP Not Sent")
            }
        }.resume()
    }
}

extension MobileNoViewModel {

    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case memberAvailable(status: Bool)
    }

}
