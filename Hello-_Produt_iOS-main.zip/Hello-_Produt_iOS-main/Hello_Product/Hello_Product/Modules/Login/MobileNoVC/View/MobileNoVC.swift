//
//  MobileNoVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 12/11/23.
//

import Foundation
import UIKit

class MobileNoVc: UIViewController {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblPasswordLogin: UILabel!
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnZentech: UIButton!
    @IBOutlet weak var txtMobileNo: UITextField!
    @IBOutlet weak var btnSend: UIButton!
    
    private var viewModel = MobileNoViewModel()
//    var randomNum = arc4random_uniform(9000) + 1000
    var randomNum = 0000

    
    var forForgotPassword = false
    var mobileNo = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        observeEvent()
        navigationController?.isNavigationBarHidden = true
        addTapGesture()
        design()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        randomNum = Int(arc4random_uniform(9000) + 1000)
    }
    
    func design() {
        viewBackground.layer.cornerRadius = 50
        viewBackground.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        btnSend.layer.cornerRadius = 15
        lblTitle.text = "Hello!,\n\nEnter Your \nMobile number"
        lblTitle.numberOfLines = 4


        
        btnZentech.setTitle("", for: .normal)
    }
    
    @IBAction func btnSendTapped(_ sender: UIButton) {
        
        if txtMobileNo.text == "" {
            self.view.makeToast("Please enter Mobile number")
        } else {
            
            if !isValidIndianMobileNumber(txtMobileNo.text ?? "") {
                self.hideActivityIndicator()
                self.view.makeToast("Please enter valid Mobile number")
                return
            }
            self.showActivityIndicator()
            viewModel.varifyMobileNo(mobileNo: txtMobileNo.text ?? "")
        }
    }
    
    func addTapGesture() {
        
        lblPasswordLogin.isUserInteractionEnabled = true
        let passwordLoginTap = UITapGestureRecognizer(target: self, action: #selector(labelPasswordLoginTapped(_:)))
        lblPasswordLogin.addGestureRecognizer(passwordLoginTap)
    }
    
    @objc func labelPasswordLoginTapped(_ sender: UITapGestureRecognizer) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension MobileNoVc {
    
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                print("Data Loading")
            case .stopLoading:
                print("Data Stop Loading")
            case .dataLoaded:
                print("Data Loaded")
                DispatchQueue.main.async {
                    let storyboard = UIStoryboard(name: "Login", bundle: nil)
                    let vc = storyboard.instantiateViewController(withIdentifier: "EnterOtpVC") as! EnterOtpVC
                    vc.otpToMatch = Int(self.randomNum)
                    vc.mobileNo = self.mobileNo
                    vc.forForgotPassword = self.forForgotPassword
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                
            case .error(let error):
                print(error)
                
            case .memberAvailable(status: let status):
                if status == true {
                    DispatchQueue.main.async {
                        self.hideActivityIndicator()
                        
                        if self.txtMobileNo.text != "" {
                            self.mobileNo = self.txtMobileNo.text ?? ""
                            if self.forForgotPassword {
                                print("OTP Sent for Password Reset")
                                print("Random 4-digit number: \(self.randomNum)")
                                
                                self.viewModel.sendOTP(rendomOTP: String(self.randomNum), mobileNo: self.mobileNo)
                                
                                self.observeEvent()
                            } else {
                                print("Random 4-digit number: \(self.randomNum)")
                                
                                self.viewModel.sendOTP(rendomOTP: String(self.randomNum), mobileNo: self.mobileNo)
                                
                                self.observeEvent()
                            }
                        } else {
                            self.hideActivityIndicator()
                            self.view.makeToast("Please Enter Valid Mobile No.")
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        self.hideActivityIndicator()
                        self.view.makeToast("Mobile No Not registered")
                    }
                }
            }
        }
    }
}
