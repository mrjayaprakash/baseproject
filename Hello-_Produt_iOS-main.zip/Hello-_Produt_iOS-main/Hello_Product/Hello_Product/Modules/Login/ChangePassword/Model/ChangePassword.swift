//
//  ChangePassword.swift
//  Hello_Product
//
//  Created by Zentech-038 on 27/11/23.
//

import Foundation

struct ChangePassword: Codable {
    var password: String?
}

struct PasswordChangeResponse: Codable {
    var isSuccess: Bool?
    var message: String?
}
