//
//  ChangePasswordViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 25/11/23.
//

import Foundation
import UIKit


final class ChangePasswordViewModel {
    
    var eventHandler: ((_ event: Event) -> Void)?
    
    func changePassword(mobileNo: String, password: ChangePassword) {
        
        self.eventHandler?(.loading)
        ApiManager.shared.request(
            modelType: PasswordChangeResponse.self,
            type: LoginEndPoint.changePassword(mobileNo: mobileNo, password: password)) { result in
                switch result {
                case .success(let data):
                    self.eventHandler?(.passwordChangeSuccessful(changeStatus: data))
                case .failure(let error):
                    self.eventHandler?(.error(error))
                }
            }
    }
    
    
}

extension ChangePasswordViewModel {
    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case passwordChangeSuccessful(changeStatus: PasswordChangeResponse)
    }
}
