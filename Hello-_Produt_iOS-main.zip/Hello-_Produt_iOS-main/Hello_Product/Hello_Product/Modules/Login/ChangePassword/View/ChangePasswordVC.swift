//
//  ChangePasswordVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 16/11/23.
//

import Foundation
import UIKit

class ChangePasswordVC: UIViewController {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtConfirmPassword: UITextField!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnZentech: UIButton!
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnEye: UIButton!
    
    let viewModel = ChangePasswordViewModel()
    var mobileNo = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnLogin.layer.cornerRadius = 15
        
        lblTitle.text = "Hello!,\n\nChange Your \nPassword"
        lblTitle.numberOfLines = 4
        observeEvent()
        
        btnEye.setTitle("", for: .normal)
        btnEye.tintColor = .white
        
    }
    @IBAction func btnLoginTapped(_ sender: UIButton) {
        
        if txtPassword.text != "" && txtConfirmPassword.text != "" {
            if txtPassword.text == txtConfirmPassword.text {
                let Password = ChangePassword(password: txtPassword.text ?? "")
                viewModel.changePassword(mobileNo: mobileNo, password: Password)
            } else {
                self.view.makeToast("Password does not match")
            }
        } else {
            self.view.makeToast("Please fill both the fields")
        }
        
    }
    @IBAction func btnEyeTapped(_ sender: UIButton) {
        if txtPassword.isSecureTextEntry || txtConfirmPassword.isSecureTextEntry {
            txtPassword.isSecureTextEntry = false
            txtConfirmPassword.isSecureTextEntry = false
            btnEye.tintColor = .red
        } else {
            txtPassword.isSecureTextEntry = true
            txtConfirmPassword.isSecureTextEntry = true
            btnEye.tintColor = .white
        }
    }
}

extension ChangePasswordVC {
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
                
            case .loading:
                DispatchQueue.main.async {
                    self.showActivityIndicator()
                }
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Data Loaded")
            case .error(let error):
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    self.view.makeToast("Something went wrong, please try after sometime.")
                }
                print(error?.localizedDescription)
            case .passwordChangeSuccessful(changeStatus: let changeStatus):
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    
//                    self.view.makeToast(changeStatus.message)
                    
                    if changeStatus.isSuccess == true {
                        
                        self.view.makeToast(changeStatus.message)
                        let storyboard = UIStoryboard(name: "Login", bundle: nil) // Replace "Main" with your actual storyboard name
                        guard let loginViewController = storyboard.instantiateViewController(withIdentifier: "LoginVC") as? LoginVC else {
                            return // Ensure the view controller is created successfully
                        }
                            
                        // Reset navigation stack if using a navigation controller
                        if let navigationController = UIApplication.shared.keyWindow?.rootViewController as? UINavigationController {
                            navigationController.setViewControllers([loginViewController], animated: true)
                        } else {
                            // Set login view controller as the root view controller
                            if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
                                appDelegate.window?.rootViewController = loginViewController
                            }
                        }
                        
                    } else {
                        self.view.makeToast(changeStatus.message)
                        
                    }
                    
                }
            }
        }
    }
}
