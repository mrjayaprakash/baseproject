//
//  SignUpVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 06/11/23.
//

import Foundation
import UIKit

class SignUpVC: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
