//
//  LoginVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 06/11/23.
//

import UIKit
import JWTDecode
import MBProgressHUD

class LoginVC: UIViewController {
    
    @IBOutlet weak var ViewBackgroundLower: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var btnZentech: UIButton!
    @IBOutlet weak var lblForgotPassword: UILabel!
    @IBOutlet weak var lblOtpLogin: UILabel!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnEye: UIButton!
    
    private var viewModel = LoginViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        design()
        addTapGesture()
        
    }
    
    func addTapGesture() {
        
        lblForgotPassword.isUserInteractionEnabled = true
        let foegotPasswordTap = UITapGestureRecognizer(target: self, action: #selector(labelForgotPasswordTapped(_:)))
        lblForgotPassword.addGestureRecognizer(foegotPasswordTap)
        
        lblOtpLogin.isUserInteractionEnabled = true
        let otpTap = UITapGestureRecognizer(target: self, action: #selector(labelOtpTapped(_:)))
        lblOtpLogin.addGestureRecognizer(otpTap)
        
    }
    
    @objc func labelForgotPasswordTapped(_ sender: UITapGestureRecognizer) {
        
        let storyboard = UIStoryboard(name: "Login", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "MobileNoVc") as! MobileNoVc
        vc.forForgotPassword = true
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @objc func labelOtpTapped(_ sender: UITapGestureRecognizer) {
        
        let storyboard = UIStoryboard(name: "Login", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "MobileNoVc") as! MobileNoVc
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    @IBAction func btnLoginTapped(_ sender: UIButton) {
        
        self.showActivityIndicator()
        
        if txtUserName.text != "" && txtPassword.text != "" {
            
            let userName = txtUserName.text ?? ""
            let password = txtPassword.text ?? ""
            let logindetails = LoginDetailModel(userName: userName, password: password)
            
            viewModel.login(parameter: logindetails)
            observeEvent()
            
        } else {
            self.hideActivityIndicator()
            self.view.makeToast("Please fill all the fields")
        }
                
    }
    
    @IBAction func btnEyeTapped(_ sender: UIButton) {
        
        if txtPassword.isSecureTextEntry {
            txtPassword.isSecureTextEntry = false
            btnEye.tintColor = .red
        } else {
            txtPassword.isSecureTextEntry = true
            btnEye.tintColor = .white
        }
    }
    
    func design() {
        
        ViewBackgroundLower.layer.cornerRadius = 50
        ViewBackgroundLower.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
//        btnLogin.layer.cornerRadius = btnLogin.layer.frame.height / 2
        
        btnLogin.layer.cornerRadius = 15
        
        lblTitle.text = "Hello,\nWelcome!"
        lblTitle.numberOfLines = 2
        
        btnZentech.setTitle("", for: .normal)
        
        btnEye.tintColor = .white
        btnEye.setTitle("", for: .normal)


    }
}

extension LoginVC {
    
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                print("Data Loading")
//                self.showActivityIndicator()
                
            case .stopLoading:
                print("Data Stoped Loading")
                
            case .dataLoaded:
                print("Data Loaded")
                
            case .loginSuccessful(loginData: let loginData):
                
                UserDefaults.standard.setValue(loginData.token, forKey: Constants.loginTockenConstant)
                
//                let stored_jwt = loginData.token
                let stored_jwt = UserDefaults.standard.value(forKey: Constants.loginTockenConstant) as? String
                let jwt = try? decode(jwt: stored_jwt ?? "")
                
                if jwt != nil {
                    
                    DispatchQueue.main.async {
                        
                        self.hideActivityIndicator()
                                                
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc = storyboard.instantiateViewController(withIdentifier: "MenuVC") as! MenuVC

                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                } else {
                    DispatchQueue.main.async {
                        self.hideActivityIndicator()
                        self.view.makeToast("Invalid Password")
                        print("Problem in Logging In")
                    }
                }
                
            case .error(let error):
                print(error)
                self.hideActivityIndicator()

            }
        }
    }
}
