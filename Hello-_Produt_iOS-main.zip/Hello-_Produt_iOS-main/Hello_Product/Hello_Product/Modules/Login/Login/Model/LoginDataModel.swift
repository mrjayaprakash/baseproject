//
//  loginDataModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 17/11/23.
//

import Foundation
import UIKit

struct LoginDataModel : Codable {
    
    var isSuccess: Bool?
    var message: String?
    var token: String?
    
    init(isSuccess: Bool, message: String, token: String) {
        self.isSuccess = isSuccess
        self.message = message
        self.token = token
    }
    
    init() {}
    
}
