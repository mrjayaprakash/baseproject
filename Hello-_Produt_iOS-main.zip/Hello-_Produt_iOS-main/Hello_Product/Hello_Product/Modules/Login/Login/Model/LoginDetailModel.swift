//
//  LogindataModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 16/11/23.
//

import Foundation

struct LoginDetailModel : Codable {
    
    let userName: String?
    let password: String?
    
    init(userName: String?, password: String?) {
        self.userName = userName
        self.password = password
    }
}

struct AvailableStatus: Codable {
    var status: Bool?
}
