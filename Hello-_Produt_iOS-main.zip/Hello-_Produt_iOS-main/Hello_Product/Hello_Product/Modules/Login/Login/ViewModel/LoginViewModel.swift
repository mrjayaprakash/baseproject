//
//  LoginViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 16/11/23.
//

import Foundation

final class LoginViewModel {
    
    var loginData = LoginDataModel()
    var eventHandler: ((_ event: Event) -> Void)?
    
    func login(parameter: LoginDetailModel) {
        self.eventHandler?(.loading)
        ApiManager.shared.request(
            modelType: LoginDataModel.self, // response type
            type: LoginEndPoint.login(loginDetail: parameter)) { result in
                switch result {
                case .success(let loginData):
                    self.eventHandler?(.loginSuccessful(loginData: loginData))
                case .failure(let error):
                    self.eventHandler?(.error(error))
                }
            }
    }
}

extension LoginViewModel {

    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case loginSuccessful(loginData: LoginDataModel)
    }
}

