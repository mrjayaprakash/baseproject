//
//  EnterOtpVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 12/11/23.
//

import Foundation
import UIKit
import JWTDecode
import Toast_Swift

class EnterOtpVC: UIViewController {
    
    @IBOutlet weak var tf1: UITextField!
    @IBOutlet weak var tf2: UITextField!
    @IBOutlet weak var tf3: UITextField!
    @IBOutlet weak var tf4: UITextField!
    @IBOutlet weak var lblResend: UILabel!
    @IBOutlet weak var btnZentech: UIButton!
    @IBOutlet weak var btnVerify: UIButton!
    
    let viewModel = OTPViewModel()
    
    var mobileNo = ""
    var forForgotPassword = false
    
    var countdownTimer: Timer?
    var remainingTime: TimeInterval = 30.0
    
    var otpToMatch: Int = 0000
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnVerify.layer.cornerRadius = 15
        
        navigationController?.isNavigationBarHidden = false
        tf1.addTarget(self, action: #selector(self.textdidChange(textfield:)), for: UIControl.Event.editingChanged)
        tf2.addTarget(self, action: #selector(self.textdidChange(textfield:)), for: UIControl.Event.editingChanged)
        tf3.addTarget(self, action: #selector(self.textdidChange(textfield:)), for: UIControl.Event.editingChanged)
        tf4.addTarget(self, action: #selector(self.textdidChange(textfield:)), for: UIControl.Event.editingChanged)
        
        startCountdown()
        addTapGesture()
        
        btnZentech.setTitle("", for: .normal)

    }
    
    
    @IBAction func btnLoginTapped(_ sender: UIButton) {
        if tf1.text != "" && tf2.text != "" && tf3.text != "" && tf4.text != "" {
            let otpEntered = String("\(tf1.text ?? "")\(tf2.text ?? "")\(tf3.text ?? "")\(tf4.text ?? "")")
            print("otpEntered = \(otpEntered)")
            
            if String(self.otpToMatch) == otpEntered {
                
                if forForgotPassword == true {
                    let storyboard = UIStoryboard(name: "Login", bundle: nil)
                    let vc = storyboard.instantiateViewController(withIdentifier: "ChangePasswordVC") as! ChangePasswordVC
                    vc.mobileNo = self.mobileNo
                    navigationController?.pushViewController(vc, animated: true)
                } else {
                    
                    observeEvent()
                    viewModel.login(parameter: LoginDetailModel(userName: mobileNo, password: ""))
            
                }
            } else {
                DispatchQueue.main.async {
                    self.view.makeToast("Wrong OTP")
                }
            }
        } else {
            DispatchQueue.main.async {
                self.view.makeToast("Please Enter OTP!")
            }
        }
    }
    
    func addTapGesture() {
        
        let passwordLoginTap = UITapGestureRecognizer(target: self, action: #selector(lblResendTapped(_:)))
        lblResend.addGestureRecognizer(passwordLoginTap)
    }
    
    @objc func lblResendTapped(_ sender: UITapGestureRecognizer) {
        
        otpToMatch = Int(arc4random_uniform(9000) + 1000)
        
        viewModel.resendOTP(rendomOTP: String(otpToMatch), mobileNo: mobileNo)
        lblResend.isUserInteractionEnabled = false
        remainingTime = 30.0
        startCountdown()
        
        print("Resend otp")
    }
    
    func startCountdown() {
        // Schedule a timer to update the countdown label every second
        countdownTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateCountdown), userInfo: nil, repeats: true)
    }

    @objc func updateCountdown() {
        // Update the remaining time
        remainingTime -= 1.0

        // Check if the countdown has reached zero
        if remainingTime <= 0 {
            countdownTimer?.invalidate() // Stop the timer when the countdown reaches zero
                // Update the label text to "Resend OTP" when the countdown is over
            lblResend.text = "Resend OTP"
            lblResend.isUserInteractionEnabled = true
        } else {
            // Update the label with the new time
            updateLabel()
        }
    }
    
    func updateLabel() {
        // Format the remaining time and update the label
        let minutes = Int(remainingTime) / 60
        let seconds = Int(remainingTime) % 60
        let formattedTime = String(format: "Resend in %02d:%02d", minutes, seconds)
        lblResend.text = formattedTime
    }
}

extension EnterOtpVC {
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                print("Data Loading")
                self.showActivityIndicator()
                
            case .stopLoading:
                print("Data Stoped Loading")
                
            case .dataLoaded:
                print("Data Loaded")
                
            case .loginSuccessful(loginData: let loginData):
                
                UserDefaults.standard.setValue(loginData.token, forKey: Constants.loginTockenConstant)
                
                let stored_jwt = UserDefaults.standard.value(forKey: Constants.loginTockenConstant) as? String
                
                let jwt = try? decode(jwt: stored_jwt ?? "")
                
                if jwt != nil {
                    
                    DispatchQueue.main.async {
                        
                        self.hideActivityIndicator()
                                                
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc = storyboard.instantiateViewController(withIdentifier: "MenuVC") as! MenuVC
                        self.navigationController?.pushViewController(vc, animated: true)
                        
                    }
                } else {
                   print("Problem in Logging In")
                }
                
            case .error(let error):
                print(error)
                self.hideActivityIndicator()

            }
        }
    }
}


extension EnterOtpVC: UITextFieldDelegate {
    
    @objc func textdidChange(textfield: UITextField) {
        let text = textfield.text
        
        if text?.utf16.count == 1 {
            switch textfield {
            case tf1:
                tf2.becomeFirstResponder()
                break
            case tf2:
                tf3.becomeFirstResponder()
                break
            case tf3:
                tf4.becomeFirstResponder()
                break
            case tf4:
                tf4.resignFirstResponder()
                break
            default:
                break
            }
        }
    }
    
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//        
//        // Check if the new input will exceed the allowed length
//        let newLength = (textField.text ?? "").count + string.count - range.length
//        if newLength > 1 {
//            return false
//        }
//
//        return true
//    }
}
