//
//  OTPViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 26/11/23.
//

import Foundation

final class OTPViewModel {
    
    var eventHandler: ((_ event: Event) -> Void)?
    var loginData = LoginDataModel()
    
    func login(parameter: LoginDetailModel) {
        self.eventHandler?(.loading)
        ApiManager.shared.request(
            modelType: LoginDataModel.self, // response type
            type: LoginEndPoint.login(loginDetail: parameter)) { result in
                switch result {
                case .success(let loginData):
                    self.eventHandler?(.loginSuccessful(loginData: loginData))
                case .failure(let error):
                    self.eventHandler?(.error(error))
                }
            }

    }
    
    func resendOTP(rendomOTP: String, mobileNo: String) {
        
        guard let url = URL(string: "https://sms.cell24x7.in/smsReceiver/sendSMS?user=zentech&pwd=apizentech&sender=ZTISPL&mobile=\(mobileNo)&msg=Your+login+OTP+is+\(rendomOTP)+Use+this+OTP+to+validate+your+login.+-Zentechinfo+Solutions+Private+Limited&mt=0") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.allHTTPHeaderFields = [
            "Content-Type": "application/json"
        ]
        
        URLSession.shared.dataTask(with: request) { Data, response, error in
            if error == nil {
                print("OTP sent Successfully")
                self.eventHandler?(.dataLoaded)
            } else {
                self.eventHandler?(.error(error))
                print("OTP Not Sent")
            }
        }.resume()
    }
}

extension OTPViewModel {
    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case loginSuccessful(loginData: LoginDataModel)
    }
}
