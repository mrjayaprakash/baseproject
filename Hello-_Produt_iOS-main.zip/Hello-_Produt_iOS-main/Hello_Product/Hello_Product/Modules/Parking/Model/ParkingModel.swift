//
//  ParkingFloorDetail.swift
//  Hello_Product
//
//  Created by Zentech-038 on 27/02/24.
//

import Foundation

struct ParkingFloorDetail: Codable {
    
    var floorId: Int?
    var siteId: Int?
    var wingId: Int?
    var siteName: String?
    var wingName: String?
    var floorName: String?
    var floorType: String?
    var parking: [ParkingSpotDetail]
    
    init(floorId: Int, siteId: Int, wingId: Int, siteName: String, wingName: String, floorName: String, floorType: String, parking: [ParkingSpotDetail]) {
        
        self.floorId = floorId
        self.siteId = siteId
        self.wingId = wingId
        self.siteName = siteName
        self.wingName = wingName
        self.floorName = floorName
        self.floorType = floorType
        self.parking = parking
    }
}

struct ParkingSpotDetail: Codable {
    var parkingId: Int?
    var parkingName: String?
    var vehicleType: String?
    var status: Bool?
//    var status: String = "false"

    var bookingParkingId: [String]
    
    init(parkingId: Int, parkingName: String, vehicleType: String, status: Bool, bookingParkingId: [String]) {
        self.parkingId = parkingId
        self.parkingName = parkingName
        self.vehicleType = vehicleType
        self.status = status
        self.bookingParkingId = bookingParkingId
    }
    
}

struct ParkingResponse: Codable {
//    var isSuccess: Bool
    var message: String?
    var parkingfloor: [ParkingFloorDetail]
}

struct BookParkingResponse: Codable {
    var isSuccess: Bool?
    var message: String?
}


struct ParkingTime: Codable {
    var toDate: String?
    var fromDate: String?
    
//    "2024-03-15T09:32:01.049Z"
//    "2024-03-21T09:32:01.049Z"
    init(toDate: String, fromDate: String) {
        self.toDate = toDate
        self.fromDate = fromDate
    }
}


struct PostParkingDetailModel: Codable {
//    id": 0,
    var parkingId: Int?
    var mobileNumber: String?
    var ownerName: String?
    var vehicleNumber: String?
    var vehicleTypeId: Int?
    var createdBy: String?
    var isActiveId: Int?
    
    init(parkingId: Int, mobileNumber: String, ownerName: String, vehicleNumber: String, vehicleTypeId: Int, createdBy: String, isActiveId: Int) {
        
        self.parkingId = parkingId
        self.mobileNumber = mobileNumber
        self.ownerName = ownerName
        self.vehicleNumber = vehicleNumber
        self.vehicleTypeId = vehicleTypeId
        self.createdBy = createdBy
        self.isActiveId = isActiveId
    }
    
    init() {
        
    }
}

struct OccupiedParkingResponse: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [OccupiedParkingDetails]
}

struct ReleseParkingRespsonse: Codable {
    var isSuccess: Bool
    var message: String
}

struct OccupiedParkingDetails: Codable {
    var id: Int?
    var toDate: String?
    var fromDate: String?
    var mobileNumber: String?
    var personName: String?
    var vehicaleNumber: String?
    var floorId: Int?
    var floorName: String?
    var wingId: Int?
    var wingName: String?
    var siteId: Int?
    var siteName: String?
    var parkingNumber: String?
    var parkingId: Int?
    var bookingStatus: String?
    
    init(id: Int, toDate: String, fromDate: String, mobileNumber: String, vehicaleNumber: String, floorId: Int, floorName: String, wingId: Int, wingName: String, siteId: Int, siteName: String, parkingId: Int, bookingStatus: String) {
        self.id = id
        self.toDate = toDate
        self.fromDate = fromDate
        self.mobileNumber = mobileNumber
        self.vehicaleNumber = vehicaleNumber
        self.floorId = floorId
        self.floorName = floorName
        self.wingId = wingId
        self.wingName = wingName
        self.siteId = siteId
        self.siteName = siteName
        self.parkingId = parkingId
        self.bookingStatus = bookingStatus
    }
    
    init() {
        
    }
    
}

struct ParkingUnitResponse: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [ParkingUnitDetails]?
}


struct ParkingUnitDetails: Codable {
    var id: Int?
    var clientId: Int?
    var siteId: Int?
    var wingId: Int?
    var floorId: Int?
    var unitNumberId: Int?
    var siteName: String?
    var wingName: String?
    var floorName: String?
    var unitNumberName: String?
    var name: String?
    var accessStatus: String?
    var isActive: String?
    
    init(id: Int, clientId: Int, siteId: Int, wingId: Int, floorId: Int, unitNumberId: Int, siteName: String, wingName: String, floorName: String, unitNumberName: String, name: String, accessStatus: String, isActive: String) {
        self.id = id
        self.clientId = clientId
        self.siteId = siteId
        self.wingId = wingId
        self.floorId = floorId
        self.unitNumberId = unitNumberId
        self.siteName = siteName
        self.wingName = wingName
        self.floorName = floorName
        self.unitNumberName = unitNumberName
        self.name = name
        self.accessStatus = accessStatus
        self.isActive = isActive
    }
    
    init() {}
}
