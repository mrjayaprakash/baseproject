//
//  ParkingUnitCell.swift
//  Hello_Product
//
//  Created by Zentech-038 on 21/10/24.
//

import UIKit

class ParkingUnitCell: UITableViewCell {

    @IBOutlet weak var lblUnitNo: UILabel!
    @IBOutlet weak var lblUnitName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
