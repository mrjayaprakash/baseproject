//
//  AvailableParkingCell.swift
//  Hello_Product
//
//  Created by Zentech-038 on 22/10/24.
//

import UIKit

class AvailableParkingCell: UICollectionViewCell {
    
    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgCar: UIImageView!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
