//
//  ParkingFloorCell.swift
//  Hello_Product
//
//  Created by Zentech-038 on 20/02/24.
//

import UIKit

class ParkingFloorCell: UICollectionViewCell {
        
    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
