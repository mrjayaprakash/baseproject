//
//  BookingHistoryCell.swift
//  Hello_Product
//
//  Created by Zentech-038 on 22/02/24.
//

import UIKit

class BookingHistoryCell: UITableViewCell {

    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var lblSiteName: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblVehicalNo: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblDuration: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        innerView.layer.cornerRadius = 10
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
