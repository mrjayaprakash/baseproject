//
//  ParkingSpotCell.swift
//  Hello_Product
//
//  Created by Zentech-038 on 20/02/24.
//

import UIKit

class ParkingSpotCell: UICollectionViewCell {
    
    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgCar: UIImageView!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
