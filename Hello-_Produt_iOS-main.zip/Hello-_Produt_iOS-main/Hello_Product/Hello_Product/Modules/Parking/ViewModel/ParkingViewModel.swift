//
//  ParkingViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 27/02/24.
//

import Foundation

class ParkingViewModel {
    
    var eventHandler: ((_ event: Event) -> Void)?
    
    var ParkingDetails = [ParkingFloorDetail]()
    
//    var OccupiedParkingDetails = [OccupiedParkingDetails]
    
    func postParkingBookingDetail(details: PostParkingDetailModel) {
        ApiManager.shared.request(modelType: BookParkingResponse.self,
                                  type: ParkingEndPoint.postParkingBookingDetail(detail: details)) { result in
            switch result {
                
            case .success(let data):
                print(data)
                self.eventHandler?(.bookedSuccessfully(response: data))
            case .failure(let error):
                
                self.eventHandler?(.error(error))
                print("Error")
            }
        }
    }
    
    func getParkingDetails(siteId: String) {
        
        ApiManager.shared.request(modelType: ParkingResponse.self,
                                  type: ParkingEndPoint.getAllParking(siteID: siteId)) { result in
            
            switch result {
                
            case .success(let data):
                print(data)
                self.eventHandler?(.dataFatchedSuccessfully(response: data))
                
            case .failure(let error):
                self.eventHandler?(.error(error))
                print(error)
            }
        }
    }
    
    func getParkingDetailsForOpenParking(siteId: String) {
        
        ApiManager.shared.request(modelType: ParkingResponse.self,
                                  type: ParkingEndPoint.getAllOpenParking(siteID: siteId)) { result in
            
            switch result {
                
            case .success(let data):
                print(data)
                self.eventHandler?(.dataFatchedSuccessfully(response: data))
                
            case .failure(let error):
                self.eventHandler?(.error(error))
                print(error)
            }
        }
    }
    
    func getParkingDetails(unitId: String) {
        
        ApiManager.shared.request(modelType: ParkingResponse.self,
                                  type: ParkingEndPoint.getAllParkingbyUnit(unitID: unitId)) { result in
            
            switch result {
                
            case .success(let data):
                print(data)
                self.eventHandler?(.dataFatchedSuccessfully(response: data))
                
            case .failure(let error):
                self.eventHandler?(.error(error))
                print(error)
            }
        }
    }
    
    func getOccupiedParkingDetails() {
        ApiManager.shared.request(modelType: OccupiedParkingResponse.self,
                                  type: ParkingEndPoint.getOccupiedParkingDetails) { result in
            switch result {
                
            case .success(let data):
                self.eventHandler?(.occupiedBookingDataFetchedSuccessfully(response: data.data))
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
    }
    
    func ReleaseParkingSlot(id: String) {
        ApiManager.shared.request(modelType: ReleseParkingRespsonse.self,
                                  type: ParkingEndPoint.ReleaseSlot(id: id)) { result in
            switch result {
                
            case .success(let data):
                self.eventHandler?(.successfullyReleased(response: data))
                
            case .failure(let error):
                self.eventHandler?(.error(error))

            }
        }
    }
    
    func fetchParkingUnit() {
        self.eventHandler?(.loading)
        
        ApiManager.shared.request(modelType: ParkingUnitResponse.self,
                                  type: ManageUsersEndPoint.getAllUnits) { result in
            switch result {
            case .success(let data):
                self.eventHandler?(.parkingUnitsFetchedSuccessfully(data: data.data ?? []))

            case .failure(let error):
                self.eventHandler?(.error(error))
                
            }
        }
    }
    
}

extension ParkingViewModel {
    
    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case dataFatchedSuccessfully(response: ParkingResponse)
        case bookedSuccessfully(response: BookParkingResponse)
        case occupiedBookingDataFetchedSuccessfully(response: [OccupiedParkingDetails])
        case error(Error?)
        case successfullyReleased(response: ReleseParkingRespsonse)
        case parkingUnitsFetchedSuccessfully(data: [ParkingUnitDetails])
        
    }
    
}
