//
//  ParkingHistoryVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 22/02/24.
//

import Foundation
import UIKit

class ParkingHistoryVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    let viewModel = ParkingViewModel()
    
    var parkingArray = [OccupiedParkingDetails]()
    
    var FilteredArray = [OccupiedParkingDetails]()
            
    var searching = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        FilteredArray = parkingArray
        
        searchBar.delegate = self
        
        btnBack.setTitle("", for: .normal)
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "BookingHistoryCell", bundle: nil), forCellReuseIdentifier: "BookingHistoryCell")
        tableView.separatorStyle = .none
        tableView.bounces = false
        
        self.showActivityIndicator()
        
        viewModel.getOccupiedParkingDetails()
        observeEvent()
    }
    
    func getTimeFromDateString(_ dateString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        if let date = dateFormatter.date(from: dateString) {
            dateFormatter.dateFormat = "HH:mm a"
            return dateFormatter.string(from: date)
        } else {
            return nil
        }
    }
    
    func calculateDuration(from fromDateString: String, to toDateString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        // Convert the input strings to Date objects
        guard let fromDate = dateFormatter.date(from: fromDateString),
              let toDate = dateFormatter.date(from: toDateString) else {
            return nil
        }
        
        let calendar = Calendar.current
        
        // Calculate the difference between the dates
        let components = calendar.dateComponents([.hour, .minute], from: fromDate, to: toDate)
        
        // Get hours and minutes
        let hours = components.hour ?? 0
        let minutes = components.minute ?? 0
        
        // Construct the duration string
        var durationString = ""
        if hours > 0 {
            durationString += "\(hours) hour\(hours > 1 ? "s" : "") "
        }
        durationString += "\(minutes % 60) minute\(minutes % 60 > 1 ? "s" : "")"
        
        return durationString.trimmingCharacters(in: .whitespaces)
    }
    
    func calculateDurationFromPast(from pastTimeString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        // Convert the input string to a Date object
        guard let pastDate = dateFormatter.date(from: pastTimeString) else {
            return nil
        }
        
        let currentDate = Date()
        let calendar = Calendar.current
        
        // Calculate the difference between the dates
        let components = calendar.dateComponents([.hour, .minute], from: pastDate, to: currentDate)
        
        // Get hours and minutes
        let hours = components.hour ?? 0
        let minutes = components.minute ?? 0
        
        // Adjust for the minimum duration of 15 minutes
        let totalMinutes = (hours * 60) + minutes
        if totalMinutes < 15 {
            return "0 hours 15 minutes"
        }
        
        // Construct the duration string
        var durationString = ""
        if hours > 0 {
            durationString += "\(hours) hour\(hours > 1 ? "s" : "") "
        }
        durationString += "\(minutes % 60) minute\(minutes % 60 > 1 ? "s" : "")"
        
        return durationString.trimmingCharacters(in: .whitespaces)
    }
    
    func filterOccupiedParkingDetails(bySiteId siteId: Int, in details: [OccupiedParkingDetails]) -> [OccupiedParkingDetails] {
        return details.filter { $0.siteId == siteId }
    }

    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
}

extension ParkingHistoryVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return parkingArray.count
        return FilteredArray.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
//        let data = parkingArray[indexPath.row]
        let data = FilteredArray[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "BookingHistoryCell", for: indexPath) as! BookingHistoryCell
        
        cell.lblDate.text = getTimeFromDateString(data.fromDate ?? "")
        cell.lblVehicalNo.text = data.vehicaleNumber
        cell.lblSiteName.text = data.siteName
        cell.lblName.text = data.personName
        cell.lblPrice.text = ""
        
        
        if data.bookingStatus == "Occupied" {
            cell.lblDuration.text = calculateDurationFromPast(from: data.fromDate ?? "")
            cell.lblStatus.text = "Occupied"
            cell.lblStatus.textColor = ColorConstants.OccupiedBooking

        } else {
            cell.lblDuration.text = calculateDuration(from: data.fromDate ?? "", to: data.toDate ?? "")
            cell.lblStatus.text = "Released"
            cell.lblStatus.textColor = ColorConstants.CanceledBooking
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let data = parkingArray[indexPath.row]
        let data = FilteredArray[indexPath.row]
        
        let storyboard = UIStoryboard(name: "PMS", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "ParkingTicketVC") as! ParkingTicketVC
        
        vc.parkingDetails = data
        
        self.navigationController?.pushViewController(vc, animated: true)

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    
}

extension ParkingHistoryVC {
    func observeEvent() {
        
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Loaded")
            case .error(let error):
                self.hideActivityIndicator()
                print("Error In Api Call :- \(error)")
            case .dataFatchedSuccessfully(response: let response):
                print("Data fetched")
                print(response)
                
            case .bookedSuccessfully(response: let response):
                print(response)

            case .occupiedBookingDataFetchedSuccessfully(response: let response):
                
                print(response)
                
                DispatchQueue.main.async {
                    
                    let filteredDetails = self.filterOccupiedParkingDetails(bySiteId: GlobalConstants.loggedInMemberDetails.siteId ?? 0, in: response)
                    
                    self.parkingArray = filteredDetails
                    self.FilteredArray = self.parkingArray
                    self.hideActivityIndicator()
                    self.tableView.reloadData()
                }

            case .successfullyReleased(response: let response):
                print(response)

            case .parkingUnitsFetchedSuccessfully(data: let data):
                print(data)
            }
        }
    }
}

extension ParkingHistoryVC: UISearchBarDelegate {
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searching = false
        searchBar.text = ""
        tableView.reloadData()
        searchBar.setShowsCancelButton(false, animated: true)
        self.view.endEditing(true)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
//        FilteredArray = searchText.isEmpty ? parkingArray : parkingArray.filter { $0.vehicaleNumber?.localizedCaseInsensitiveContains(searchText) ?? false }
        let searchText = searchText.lowercased()
        
        FilteredArray = searchText.isEmpty ? parkingArray : parkingArray.filter {
            // Convert vehicaleNumber to lowercase and check if it contains the lowercase search text
            
            ($0.personName?.lowercased().contains(searchText) ?? false) || ($0.vehicaleNumber?.lowercased().contains(searchText) ?? false)
        }
        
        searching = true
        tableView.reloadData()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.view.endEditing(true)
    }
}
