//
//  BookParkingPopupVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 09/04/24.
//

import Foundation
import UIKit

class BookParkingPopupVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnBook: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    
    @IBOutlet weak var lblParkingId: UILabel!
    @IBOutlet weak var lblParkingName: UILabel!
    @IBOutlet weak var lblParkingType: UILabel!
    @IBOutlet weak var lblVehicalNo: UILabel!
    
    @IBOutlet weak var viewContentVehicleNo: UIView!
    
    var parkingDetails = ParkingSpotDetail(parkingId: 0,
                                           parkingName: "",
                                           vehicleType: "",
                                           status: false,
                                           bookingParkingId: [])
    
    var postParkingDetails = PostParkingDetailModel(parkingId: 0,
                                                    mobileNumber: "",
                                                    ownerName: "",
                                                    vehicleNumber: "",
                                                    vehicleTypeId: 1,
                                                    createdBy: "",
                                                    isActiveId: 1)
    
    
    var parkingId: Int?
    var mobileNumber: String?
    var ownerName: String?
    var vehicleNumber: String?
    
    let viewModel = ParkingViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Design()
    }
    
    func Design() {
                
        viewContentVehicleNo.isHidden = true
        
        viewBackground.layer.cornerRadius = 20
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        btnBook.layer.cornerRadius = 5
        btnCancel.layer.cornerRadius = 5
        
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        lblParkingId.text = String(parkingDetails.parkingId ?? 0)
        lblParkingName.text = parkingDetails.parkingName
        lblParkingType.text = parkingDetails.vehicleType
    }
    
    @IBAction func btnBookTapped(_ sender: UIButton) {
        
        viewModel.postParkingBookingDetail(details: postParkingDetails)
        observeEvent()
        
//        let storyboard = UIStoryboard(name: "PMS", bundle: nil)
//        let vc = storyboard.instantiateViewController(withIdentifier: "BookParkingVC") as! BookParkingVC
//        vc.parkingID = parkingDetails.parkingId ?? 0
//        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func btnCancelTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension BookParkingPopupVC {
    func observeEvent() {
        
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Loaded")
            case .error(let error):
                self.hideActivityIndicator()
                print("Error In Api Call :- \(error)")
            case .dataFatchedSuccessfully(response: let response):
                print("Data fetched")
                print(response)
            case .bookedSuccessfully(response: let response):
                print(response)
                
                DispatchQueue.main.async {
                    if response.isSuccess == true {
                        self.navigationController?.popToRootViewController(animated: true)
                    } else {
                        self.view.makeToast(response.message)
                    }
                }
            case .occupiedBookingDataFetchedSuccessfully(response: let response):
                print(response)
            case .successfullyReleased(response: let response):
                print(response)

            case .parkingUnitsFetchedSuccessfully(data: let data):
                print(data)
            }
            
        }
    }
}
