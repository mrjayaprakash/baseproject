//
//  ParkingTicketVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 21/02/24.
//

import Foundation
import UIKit

class ParkingTicketVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var viewTicket: UIView!
    @IBOutlet weak var viewQR: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var imgQR: UIImageView!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblVehicleNo: UILabel!
    @IBOutlet weak var lblParkingArea: UILabel!
    @IBOutlet weak var lblParkingSlot: UILabel!
    @IBOutlet weak var lblDuration: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblMobileNo: UILabel!
    
    @IBOutlet weak var viewReleaseSlot: UIView!
    @IBOutlet weak var btnReleaseSlot: UIButton!
    
    let viewModel = ParkingViewModel()
//    var vehicalNo = ""
    var parkingDetails = OccupiedParkingDetails()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        let qrImage = QRHelper.generateQRCode(from: String(parkingDetails.id ?? 0))
        imgQR.image = qrImage
        
        Design()
        LoadData()
    }
    
    func getTimeFromDateString(_ dateString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        if let date = dateFormatter.date(from: dateString) {
            dateFormatter.dateFormat = "HH:mm a"
            return dateFormatter.string(from: date)
        } else {
            return nil
        }
    }
    
    
    func getDateFromDateString(_ dateString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        if let date = dateFormatter.date(from: dateString) {
            dateFormatter.dateFormat = "dd-MM-yyyy"
            return dateFormatter.string(from: date)
        } else {
            return nil
        }
    }
    
    func LoadData() {
        lblName.text = parkingDetails.personName
        lblVehicleNo.text = parkingDetails.vehicaleNumber
        lblParkingArea.text = parkingDetails.floorName
        lblParkingSlot.text = parkingDetails.parkingNumber
        lblTime.text = getTimeFromDateString(parkingDetails.fromDate ?? "")
        lblDate.text = getDateFromDateString(parkingDetails.fromDate ?? "")
        lblMobileNo.text = parkingDetails.mobileNumber
        
        if parkingDetails.bookingStatus == "Occupied" {
            lblDuration.text = calculateDurationFromPast(from: parkingDetails.fromDate ?? "")
        } else {
            lblDuration.text = calculateDuration(from: parkingDetails.fromDate ?? "", to: parkingDetails.toDate ?? "")
        }
    }
    
    func calculateDuration(from fromDateString: String, to toDateString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        // Convert the input strings to Date objects
        guard let fromDate = dateFormatter.date(from: fromDateString),
              let toDate = dateFormatter.date(from: toDateString) else {
            return nil
        }
        
        let calendar = Calendar.current
        
        // Calculate the difference between the dates
        let components = calendar.dateComponents([.hour, .minute], from: fromDate, to: toDate)
        
        // Get hours and minutes
        let hours = components.hour ?? 0
        let minutes = components.minute ?? 0
        
        // Construct the duration string
        var durationString = ""
        if hours > 0 {
            durationString += "\(hours) hour\(hours > 1 ? "s" : "") "
        }
        durationString += "\(minutes % 60) minute\(minutes % 60 > 1 ? "s" : "")"
        
        return durationString.trimmingCharacters(in: .whitespaces)
    }
    
    func calculateDurationFromPast(from pastTimeString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        // Convert the input string to a Date object
        guard let pastDate = dateFormatter.date(from: pastTimeString) else {
            return nil
        }
        
        let currentDate = Date()
        let calendar = Calendar.current
        
        // Calculate the difference between the dates
        let components = calendar.dateComponents([.hour, .minute], from: pastDate, to: currentDate)
        
        // Get hours and minutes
        let hours = components.hour ?? 0
        let minutes = components.minute ?? 0
        
        // Adjust for the minimum duration of 15 minutes
        let totalMinutes = (hours * 60) + minutes
        if totalMinutes < 15 {
            return "0 hours 15 minutes"
        }
        
        // Construct the duration string
        var durationString = ""
        if hours > 0 {
            durationString += "\(hours) hour\(hours > 1 ? "s" : "") "
        }
        durationString += "\(minutes % 60) minute\(minutes % 60 > 1 ? "s" : "")"
        
        return durationString.trimmingCharacters(in: .whitespaces)
    }
    
    @IBAction func btnReleaseSlotTapped(_ sender: UIButton) {
        
        viewModel.ReleaseParkingSlot(id: String(parkingDetails.id ?? 0))
        observeEvent()
    }
    
    func Design() {
        
        viewTicket.layer.cornerRadius = 10
        viewQR.layer.cornerRadius = 8
        
        btnBack.setTitle("", for: .normal)
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        if parkingDetails.bookingStatus == "Occupied" {
            viewReleaseSlot.isHidden = false
        } else {
            viewReleaseSlot.isHidden = true
        }
    }
    
    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension ParkingTicketVC {
    func observeEvent() {
        
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Loaded")
            case .error(let error):
                self.hideActivityIndicator()
                print("Error In Api Call :- \(error)")
            case .dataFatchedSuccessfully(response: let response):
                print("Data fetched")
                print(response)
                
            case .bookedSuccessfully(response: let response):
                print(response)

            case .occupiedBookingDataFetchedSuccessfully(response: let response):
                print(response)

            case .successfullyReleased(response: let response):
                
                DispatchQueue.main.async {
                    if response.isSuccess ?? false {
                        self.view.makeToast("Released Successfully")
                        
                        self.navigationController?.popToRootViewController(animated: true)
                    } else {
                        self.view.makeToast("Something Went Wrong")

                    }
                }
            case .parkingUnitsFetchedSuccessfully(data: let data):
                print(data)
            }
        }
    }
}
