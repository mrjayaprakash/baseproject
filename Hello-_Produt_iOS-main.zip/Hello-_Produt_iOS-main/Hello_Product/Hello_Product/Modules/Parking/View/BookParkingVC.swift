//
//  BookParkingVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 11/04/24.
//

import Foundation
import UIKit

class BookParkingVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var viewContentName: UIView!
    @IBOutlet weak var viewContentVehicleNo: UIView!
    @IBOutlet weak var viewContentMobileNo: UIView!
    @IBOutlet weak var btnBook: UIButton!
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtVehicleNo: UITextField!
    @IBOutlet weak var txtMobileNo: UITextField!
    
    @IBOutlet weak var btnMinus: UIButton!
    @IBOutlet weak var btnPlus: UIButton!
    @IBOutlet weak var lblHours: UILabel!
    
    let viewModel = ParkingViewModel()
    var parkingID = 0
    
    var Hours: Int = 1
//    var ParkingDetails = ParkingSpotDetail(parkingId: 0,
//                                           parkingName: "",
//                                           vehicleType: "",
//                                           status: true,
//                                           bookingParkingId: [])
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Design()
    }
    
    
    func Design() {
        viewBackground.layer.cornerRadius = 20
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        btnBack.setTitle("", for: .normal)
        btnBook.layer.cornerRadius = 5
        
        btnMinus.setTitle("", for: .normal)
        btnPlus.setTitle("", for: .normal)

        btnMinus.layer.cornerRadius = 5
        btnPlus.layer.cornerRadius = 5
        
        lblHours.text = String(Hours)

    }
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnMinusTapped(_ sender: UIButton) {
        if Hours <= 1 {
            self.view.makeToast("Should be booked for at least 1 hour.")
        } else {
            Hours = Hours - 1
        }
        lblHours.text = String(Hours)
    }
    
    @IBAction func btnPlusTapped(_ sender: UIButton) {
        Hours = Hours + 1
        lblHours.text = String(Hours)
    }
    
    @IBAction func btnNextTapped(_ sender: UIButton) {
        
        if txtName.text != "" && txtMobileNo.text != "" && txtVehicleNo.text != "" {
            
            if parkingID != 0 {
                let details = PostParkingDetailModel(parkingId: parkingID,
                                                     mobileNumber: txtMobileNo.text ?? "",
                                                     ownerName: txtName.text ?? "",
                                                     vehicleNumber: txtVehicleNo.text ?? "",
                                                     vehicleTypeId: 1,
                                                     createdBy: String(GlobalConstants.loggedInMemberDetails.memberId ?? 0),
                                                     isActiveId: 1)
                
                viewModel.postParkingBookingDetail(details: details)
                self.observeEvent()
            } else {
                self.view.makeToast("Something went wrong, Please try again")
            }
            
        } else {
            self.view.makeToast("Please fill all the fields")
        }
    }
}

extension BookParkingVC {
    func observeEvent() {
        
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Loaded")
            case .error(let error):
                self.hideActivityIndicator()
                print("Error In Api Call :- \(error)")
            case .dataFatchedSuccessfully(response: let response):
                print("Data fetched")
                print(response)
                
            case .bookedSuccessfully(response: let response):
                print(response)

            case .occupiedBookingDataFetchedSuccessfully(response: let response):
                print(response)

            case .successfullyReleased(response: let response):
                print(response)

            case .parkingUnitsFetchedSuccessfully(data: let data):
                print(data)
            }
        }
    }
}
