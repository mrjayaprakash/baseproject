//
//  ParkingDetailsVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 21/02/24.
//

import Foundation
import UIKit

class ParkingDetailsVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var viewTextFullName: UIView!
    @IBOutlet weak var viewTextVehicalNumber: UIView!
    @IBOutlet weak var viewTextMobileNo: UIView!
    @IBOutlet weak var viewTextCurrentTime: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var viewSelectTime: UIView!
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtVehicalNo: UITextField!
    @IBOutlet weak var txtMobileNo: UITextField!
    var CurrentTimeChecked = true
    @IBOutlet weak var txtSelectedTime: UITextField!
    
    
    @IBOutlet weak var imgCheckBoxCurrentTime: UIImageView!
    @IBOutlet weak var btnNext: UIButton!
    
    var parkingDetails = ParkingSpotDetail(parkingId: 0,
                                           parkingName: "",
                                           vehicleType: "",
                                           status: false,
                                           bookingParkingId: [])
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgCheckBoxCurrentTime.isUserInteractionEnabled = true
        
        let tapImgRadioCurrentTime = UITapGestureRecognizer(target: self, action: #selector(didTapimgRadioCurrentTime(_:)))
        imgCheckBoxCurrentTime.addGestureRecognizer(tapImgRadioCurrentTime)
        
        Design()
        
        CurrentTimeChecked = true
        imgCheckBoxCurrentTime.image = UIImage(named: "radio_Checked")
        viewSelectTime.isHidden = true
        
    }
    
    @objc private func didTapimgRadioCurrentTime(_ sender: UITapGestureRecognizer) {
        CheckBoxClicked()
    }
    
    func CheckBoxClicked() {
        if CurrentTimeChecked == false {
            CurrentTimeChecked = true
            imgCheckBoxCurrentTime.image = UIImage(named: "radio_Checked")
            viewSelectTime.isHidden = true

        } else {
            CurrentTimeChecked = false
            imgCheckBoxCurrentTime.image = UIImage(named: "radio-unchacked")
            viewSelectTime.isHidden = false
        }
    }
    
    @IBAction func btnNextTapped(_ sender: UIButton) {
        
        if txtName.text != "" || txtMobileNo.text != "" || txtVehicalNo.text != "" {
            let storyboard = UIStoryboard(name: "PMS", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "BookParkingPopupVC") as! BookParkingPopupVC
            
            vc.parkingDetails = self.parkingDetails
            vc.postParkingDetails = PostParkingDetailModel(parkingId: parkingDetails.parkingId ?? 0,
                                                           mobileNumber: txtMobileNo.text ?? "",
                                                           ownerName: txtName.text ?? "",
                                                           vehicleNumber: txtVehicalNo.text ?? "",
                                                           vehicleTypeId: 1,
                                                           createdBy: String(GlobalConstants.loggedInMemberDetails.memberId ?? 0),
                                                           isActiveId: 1)
                        
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            self.view.makeToast("Please fill all the fields properly")
        }
        
//        if txtName.text != "" || txtMobileNo.text != "" || txtVehicalNo.text != "" {
//            let storyboard = UIStoryboard(name: "PMS", bundle: nil)
//            let vc = storyboard.instantiateViewController(withIdentifier: "AvailableParkingsVC") as! AvailableParkingsVC
//            vc.unitID = unitID
//            self.navigationController?.pushViewController(vc, animated: true)
//        } else {
//            self.view.makeToast("Please fill all the fields properly")
//        }
    }
    
    func Design() {
        
        viewTextFullName.layer.cornerRadius = 5
        viewTextFullName.layer.borderWidth = 1
        viewTextFullName.layer.borderColor = UIColor.lightGray.cgColor
        
        viewTextVehicalNumber.layer.cornerRadius = 5
        viewTextVehicalNumber.layer.borderWidth = 1
        viewTextVehicalNumber.layer.borderColor = UIColor.lightGray.cgColor
        
        viewTextMobileNo.layer.cornerRadius = 5
        viewTextMobileNo.layer.borderWidth = 1
        viewTextMobileNo.layer.borderColor = UIColor.lightGray.cgColor
        
        viewTextCurrentTime.layer.cornerRadius = 5
        viewTextCurrentTime.layer.borderWidth = 1
        viewTextCurrentTime.layer.borderColor = UIColor.lightGray.cgColor
        
        btnBack.setTitle("", for: .normal)
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        btnNext.layer.cornerRadius = 10
        
    }
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
}
