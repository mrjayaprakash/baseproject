//
//  ParkingMenuVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 22/02/24.
//

import Foundation
import UIKit

class ParkingMenuVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnBack: UIButton!
    
    @IBOutlet weak var viewBookingHistory: UIView!
    @IBOutlet weak var viewBookforself: UIView!
    @IBOutlet weak var viewBookforothers: UIView!
    
    @IBOutlet weak var btnBookingHistory: UIButton!
    @IBOutlet weak var btnBookforself: UIButton!
    @IBOutlet weak var btnBookforothers: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Design()
        
    }
    
    func Design() {
        
        btnBookingHistory.setTitle("", for: .normal)
        btnBookforself.setTitle("", for: .normal)
        btnBookforothers.setTitle("", for: .normal)
        
        btnBack.setTitle("", for: .normal)
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        viewBookingHistory.layer.cornerRadius = 20
        viewBookforself.layer.cornerRadius = 20
        viewBookforothers.layer.cornerRadius = 20
        
    }
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    @IBAction func btnBookingHistoryTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "PMS", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ParkingHistoryVC") as! ParkingHistoryVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnBookforUnitTapped(_ sender: UIButton) {
        
        let storyboard = UIStoryboard(name: "PMS", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "SelectParkingUnitVC") as! SelectParkingUnitVC

        self.navigationController?.pushViewController(vc, animated: true)
        
        
        
//        let storyboard = UIStoryboard(name: "PMS", bundle: nil)
//        let vc = storyboard.instantiateViewController(withIdentifier: "AllParkingVC") as! AllParkingVC
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnOpenBookingTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "PMS", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "AllParkingVC") as! AllParkingVC
        vc.bookOpenSlot = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
