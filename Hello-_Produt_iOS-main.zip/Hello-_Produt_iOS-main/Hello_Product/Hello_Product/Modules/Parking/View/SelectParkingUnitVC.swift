//
//  SelectParkingUnitVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 21/10/24.
//

import Foundation
import UIKit

class SelectParkingUnitVC: UIViewController {
    
    let viewModel = ParkingViewModel()
    
    var FilteredArray = [ParkingUnitDetails]()
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var btnBack: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnBack.setTitle("", for: .normal)
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "ParkingUnitCell", bundle: nil), forCellReuseIdentifier: "ParkingUnitCell")
        tableView.separatorStyle = .none
        tableView.bounces = false
        
        self.showActivityIndicator()
        
        
        viewModel.fetchParkingUnit()
        observeEvent()
    }
    
    @IBAction func btnBackTapped(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    
    func filterOccupiedParkingDetails(bySiteId siteId: Int, in details: [ParkingUnitDetails]) -> [ParkingUnitDetails] {
        return details.filter { $0.siteId == siteId }
    }
    
}

extension SelectParkingUnitVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return FilteredArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let data = FilteredArray[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ParkingUnitCell", for: indexPath) as! ParkingUnitCell
        
        cell.lblUnitNo.text = data.unitNumberName
        cell.lblUnitName.text = data.name
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let data = FilteredArray[indexPath.row]
        
        let storyboard = UIStoryboard(name: "PMS", bundle: nil)
        
//        let vc = storyboard.instantiateViewController(withIdentifier: "AvailableParkingsVC") as! AvailableParkingsVC
        
        let vc = storyboard.instantiateViewController(withIdentifier: "AllParkingVC") as! AllParkingVC
        
        vc.unitID = String(data.id ?? 0)
        
        self.navigationController?.pushViewController(vc, animated: true)

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}

extension SelectParkingUnitVC {
    func observeEvent() {
        
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Loaded")
            case .error(let error):
                self.hideActivityIndicator()
                print("Error In Api Call :- \(error)")
            case .dataFatchedSuccessfully(response: let response):
                print(response)
                
            case .bookedSuccessfully(response: let response):
                print(response)

            case .occupiedBookingDataFetchedSuccessfully(response: let response):
                print(response)

            case .successfullyReleased(response: let response):
                print(response)

            case .parkingUnitsFetchedSuccessfully(data: let data):
                DispatchQueue.main.async {
                    
                    if data.count != 0 {
                        self.FilteredArray = self.filterOccupiedParkingDetails(bySiteId: GlobalConstants.loggedInMemberDetails.siteId ?? 0, in: data)
                        
                        self.hideActivityIndicator()
                        self.tableView.reloadData()
                        print(data)
                    } else {
                        print("No Data Found")
                    }
                }
            }
        }
    }
}
