//
//  AvailableParkingsVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 22/10/24.
//

import Foundation
import UIKit

class AvailableParkingsVC: UIViewController {
    
    var unitID = ""
    var parkingForUnit = true
    let viewModel = ParkingViewModel()
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
