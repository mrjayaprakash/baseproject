//
//  AllParkingVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 20/02/24.
//

import Foundation
import UIKit

class AllParkingVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var parkingSpotCollectionView: UICollectionView!
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var viewParkingFloor: UIView!
    @IBOutlet weak var viewParkingSlot: UIView!
    
//    var parkingSpots = [ParkingSpotDetail]()
    
//    var selectedIndex: Int?
    var selectedIndex: Int? {
        didSet {
//            lblTitle.text = viewModel.ParkingDetails[selectedIndex ?? 0].wingName
            collectionView.reloadData() // Reload collection view when selection changes
        }
    }
    
    var selectedFloor: ParkingFloorDetail? {
        didSet {
            DispatchQueue.main.async {
                self.lblTitle.text = self.selectedFloor?.floorName
                self.parkingSpotCollectionView.reloadData() // Reload collection view when selection changes
            }
        }
    }

    let viewModel = ParkingViewModel()
    
    var unitID = ""
    
    var bookOpenSlot = false

    override func viewDidLoad() {
        super.viewDidLoad()
        
        Design()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        parkingSpotCollectionView.delegate = self
        parkingSpotCollectionView.dataSource = self
        
        selectedIndex = 0
                
        self.showActivityIndicator()
        
        if bookOpenSlot == false {
            viewModel.getParkingDetails(unitId: unitID)
        } else {
            viewModel.getParkingDetailsForOpenParking(siteId: String(GlobalConstants.loggedInMemberDetails.siteId ?? 0))
        }
        
        observeEvent()
    }
    
    func Design() {
        btnBack.setTitle("", for: .normal)
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
    }
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension AllParkingVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView == parkingSpotCollectionView {
            return selectedFloor?.parking.count ?? 0
        } else {
            return viewModel.ParkingDetails.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
//        let data = viewModel.ParkindFloor[indexPath.row]
        
        if collectionView == parkingSpotCollectionView {
            
            let data = selectedFloor?.parking[indexPath.row]
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ParkingSpotCell", for: indexPath) as! ParkingSpotCell
            
            cell.lblTitle.text = data?.parkingName
            
            if data?.status == false {
                // Available for parking
                if data?.bookingParkingId[0] == "" {
                    // permanent Seat
                    cell.innerView.backgroundColor = .green

                } else {
                    // Booked Not available
                    cell.innerView.backgroundColor = .red
                }

            } else {
                if data?.bookingParkingId[0] == "" {
                    // permanent Seat
                    cell.innerView.backgroundColor = .gray
                
                } else {
                    // Booked Not available
                    cell.innerView.backgroundColor = .red
                    
                }
            }

            return cell

        } else {
            
            let data = viewModel.ParkingDetails[indexPath.row]
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ParkingFloorCell", for: indexPath) as! ParkingFloorCell
            
            // Configure the cell's appearance based on selection state
            if indexPath.row == selectedIndex {
                cell.innerView.applyCardEffectWithRedBackground()
                cell.lblTitle.textColor = .white
            } else {
                cell.innerView.applyCardEffect()
                cell.lblTitle.textColor = .black
            }
            
            cell.lblTitle.text = data.floorName
                    
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if collectionView == parkingSpotCollectionView {
            
            let data = selectedFloor?.parking[indexPath.row]
            
            
            if data?.status == true {
                if data?.bookingParkingId[0] == "" {
                    DispatchQueue.main.async {
                        self.view.makeToast("Permanently Reserved")
                    }
                } else {
                    
//                    callAlreadyInvitedDetailApi(seatId: String(data?.bookingParkingId[0]))
                }
            } else {
                
                if data?.bookingParkingId[0] == "" {
                    let storyboard = UIStoryboard(name: "PMS", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "ParkingDetailsVC") as! ParkingDetailsVC
                    
                    vc.parkingDetails = data ?? ParkingSpotDetail(parkingId: 0,
                                                                  parkingName: "",
                                                                  vehicleType: "",
                                                                  status: false,
                                                                  bookingParkingId: [])
                    
                    self.navigationController?.pushViewController(vc, animated: true)
                } else {
                    
                }
            }

        } else {
            // Deselect the previously selected cell if any
            if let previousIndex = selectedIndex {
                let previousIndexPath = IndexPath(row: previousIndex, section: 0)
                selectedIndex = nil // Reset the selection
//                selectedFloor = nil
                collectionView.reloadItems(at: [previousIndexPath])
            }
                    
            // Select the new cell
            selectedIndex = indexPath.row
            selectedFloor = viewModel.ParkingDetails[indexPath.row]
            collectionView.reloadItems(at: [indexPath])
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Size added
        if collectionView == parkingSpotCollectionView {
            return CGSize(width: 160, height: 100)
        } else {
            return CGSize(width: 120, height: 60)
        }
    }
}

extension AllParkingVC {
    
    func observeEvent() {
        
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Loaded")
            case .error(let error):
                self.hideActivityIndicator()
                print("Error In Api Call :- \(error)")
            case .dataFatchedSuccessfully(response: let response):
                                
                viewModel.ParkingDetails = response.parkingfloor
                
                if viewModel.ParkingDetails.count <= 0 {
                    
                    DispatchQueue.main.async {
                        
                        self.viewParkingFloor.isHidden = true
                        self.viewParkingSlot.isHidden = true
                    }
                    
                    print("No Parking Slot Available")
                } else {
                    selectedFloor = viewModel.ParkingDetails[0]
                }
                
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    self.collectionView.reloadData()
                }
                
            case .bookedSuccessfully(response: let response):
                print(response)

            case .occupiedBookingDataFetchedSuccessfully(response: let response):
                print(response)

            case .successfullyReleased(response: let response):
                print(response)

            case .parkingUnitsFetchedSuccessfully(data: let data):
                print(data)
            }
        }
    }
}
