//
//  TicketDetails.swift
//  Hello_Product
//
//  Created by Zentech-038 on 18/03/24.
//

import Foundation

struct TicketResponse: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [TicketDetails]
}

struct AssetResponse: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [AssetDetail]
}

struct StatusDetailResponse: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [StatusDetail]
}

struct AllStatusResponse: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [AllStatus]
}

struct TicketDetails: Codable {
    var id: Int?
    var assetsId: Int?
    var unitId: Int?
    var assetName: String?
    var assignedToMember: String?
    var statusId: Int?
    var statusName: String?
    var lastUpdated: String?
    var createdById: Int?
    var createdByName: String?
    var assignedToMemberId: Int?
    var titel: String?
    var image: String?
    
    init(id: Int, assetsId: Int, unitId: Int, assetName: String, assignedToMember: String, statusId: Int, statusName: String, lastUpdated: String, createdById: Int, createdByName: String, assignedToMemberId: Int, titel: String, image: String) {
        self.id = id
        self.assetsId = assetsId
        self.unitId = unitId
        self.assetName = assetName
        self.assignedToMember = assignedToMember
        self.statusId = statusId
        self.statusName = statusName
        self.lastUpdated = lastUpdated
        self.createdById = createdById
        self.createdByName = createdByName
        self.assignedToMemberId = assignedToMemberId
        self.titel = titel
        self.image = image
    }
    
    init() {

    }
}

struct StatusDetail: Codable {
    var id: Int?
    var ticketId: Int?
    var statusName: String?
    var description: String?
    var modifiedOn: String?
    
    init(id: Int, ticketId: Int, statusName: String, description: String, modifiedOn: String) {
        self.id = id
        self.ticketId = ticketId
        self.statusName = statusName
        self.description = description
        self.modifiedOn = modifiedOn
    }
    
    init() {
    }
}

struct AllStatus: Codable {
    var id: Int?
    var statusName: String?
    
    init(id: Int, statusName: String) {
        self.id = id
        self.statusName = statusName
    }
    
    init() {
    }
}

struct postTicketStatusDetail: Codable {
    var ticketId: Int?
    var statusId: Int?
    var description: String?
    var createdBy: String?
    var isActiveId: Int?
    
    init(ticketId: Int, statusId: Int, description: String, createdBy: String, isActiveId: Int) {
        self.ticketId = ticketId
        self.statusId = statusId
        self.description = description
        self.createdBy = createdBy
        self.isActiveId = isActiveId
    }
    
    init() {
        
    }
}


struct AssetDetail: Codable {
    var id: Int?
    var siteId: Int?
    var siteName: String?
    var unitId: Int?
    var unitName: String?
    var departmentId: Int?
    var departmentName: String?
    var infraId: Int?
    var infraName: String?
    var assetTypeId: Int?
    var assetName: String?
    var assetType: String?
    
    init(id: Int, siteId: Int, siteName: String, unitId: Int, unitName: String, departmentId: Int, departmentName: String, infraId: Int, infraName: String, assetTypeId: Int, assetName: String, assetType: String) {
        self.id = id
        self.siteId = siteId
        self.siteName = siteName
        self.unitId = unitId
        self.unitName = unitName
        self.departmentId = departmentId
        self.departmentName = departmentName
        self.infraId = infraId
        self.infraName = infraName
        self.assetTypeId = assetTypeId
        self.assetName = assetName
        self.assetType = assetType
    }
    
    init() {
        
    }
}
