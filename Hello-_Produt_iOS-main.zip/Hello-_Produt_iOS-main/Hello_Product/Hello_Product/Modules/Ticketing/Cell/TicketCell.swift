//
//  TicketCell.swift
//  Hello_Product
//
//  Created by Zentech-038 on 08/02/24.
//

import UIKit

class TicketCell: UITableViewCell {

    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var lblTicketNo: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblLastUpdateDate: UILabel!
    @IBOutlet weak var lblAssignedTo: UILabel!
    @IBOutlet weak var viewStatus: UIView!
    @IBOutlet weak var lblStatus: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        innerView.layer.cornerRadius = 8.0
        innerView.layer.borderColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        innerView.layer.borderWidth = 0.4
//        innerView.backgroundColor = ColorConstants.cellBackgroundColor
//        innerView.applyCardEffect()
        
        viewStatus.layer.cornerRadius = 5
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
