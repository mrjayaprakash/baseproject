//
//  TicketsViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 08/02/24.
//

import Foundation


final class TicketsViewModel {
    
    //    var allMemberArray = [MemberDetails]()
    var eventHandler: ((_ event: Event) -> Void)?
    
    var Tickets: [TicketDetails] = [TicketDetails]()
    
    var StatusDetails: [StatusDetail] = [StatusDetail]()
    
    func fetchTickets(id: String) {
        ApiManager.shared.request(modelType: TicketResponse.self,
                                  type: TicketingEndPoint.getAllAssignedTicketbyId(id: id)) { result in
            
            switch result {
                
            case .success(let data):
                self.eventHandler?(.ticketFetchedSuccessfully(ticketDetails: data.data))
   
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
    }
    
    func fetchMaterialDetail(id: String) {
        ApiManager.shared.request(modelType: AssetResponse.self,
                                  type: TicketingEndPoint.getAssetDetails(id: id)) { result in
            switch result {
                
            case .success(let data):
                if let data = data.data.first {
                    self.eventHandler?(.assetFetchedSuccessfully(assetDetails: data))
                }

            case .failure(let error):
                self.eventHandler?(.error(error))

            }
        }
    }
    
    func fetchStatusDetail(id: String) {
        ApiManager.shared.request(modelType: StatusDetailResponse.self,
                                  type: TicketingEndPoint.getStatusDetail(id: id)) { result in
            switch result {
                
            case .success(let data):
                self.eventHandler?(.statusDetailFetchedSuccessfully(statusDetail: data.data))
            case .failure(let error):
                self.eventHandler?(.error(error))

            }
        }
    }
    
    func fetchAllStatus() {
        ApiManager.shared.request(modelType: AllStatusResponse.self,
                                  type: TicketingEndPoint.getAllStatus) { result in
            switch result {
                
            case .success(let data):
                self.eventHandler?(.AllStatusFetched(allStatus: data.data))
            case .failure(let error):
                self.eventHandler?(.error(error))

            }
        }
    }
    
    
    func filterTickets(status: ticketsStatus, allTickets: [TicketDetails]) -> [TicketDetails] {
        
        var filteredTickets: [TicketDetails] = []
        
        
        switch status {
            
        case .all:
            filteredTickets = allTickets
            return filteredTickets
        case .open:
            for ticket in allTickets {
                if ticket.statusName == "Opened" {
                    filteredTickets.append(ticket)
                }
            }
            
            return filteredTickets

        case .processing:
            for ticket in allTickets {
                if ticket.statusName == "In Review" || ticket.statusName == "In Process" || ticket.statusName == "Escalated" {
                    filteredTickets.append(ticket)
                }
            }
            return filteredTickets
        case .closd:
            for ticket in allTickets {
                if ticket.statusName == "Resolved" {
                    filteredTickets.append(ticket)
                }
            }
            return filteredTickets
        }
    }
}

extension TicketsViewModel {

    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case ticketFetchedSuccessfully(ticketDetails: [TicketDetails])
        case assetFetchedSuccessfully(assetDetails: AssetDetail)
        case statusDetailFetchedSuccessfully(statusDetail: [StatusDetail])
        case AllStatusFetched(allStatus: [AllStatus])
    }

}
