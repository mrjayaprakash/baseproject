//
//  TicketDetailsVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 01/03/24.
//

import Foundation
import UIKit

class TicketDetailsVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var lblAssignedTo: UILabel!
    @IBOutlet weak var lblUpdatedOn: UILabel!
    
    @IBOutlet weak var viewTicketNo: UIView!
    @IBOutlet weak var lblTicketNo: UILabel!
    @IBOutlet weak var viewTicketDetails: UIView!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var btnChangeStatus: UIButton!
    @IBOutlet weak var btnReject: UIButton!
    //    var ticketNo: String = ""
    
    private var viewModel = TicketsViewModel()
    
    var ticketDetails: TicketDetails?
    var status: TicketStatusEnum?
    
    var ticketID = "1"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        design()
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "TicketStatusCell", bundle: nil), forCellReuseIdentifier: "TicketStatusCell")
        tableView.separatorStyle = .none
        tableView.bounces = false
                
        viewModel.fetchStatusDetail(id: ticketID)
        observeEvent()
        
        if ticketDetails?.statusName == "Opened" {
            status = .Opened
        } else if ticketDetails?.statusName == "In Review" {
            status = .InReview
        } else if ticketDetails?.statusName == "In Process" {
            status = .InProgress
        } else if ticketDetails?.statusName == "Escalated" {
            status = .Escalated
        } else if ticketDetails?.statusName == "Resolved" {
            status = .Resolved
        }
    }
    
    func design() {
        
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        btnBack.setTitle("", for: .normal)
        
        
//        displayTicketStatusDetail(status: status ?? .Opened)
        
        viewTicketNo.layer.cornerRadius = viewTicketNo.frame.height / 2
        
        viewTicketDetails.layer.cornerRadius = 20
        viewTicketDetails.layer.borderWidth = 0.5
        viewTicketDetails.layer.borderColor = UIColor.lightGray.cgColor
        
        btnChangeStatus.layer.cornerRadius = 5
        btnReject.layer.cornerRadius = 5

    }
    
    func getDateFromDateString(_ dateString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        if let date = dateFormatter.date(from: dateString) {
            dateFormatter.dateFormat = "dd-MM-yyyy"
            return dateFormatter.string(from: date)
        } else {
            return nil
        }
    }
    
    @IBAction func btnChangeStatusTapped(_ sender: UIButton) {
    }
    @IBAction func btnRejecttapped(_ sender: UIButton) {
    }
    
    func statusColor(statusName: String) -> UIColor {
        if statusName == "Opened" {
            return #colorLiteral(red: 0.4274509804, green: 0.4470588235, blue: 0.4941176471, alpha: 0.1987789735)
        } else if statusName == "In Review" {
            return #colorLiteral(red: 0, green: 0.6588235294, blue: 1, alpha: 0.2043925911)
        } else if statusName == "In Process" {
            return #colorLiteral(red: 0.1176470588, green: 1, blue: 0, alpha: 0.1976407285)
        } else if statusName == "Escalated" {
            return #colorLiteral(red: 1, green: 0.4901960784, blue: 0.0431372549, alpha: 0.3469577815)
        } else if statusName == "Resolved" {
            return #colorLiteral(red: 0.1176470588, green: 1, blue: 0.007843137255, alpha: 0.5)
        } else {
            return .clear
        }
    }
    
//    func displayTicketStatusDetail(status: TicketStatusEnum) {
//        switch status {
//            
//        case .Opened:
//            ViewDotOpened.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineOpened.backgroundColor = ColorConstants.TrackerLineColor
//            
//            lblOpenUpdatedDate.text = ticketDetails?.statusDetails[0].updatedDate
//            lblOpenDescription.text = ticketDetails?.statusDetails[0].description
//            
//            viewContentInReview.isHidden = true
//            viewContectInProgress.isHidden = true
//            viewContentEscalated.isHidden = true
//            viewContentResolved.isHidden = true
//            
//        case .InReview:
//            ViewDotOpened.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineOpened.backgroundColor = ColorConstants.TrackerLineColor
//            viewDotInReview.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineInReview.backgroundColor = ColorConstants.TrackerLineColor
//            
//            lblOpenUpdatedDate.text = ticketDetails?.statusDetails[0].updatedDate
//            lblOpenDescription.text = ticketDetails?.statusDetails[0].description
//            
//            lblInReviewUpdateDate.text = ticketDetails?.statusDetails[1].updatedDate
//            lblInReviewDescription.text = ticketDetails?.statusDetails[1].description
//            
//            viewContectInProgress.isHidden = true
//            viewContentEscalated.isHidden = true
//            viewContentResolved.isHidden = true
//            
//        case .InProgress:
//            ViewDotOpened.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineOpened.backgroundColor = ColorConstants.TrackerLineColor
//            viewDotInReview.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineInReview.backgroundColor = ColorConstants.TrackerLineColor
//            viewDotInProgress.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineInProgress.backgroundColor = ColorConstants.TrackerLineColor
//            
//            lblOpenUpdatedDate.text = ticketDetails?.statusDetails[0].updatedDate
//            lblOpenDescription.text = ticketDetails?.statusDetails[0].description
//            
//            lblInReviewUpdateDate.text = ticketDetails?.statusDetails[1].updatedDate
//            lblInReviewDescription.text = ticketDetails?.statusDetails[1].description
//            
//            lblInProcessUpdateDate.text = ticketDetails?.statusDetails[2].updatedDate
//            lblInProgressDescription.text = ticketDetails?.statusDetails[2].description
//            
//            viewContentEscalated.isHidden = true
//            viewContentResolved.isHidden = true
//            
//            
//        case .Escalated:
//            ViewDotOpened.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineOpened.backgroundColor = ColorConstants.TrackerLineColor
//            viewDotInReview.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineInReview.backgroundColor = ColorConstants.TrackerLineColor
//            viewDotInProgress.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineInProgress.backgroundColor = ColorConstants.TrackerLineColor
//            viewDotEscalated.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineEscalated.backgroundColor = ColorConstants.TrackerLineColor
//            
//            lblOpenUpdatedDate.text = ticketDetails?.statusDetails[0].updatedDate
//            lblOpenDescription.text = ticketDetails?.statusDetails[0].description
//            
//            lblInReviewUpdateDate.text = ticketDetails?.statusDetails[1].updatedDate
//            lblInReviewDescription.text = ticketDetails?.statusDetails[1].description
//            
//            lblInProcessUpdateDate.text = ticketDetails?.statusDetails[2].updatedDate
//            lblInProgressDescription.text = ticketDetails?.statusDetails[2].description
//            
//            lblEscalatedUpdateDate.text = ticketDetails?.statusDetails[3].updatedDate
//            lblEscalatedDescription.text = ticketDetails?.statusDetails[3].description
//            
//            viewContentResolved.isHidden = true
//
//            
//        case .Resolved:
//            ViewDotOpened.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineOpened.backgroundColor = ColorConstants.TrackerLineColor
//            viewDotInReview.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineInReview.backgroundColor = ColorConstants.TrackerLineColor
//            viewDotInProgress.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineInProgress.backgroundColor = ColorConstants.TrackerLineColor
//            viewDotEscalated.backgroundColor = ColorConstants.TrackerLineColor
//            viewLineEscalated.backgroundColor = ColorConstants.TrackerLineColor
//            viewDotResolved.backgroundColor = ColorConstants.TrackerLineColor
//            
//            lblOpenUpdatedDate.text = ticketDetails?.statusDetails[0].updatedDate
//            lblOpenDescription.text = ticketDetails?.statusDetails[0].description
//            
//            lblInReviewUpdateDate.text = ticketDetails?.statusDetails[1].updatedDate
//            lblInReviewDescription.text = ticketDetails?.statusDetails[1].description
//            
//            lblInProcessUpdateDate.text = ticketDetails?.statusDetails[2].updatedDate
//            lblInProgressDescription.text = ticketDetails?.statusDetails[2].description
//            
//            lblEscalatedUpdateDate.text = ticketDetails?.statusDetails[3].updatedDate
//            lblEscalatedDescription.text = ticketDetails?.statusDetails[3].description
//            
//            lblResolvedUpdateDate.text = ticketDetails?.statusDetails[4].updatedDate
//            lblResolvedDescription.text = ticketDetails?.statusDetails[4].description
//        }
//    }
    
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
}

extension TicketDetailsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.StatusDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let data = viewModel.StatusDetails[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TicketStatusCell", for: indexPath) as! TicketStatusCell
        
        cell.lblDate.text = getDateFromDateString(data.modifiedOn ?? "")
        cell.lblDescription.text = data.description
        cell.lblStatus.text = data.statusName
        
        return cell
    }
        
}

extension TicketDetailsVC {
    func observeEvent() {
        
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Loaded")
            case .error(let error):
                self.hideActivityIndicator()
                print("Error In Api Call :- \(error)")
            case .ticketFetchedSuccessfully(ticketDetails: let ticketDetails):
                print("Fetched Successfully")
                
            case .assetFetchedSuccessfully(assetDetails: let assetDetails):
                DispatchQueue.main.async {
                    print(assetDetails)
                }
            case .statusDetailFetchedSuccessfully(statusDetail: let statusDetail):
                
                DispatchQueue.main.async {
                    self.viewModel.StatusDetails = statusDetail
                    
                    self.tableView.reloadData()
                }
            case .AllStatusFetched(allStatus: let allStatus):
                print("Success")

            }
        }
    }
}
