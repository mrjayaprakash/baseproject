//
//  NewTicketVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 08/02/24.
//

import Foundation
import UIKit
import AVFoundation
import Photos

class NewTicketVC: UIViewController {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnBack: UIButton!
    
    @IBOutlet weak var viewRadioButton: UIView!
    @IBOutlet weak var viewConteinerMaterialId: UIView!
        
    @IBOutlet weak var imgRadioUnitLevel: UIImageView!
    @IBOutlet weak var imgRadioSiteLevel: UIImageView!
    @IBOutlet weak var imgRadioUnderAMC: UIImageView!
    
    @IBOutlet weak var descriptionTextView: UITextView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblImage: UILabel!
    
    @IBOutlet weak var viewPickImage: UIView!
    @IBOutlet weak var btnRaiseTicket: UIButton!
    
    @IBOutlet weak var txtMaterialId: UITextField!
    @IBOutlet weak var txtTitle: UITextField!
    var image: UIImage?
    
    var QRScanned = false
    
    private var viewModel = TicketsViewModel()
    
    enum radioButton {
        case unitLevel
        case siteLevel
        case underAMC
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtMaterialId.delegate = self
        
        imgRadioUnitLevel.isUserInteractionEnabled = true
        imgRadioSiteLevel.isUserInteractionEnabled = true
        imgRadioUnderAMC.isUserInteractionEnabled = true
        
        let tapImgRadioUnitLevel = UITapGestureRecognizer(target: self, action: #selector(didTapimgRadioUnitLevel(_:)))
        let tapImgRadioSiteLevel = UITapGestureRecognizer(target: self, action: #selector(didTapimgRadioSiteLevel(_:)))
        let tapImgRadioUnderAMC = UITapGestureRecognizer(target: self, action: #selector(didTapimgRadioUnderAmc(_:)))



        imgRadioUnitLevel.addGestureRecognizer(tapImgRadioUnitLevel)
        imgRadioSiteLevel.addGestureRecognizer(tapImgRadioSiteLevel)
        imgRadioUnderAMC.addGestureRecognizer(tapImgRadioUnderAMC)
        
        
        let tapImgPicker = UITapGestureRecognizer(target: self, action: #selector(didTapimgPicker(_:)))
        viewPickImage.addGestureRecognizer(tapImgPicker)

        Design()
        
        
        if QRScanned {
            radioButtonClicked(clicked: .underAMC)

        } else {
            radioButtonClicked(clicked: .underAMC)
        }
    }
    
    @objc private func didTapimgRadioUnitLevel(_ sender: UITapGestureRecognizer) {
        radioButtonClicked(clicked: .unitLevel)
    }
    
    @objc private func didTapimgRadioSiteLevel(_ sender: UITapGestureRecognizer) {
        radioButtonClicked(clicked: .siteLevel)
    }
    
    @objc private func didTapimgRadioUnderAmc(_ sender: UITapGestureRecognizer) {
        radioButtonClicked(clicked: .underAMC)
    }
    
    @objc private func didTapimgPicker(_ sender: UITapGestureRecognizer) {
        showImagePickerOptions()
    }
    
    func radioButtonClicked(clicked: radioButton) {
        
        switch clicked {
            
        case .unitLevel:
            imgRadioUnitLevel.image = UIImage(named: "radio_Checked")
            imgRadioSiteLevel.image = UIImage(named: "radio-unchacked")
            imgRadioUnderAMC.image = UIImage(named: "radio-unchacked")
            viewConteinerMaterialId.isHidden = true


        case .siteLevel:
            imgRadioSiteLevel.image = UIImage(named: "radio_Checked")
            imgRadioUnitLevel.image = UIImage(named: "radio-unchacked")
            imgRadioUnderAMC.image = UIImage(named: "radio-unchacked")
            viewConteinerMaterialId.isHidden = true

            
        case .underAMC:
            imgRadioUnderAMC.image = UIImage(named: "radio_Checked")
            imgRadioUnitLevel.image = UIImage(named: "radio-unchacked")
            imgRadioSiteLevel.image = UIImage(named: "radio-unchacked")
            viewConteinerMaterialId.isHidden = false
        }
    }
    
    
    func Design() {
        
        viewRadioButton.isHidden = true
        
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        descriptionTextView.layer.borderColor = UIColor.lightGray.cgColor
        descriptionTextView.layer.borderWidth = 0.5
        descriptionTextView.layer.cornerRadius = 5
        
        viewPickImage.layer.borderColor = UIColor.lightGray.cgColor
        viewPickImage.layer.borderWidth = 0.5
        viewPickImage.layer.cornerRadius = 5
        
        btnBack.setTitle("", for: .normal)
        
        btnRaiseTicket.layer.cornerRadius = 5
        
        txtTitle.layer.borderColor = UIColor.lightGray.cgColor
        txtTitle.layer.borderWidth = 0.5
        txtTitle.layer.cornerRadius = 5
        
        txtMaterialId.layer.borderColor = UIColor.lightGray.cgColor
        txtMaterialId.layer.borderWidth = 0.5
        txtMaterialId.layer.cornerRadius = 5
    }
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnRaiseTicketTapped(_ sender: UIButton) {
        
    }
    
    func showImagePickerOptions() {
        let picker = UIImagePickerController()
        picker.delegate = self
        
        let alertController = UIAlertController(title: "Select Image", message: nil, preferredStyle: .actionSheet)
        
        let pickFromGalleryAction = UIAlertAction(title: "Pick from Gallery", style: .default) { _ in
            self.checkPhotoLibraryPermission()
        }
        
        let clickImageAction = UIAlertAction(title: "Click Image", style: .default) { _ in
            self.checkCameraPermission()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertController.addAction(pickFromGalleryAction)
        alertController.addAction(clickImageAction)
        alertController.addAction(cancelAction)
        
        // Set the popover presentation controller properties for iPad
        if let popoverPresentationController = alertController.popoverPresentationController {
            popoverPresentationController.sourceView = self.view
            popoverPresentationController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            popoverPresentationController.permittedArrowDirections = []
        }
        
        // Present the options
        self.present(alertController, animated: true, completion: nil)
    }
    
    func checkPhotoLibraryPermission() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            let status = PHPhotoLibrary.authorizationStatus()
            switch status {
            case .authorized:
                self.showPhotoPicker()
            case .notDetermined:
                PHPhotoLibrary.requestAuthorization { status in
                    if status == .authorized {
                        DispatchQueue.main.async {
                            self.showPhotoPicker()
                        }
                    } else {
                        // Handle when permission is denied
                    }
                }
            case .denied, .restricted:
                // Handle when permission is denied or restricted
                break
            @unknown default:
                break
            }
        }
    }
    
    // Function to check and request permission for camera
    func checkCameraPermission() {
        let authStatus = AVCaptureDevice.authorizationStatus(for: .video)
        switch authStatus {
        case .authorized:
            self.showCamera()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                if granted {
                    self.showCamera()
                } else {
                    // Handle when permission is denied
                }
            }
        case .denied, .restricted:
            // Handle when permission is denied or restricted
            break
        @unknown default:
            break
        }
    }
    
    func showPhotoPicker() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .photoLibrary
            self.present(picker, animated: true, completion: nil)
        }
    }
        
    func showCamera() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .camera
            self.present(picker, animated: true, completion: nil)
        }
    }
}

extension NewTicketVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    // Delegate method to handle the selected image
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            // Set the selected image to your UIImageView
            img.image = selectedImage
            image = selectedImage
            
            if image != nil {
                lblImage.text = "Change Image"
            } else {
                lblImage.text = "Select or Click Image"
            }
            
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    // Delegate method to handle cancellation
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

extension NewTicketVC: UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == txtMaterialId {
            viewModel.fetchMaterialDetail(id: "1")
        }
    }
}

extension NewTicketVC {
    func observeEvent() {
        
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Loaded")
            case .error(let error):
                self.hideActivityIndicator()
                print("Error In Api Call :- \(error)")
            case .ticketFetchedSuccessfully(ticketDetails: let ticketDetails):
                print("Fetched Successfully")
                
            case .assetFetchedSuccessfully(assetDetails: let assetDetails):
                DispatchQueue.main.async {
                    print(assetDetails)
                }
            case .statusDetailFetchedSuccessfully(statusDetail: let statusDetail):
                print("Success")
                
            case .AllStatusFetched(allStatus: let allStatus):
                print("Success")

            }
        }
    }
}
