//
//  GrevanceVC.swift
//  Hello_Product
//
//  Created by Zentech-038 on 13/02/24.
//

import Foundation
import UIKit
import AVFoundation

class GrevanceVC: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var btnRaiseNewTicket: UIButton!
    @IBOutlet weak var btnScanQR: UIButton!
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var viewAllTicketsOuter: UIView!
    @IBOutlet weak var viewAllTicketsInner: UIView!
    @IBOutlet weak var btnAllTickets: UIButton!
    @IBOutlet weak var lblNoAllTickets: UILabel!
    
    @IBOutlet weak var viewOpenTicketOuter: UIView!
    @IBOutlet weak var viewOpenTicketInner: UIView!
    @IBOutlet weak var btnOpenTicket: UIButton!
    @IBOutlet weak var lblNoOpenTickets: UILabel!
    
    @IBOutlet weak var viewProcessingTicketOuter: UIView!
    @IBOutlet weak var viewProcessingTicketInner: UIView!
    @IBOutlet weak var btnProcessingTicket: UIButton!
    @IBOutlet weak var lblNoInProcessTickets: UILabel!
    
    @IBOutlet weak var viewCloseTicketOuter: UIView!
    @IBOutlet weak var viewCloseTicketInner: UIView!
    @IBOutlet weak var btnClosedTicket: UIButton!
    @IBOutlet weak var lblNoClosedTickets: UILabel!
    
    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    var cancelButton: UIButton! // Declare cancelButton as a property
    
    private var viewModel = TicketsViewModel()
    
    var arrayList: [TicketDetails] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.showActivityIndicator()
        viewModel.fetchTickets(id: String(GlobalConstants.loggedInMemberDetails.memberId ?? 0))
        observeEvent()
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "TicketCell", bundle: nil), forCellReuseIdentifier: "TicketCell")
        tableView.separatorStyle = .none
        tableView.bounces = false
        
        design()
        
    }
    
    func NoofTickets() {
        lblNoAllTickets.text = String(viewModel.Tickets.count)
        lblNoOpenTickets.text = String(viewModel.filterTickets(status: .open, allTickets: viewModel.Tickets).count)
        lblNoInProcessTickets.text = String(viewModel.filterTickets(status: .processing, allTickets: viewModel.Tickets).count)
        lblNoClosedTickets.text = String(viewModel.filterTickets(status: .closd, allTickets: viewModel.Tickets).count)

    }
    
    func changeList(clicked: ticketsStatus) {
        
        NoofTickets()
        
        switch clicked {
        case .all:

            viewAllTicketsInner.backgroundColor = #colorLiteral(red: 0.9647058824, green: 0.7058823529, blue: 0.6980392157, alpha: 1)
            viewOpenTicketInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
            viewCloseTicketInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
            viewProcessingTicketInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
            
            arrayList = viewModel.filterTickets(status: .all, allTickets: viewModel.Tickets)
            self.tableView.reloadData()
            
        case .open:
            viewOpenTicketInner.backgroundColor = #colorLiteral(red: 0.9647058824, green: 0.7058823529, blue: 0.6980392157, alpha: 1)
            viewCloseTicketInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
            viewProcessingTicketInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
            viewAllTicketsInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
            
            arrayList = viewModel.filterTickets(status: .open, allTickets: viewModel.Tickets)
            self.tableView.reloadData()
            
        case .processing:
            viewOpenTicketInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
            viewCloseTicketInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
            viewProcessingTicketInner.backgroundColor = #colorLiteral(red: 0.9647058824, green: 0.7058823529, blue: 0.6980392157, alpha: 1)
            viewAllTicketsInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)

            arrayList = viewModel.filterTickets(status: .processing, allTickets: viewModel.Tickets)
            self.tableView.reloadData()

        case .closd:
            viewOpenTicketInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
            viewCloseTicketInner.backgroundColor = #colorLiteral(red: 0.9647058824, green: 0.7058823529, blue: 0.6980392157, alpha: 1)
            viewProcessingTicketInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
            viewAllTicketsInner.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
            
            arrayList = viewModel.filterTickets(status: .closd, allTickets: viewModel.Tickets)
            self.tableView.reloadData()
        
        }
    }
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func btnOpenTickettapped(_ sender: UIButton) {
        
        changeList(clicked: .open)
    }
    @IBAction func btnAllTicketsTapped(_ sender: UIButton) {
        changeList(clicked: .all)
    }
    @IBAction func btnProcessingTicketTapped(_ sender: UIButton) {
        
        changeList(clicked: .processing)
    }
    @IBAction func btnClosedTicketTapped(_ sender: UIButton) {
        
        changeList(clicked: .closd)
    }

    
    @IBAction func btnRaiseNewTicketTapped(_ sender: UIButton) {
        
        let storyboard = UIStoryboard(name: "Ticketing", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "NewTicketVC") as! NewTicketVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func btnScanQRTapped(_ sender: UIButton) {
        // Check if the camera is available
        guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
            print("Camera is not available")
            return
        }

        // Perform setup on a background thread
        DispatchQueue.global(qos: .background).async {
            // Create a new AVCaptureSession
            self.captureSession = AVCaptureSession()
            
            // Get the default AVCaptureDevice for video input
            guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else {
                print("Failed to get the camera device")
                return
            }
            
            // Create AVCaptureDeviceInput
            do {
                let videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
                self.captureSession.addInput(videoInput)
            } catch {
                print(error)
                return
            }
            
            // Create AVCaptureMetadataOutput
            let metadataOutput = AVCaptureMetadataOutput()
            if self.captureSession.canAddOutput(metadataOutput) {
                self.captureSession.addOutput(metadataOutput)
                
                // Set delegate and metadata types
                metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
                metadataOutput.metadataObjectTypes = [.qr]
                
                // Start video capture
                self.captureSession.startRunning()
            } else {
                print("Failed to add metadata output")
                return
            }
            
            // Create AVCaptureVideoPreviewLayer and add it to the view
            DispatchQueue.main.async {
                self.previewLayer = AVCaptureVideoPreviewLayer(session: self.captureSession)
                self.previewLayer.frame = self.view.layer.bounds
                self.previewLayer.videoGravity = .resizeAspectFill
                self.view.layer.addSublayer(self.previewLayer)
                
                // Add cancel button
                self.cancelButton = UIButton(type: .system)
                self.cancelButton.setTitle("Cancel", for: .normal)
                self.cancelButton.addTarget(self, action: #selector(self.cancelButtonTapped), for: .touchUpInside)
                self.cancelButton.translatesAutoresizingMaskIntoConstraints = false
                self.view.addSubview(self.cancelButton)
                
                // Constraints for cancel button
                NSLayoutConstraint.activate([
                    self.cancelButton.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 16),
                    self.cancelButton.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 16)
                ])
            }
        }
    }
    
    func design() {
        
        viewBackground.layer.cornerRadius = 30
        viewBackground.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        viewAllTicketsInner.layer.cornerRadius = 5
        viewOpenTicketInner.layer.cornerRadius = 5
        viewCloseTicketInner.layer.cornerRadius = 5
        viewProcessingTicketInner.layer.cornerRadius = 5
        
        btnBack.setTitle("", for: .normal)
        btnOpenTicket.setTitle("", for: .normal)
        btnProcessingTicket.setTitle("", for: .normal)
        btnClosedTicket.setTitle("", for: .normal)
        btnAllTickets.setTitle("", for: .normal)
            
        btnRaiseNewTicket.layer.cornerRadius = 5
        btnScanQR.layer.cornerRadius = 5
        
    }
    
    // Cancel button action
    @objc func cancelButtonTapped() {
        
        dismiss(animated: true, completion: {
            // Hide the cancel button after dismissing the view controller
            self.cancelButton.isHidden = true
            self.captureSession.stopRunning()
            self.previewLayer.removeFromSuperlayer()
        })
    }
    
    
    // AVCaptureMetadataOutputObjectsDelegate method to handle captured metadata objects (QR codes)
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        // Check if the metadataObjects array is not empty
        if let metadataObject = metadataObjects.first {
            // Convert the metadataObject to AVMetadataMachineReadableCodeObject
            guard let readableObject = metadataObject as? AVMetadataMachineReadableCodeObject else { return }

            // Check if the metadataObject is a QR code
            if readableObject.type == .qr {
                // If a QR code is found, stop capture session
                captureSession.stopRunning()

                // Print the QR code payload
                if let qrCodeContent = readableObject.stringValue {
                    print("QR Code scanned successfully: \(qrCodeContent)")
                    
                    let storyboard = UIStoryboard(name: "Ticketing", bundle: nil)
                    let vc = storyboard.instantiateViewController(withIdentifier: "NewTicketVC") as! NewTicketVC
                    previewLayer.removeFromSuperlayer()
                    vc.QRScanned = true
                    self.navigationController?.pushViewController(vc, animated: true)
                
                }
            }
        } else {
            // If no QR code is found, print error
            print("No QR Code detected")
        }
    }
    
}

extension GrevanceVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let data = arrayList[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "TicketCell", for: indexPath) as! TicketCell
        cell.selectionStyle = .none
        cell.lblTicketNo.text = String(data.id ?? 0)
        
        if data.statusName == "Opened" {
            cell.viewStatus.backgroundColor = #colorLiteral(red: 0.4274509804, green: 0.4470588235, blue: 0.4941176471, alpha: 0.1987789735)
            cell.lblStatus.text = "Opened"
        } else if data.statusName == "In Review" {
            cell.viewStatus.backgroundColor = #colorLiteral(red: 0, green: 0.6588235294, blue: 1, alpha: 0.2043925911)
            cell.lblStatus.text = "In Review"
        } else if data.statusName == "In Process" {
            cell.viewStatus.backgroundColor = #colorLiteral(red: 0.1176470588, green: 1, blue: 0, alpha: 0.1976407285)
            cell.lblStatus.text = "In Process"
        } else if data.statusName == "Escalated" {
            cell.viewStatus.backgroundColor = #colorLiteral(red: 1, green: 0.4901960784, blue: 0.0431372549, alpha: 0.3469577815)
            cell.lblStatus.text = "Escalated"
        } else if data.statusName == "Resolved" {
            cell.viewStatus.backgroundColor = #colorLiteral(red: 0.1176470588, green: 1, blue: 0.007843137255, alpha: 0.5)
            cell.lblStatus.text = "Resolved"
        }
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let data = arrayList[indexPath.row]
        let storyboard = UIStoryboard(name: "Ticketing", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "TicketDetailsVC") as! TicketDetailsVC
        vc.ticketDetails = data
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
}

extension GrevanceVC {
    func observeEvent() {
        
        viewModel.eventHandler = { [weak self] event in
            guard let self = self else { return }
            
            switch event {
            case .loading:
                self.showActivityIndicator()
                print("Loading")
            case .stopLoading:
                print("Stop Loading")
            case .dataLoaded:
                print("Loaded")
            case .error(let error):
                self.hideActivityIndicator()
                print("Error In Api Call :- \(error)")
            case .ticketFetchedSuccessfully(ticketDetails: let ticketDetails):
                viewModel.Tickets = ticketDetails
                DispatchQueue.main.async {
                    self.hideActivityIndicator()
                    self.changeList(clicked: .all)
                }
            case .assetFetchedSuccessfully(assetDetails: let assetDetails):
                print("Success")
            case .statusDetailFetchedSuccessfully(statusDetail: let statusDetail):
                print("Success")

            case .AllStatusFetched(allStatus: let allStatus):
                print("Success")

            }
        }
    }
}
