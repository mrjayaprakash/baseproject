//
//  ErrorEnum.swift
//  Hello_Product
//
//  Created by Zentech-038 on 06/11/23.
//

import Foundation

enum DataError: Error {
    case invalidResponse
    case invalidURL
    case invalidData
    case network(Error?)
}
