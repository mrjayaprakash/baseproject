//
//  EventEnum.swift
//  Hello_Product
//
//  Created by Zentech-038 on 06/11/23.
//

import Foundation

enum Event {
    case loading
    case stopLoading
    case dataLoaded
    case error(Error?)
}
