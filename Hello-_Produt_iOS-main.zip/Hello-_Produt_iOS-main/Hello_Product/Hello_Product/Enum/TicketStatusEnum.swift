//
//  TicketStatusEnum.swift
//  Hello_Product
//
//  Created by Zentech-038 on 19/03/24.
//

import Foundation


enum ticketsStatus {
    case all
    case open
    case processing
    case closd
}

enum TicketStatusEnum {
    case Opened
    case InReview
    case InProgress
    case Escalated
    case Resolved
}
