//
//  PushViewModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 09/02/24.
//

import Foundation

final class PushViewModel {
    
//    var allMemberArray = [MemberDetails]()
    var eventHandler: ((_ event: Event) -> Void)?
    
    func registerDeviceForPushNotification(deviceDetails: PushModel) {
        self.eventHandler?(.loading)
        ApiManager.shared.request(modelType: RegisterResponse.self,
                                  type: RaiseAlertEndPoint.registerDeviceToken(details: deviceDetails)) { result in
            self.eventHandler?(.stopLoading)
            
            switch result {
                
            case .success(let data):
                self.eventHandler?(.registeredSuccessfully(response: data))
                
            case .failure(let error):
                self.eventHandler?(.error(error))
            }
        }
        
    }
}

extension PushViewModel {

    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case registeredSuccessfully(response: RegisterResponse)
    }

}
