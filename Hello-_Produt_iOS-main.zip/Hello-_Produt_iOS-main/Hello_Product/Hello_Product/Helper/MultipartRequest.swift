//
//  MultipartRequest.swift
//  Hello_Product
//
//  Created by Zentech-038 on 20/11/23.
//

import Foundation

public struct MultipartRequest: Codable {
    
    public let boundary: String
    
    private let separator: String = "\r\n"
    private var data: Data

    public init(boundary: String = UUID().uuidString) {
        self.boundary = boundary
        self.data = .init()
    }
    
    private mutating func appendBoundarySeparator() {
        if let separatorData = "--\(boundary)\(separator)".data(using: .utf8) {
            data.append(separatorData)
        }
    }
    
    private mutating func appendSeparator() {
        if let separatorData = separator.data(using: .utf8) {
            data.append(separatorData)
        }
    }

    private func disposition(_ key: String) -> String {
        "Content-Disposition: form-data; name=\"\(key)\""
    }

    public mutating func add(
        key: String,
        value: String
    ) {
        appendBoundarySeparator()
        if let separatorData1 = (disposition(key) + separator).data(using: .utf8) {
            data.append(separatorData1)
        }
        appendSeparator()
        
        if let separatorData2 = (value + separator).data(using: .utf8) {
            data.append(separatorData2)
        }
    }

    public mutating func add(
        key: String,
        fileName: String,
        fileMimeType: String,
        fileData: Data
    ) {
        appendBoundarySeparator()
        if let separatorData1 = (disposition(key) + "; filename=\"\(fileName)\"" + separator).data(using: .utf8) {
            data.append(separatorData1)
        }
        
        if let separatorData2 = ("Content-Type: \(fileMimeType)" + separator + separator).data(using: .utf8) {
            data.append(separatorData2)
        }
        data.append(fileData)
        appendSeparator()
    }

    public var httpContentTypeHeaderValue: String {
        "multipart/form-data; boundary=\(boundary)"
    }
    
    public var httpBody: Data {
        var bodyData = data
        if let boundaryData = "--\(boundary)--".data(using: .utf8) {
            bodyData.append(boundaryData)
        }
        return bodyData
    }

}


//public struct MultipartRequest {
//    
//    public let boundary: String
//    
//    private var data: Data
//    
//    public init(boundary: String = UUID().uuidString) {
//        self.boundary = boundary
//        self.data = Data()
//    }
//    
//    private mutating func appendBoundarySeparator() {
//        let separator = "\r\n"
//        if let boundaryData = ("--\(boundary)" + separator).data(using: .utf8) {
//            data.append(boundaryData)
//        }
//    }
//    
//    private mutating func appendSeparator() {
//        let separator = "\r\n"
//        if let separatorData = separator.data(using: .utf8) {
//            data.append(separatorData)
//        }
//    }
//
//    private func disposition(_ key: String) -> String {
//        "Content-Disposition: form-data; name=\"\(key)\""
//    }
//
//    public mutating func add(
//        key: String,
//        value: String
//    ) {
//        appendBoundarySeparator()
//        let contentDisposition = disposition(key)
//        if let contentDispositionData = contentDisposition.data(using: .utf8),
//           let separatorData = "\r\n".data(using: .utf8),
//           let valueData = value.data(using: .utf8) {
//            data.append(contentDispositionData)
//            data.append(separatorData)
//            data.append(separatorData)
//            data.append(valueData)
//            appendSeparator()
//        }
//    }
//
//    public mutating func add(
//        key: String,
//        fileName: String,
//        fileMimeType: String,
//        fileData: Data
//    ) {
//        appendBoundarySeparator()
//        let contentDisposition = "\(disposition(key)); filename=\"\(fileName)\""
//        let contentType = "Content-Type: \(fileMimeType)"
//        if let contentDispositionData = contentDisposition.data(using: .utf8),
//           let contentTypeData = contentType.data(using: .utf8),
//           let separatorData = "\r\n\r\n".data(using: .utf8) {
//            data.append(contentDispositionData)
//            data.append(separatorData)
//            data.append(contentTypeData)
//            data.append(separatorData)
//            data.append(fileData)
//            appendSeparator()
//        }
//    }
//
//    public var httpContentTypeHeaderValue: String {
//        "multipart/form-data; boundary=\(boundary)"
//    }
//    
//
//    public var httpBody: Data {
//        var bodyData = data
//        if let closingBoundaryData = ("--\(boundary)--\r\n").data(using: .utf8) {
//            bodyData.append(closingBoundaryData)
//        }
//        return bodyData
//    }
//}


