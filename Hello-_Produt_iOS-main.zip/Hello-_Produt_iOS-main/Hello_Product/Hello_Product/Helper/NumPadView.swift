//
//  NumPadView.swift
//  Hello_Product
//
//  Created by Zentech-038 on 06/11/23.
//

import Foundation
import UIKit

class NumPadView: UIView {
    
    var typedString = ""
    var maxLength:Int = 6
    var delegate: NumPadTypeProtocol?
    var buttonColor: UIColor = UIColor(red: 0.942, green: 0.922, blue: 0.922, alpha: 1)
    var buttonBorderColor: CGColor = UIColor.black.cgColor
    var buttonBorderWidth = 0.0
    var buttonCornerRadius = 15.0
    
    
    @IBOutlet weak var number1: UIButton!
    @IBOutlet weak var number2: UIButton!
    @IBOutlet weak var number3: UIButton!
    @IBOutlet weak var number4: UIButton!
    @IBOutlet weak var number5: UIButton!
    @IBOutlet weak var number6: UIButton!
    @IBOutlet weak var number7: UIButton!
    @IBOutlet weak var number8: UIButton!
    @IBOutlet weak var number9: UIButton!
    @IBOutlet weak var number0: UIButton!
    @IBOutlet weak var deleteBtn: UIButton!
    @IBOutlet weak var goBtn: UIButton!
    
    @IBAction func number1Action(_ sender: Any) {
        if typedString.count < maxLength {
            typedString.append(contentsOf: "1")
            delegate?.setTextField(number: typedString)
            (sender as? UIButton)?.flash()
        }
        
        if typedString.count == maxLength {
            delegate?.enableSubmitBtn()
        }
        
    }
    @IBAction func number2Action(_ sender: Any) {
        if typedString.count < maxLength {
            typedString.append(contentsOf: "2")
            delegate?.setTextField(number: typedString)
            (sender as? UIButton)?.flash()
        }
        
        if typedString.count == maxLength {
            delegate?.enableSubmitBtn()
        }

    }
    @IBAction func number3Action(_ sender: Any) {
        if typedString.count < maxLength {
            typedString.append(contentsOf: "3")
            delegate?.setTextField(number: typedString)
            (sender as? UIButton)?.flash()
        }
        if typedString.count == maxLength {
            delegate?.enableSubmitBtn()
        }

    }
    @IBAction func number4Action(_ sender: Any) {
        if typedString.count < maxLength {
        typedString.append(contentsOf: "4")
        delegate?.setTextField(number: typedString)
        (sender as? UIButton)?.flash()
        }

        if typedString.count == maxLength {
            delegate?.enableSubmitBtn()
        }
    }
    @IBAction func number5Action(_ sender: Any) {
        if typedString.count < maxLength {
        typedString.append(contentsOf: "5")
        delegate?.setTextField(number: typedString)
        (sender as? UIButton)?.flash()
        }

        if typedString.count == maxLength {
            delegate?.enableSubmitBtn()
        }
    }
    @IBAction func number6Action(_ sender: Any) {
        if typedString.count < maxLength {
        typedString.append(contentsOf: "6")
        delegate?.setTextField(number: typedString)
        (sender as? UIButton)?.flash()
        }
        if typedString.count == maxLength {
            delegate?.enableSubmitBtn()
        }

    }
    @IBAction func number7Action(_ sender: Any) {
        if typedString.count < maxLength {
        typedString.append(contentsOf: "7")
        delegate?.setTextField(number: typedString)
        (sender as? UIButton)?.flash()
        }

        if typedString.count == maxLength {
            delegate?.enableSubmitBtn()
        }
    }
    @IBAction func number8Action(_ sender: Any) {
        if typedString.count < maxLength {
        typedString.append(contentsOf: "8")
        delegate?.setTextField(number: typedString)
        (sender as? UIButton)?.flash()
        }
        
        if typedString.count == maxLength {
            delegate?.enableSubmitBtn()
        }

    }
    @IBAction func number9Action(_ sender: Any) {
        if typedString.count < maxLength {
        typedString.append(contentsOf: "9")
        delegate?.setTextField(number: typedString)
        (sender as? UIButton)?.flash()
        }
        
        if typedString.count == maxLength {
            delegate?.enableSubmitBtn()
        }

    }
    @IBAction func number0Action(_ sender: Any) {
        if typedString.count < maxLength {
        typedString.append(contentsOf: "0")
        delegate?.setTextField(number: typedString)
        (sender as? UIButton)?.flash()
        }
        
        if typedString.count == maxLength {
            delegate?.enableSubmitBtn()
        }

    }
    @IBAction func backAction(_ sender: Any) {
        typedString = String(typedString.dropLast())
        delegate?.setTextField(number: typedString)
        (sender as? UIButton)?.flash()

    }
    @IBAction func goBtnAction(_ sender: Any) {
        delegate?.goBtnAction()
        (sender as? UIButton)?.flash()
        
    }
    
    
    
    // MARK: - Initializers
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    // MARK: - Private Helper Methods
    
    // Performs the initial setup.
    private func setupView() {
        let view = viewFromNibForClass()
        view.frame = bounds

        // Auto-layout stuff.
        view.autoresizingMask = [
            UIView.AutoresizingMask.flexibleWidth,
            UIView.AutoresizingMask.flexibleHeight
        ]
        
        number1.backgroundColor = buttonColor
        number1.layer.borderWidth = buttonBorderWidth
        number1.layer.borderColor = buttonBorderColor
        number1.layer.cornerRadius = buttonCornerRadius
        
        number2.backgroundColor = buttonColor
        number2.layer.borderWidth = buttonBorderWidth
        number2.layer.borderColor = buttonBorderColor
        number2.layer.cornerRadius = buttonCornerRadius
        
        number3.backgroundColor = buttonColor
        number3.layer.borderWidth = buttonBorderWidth
        number3.layer.borderColor = buttonBorderColor
        number3.layer.cornerRadius = buttonCornerRadius
        
        number4.backgroundColor = buttonColor
        number4.layer.borderWidth = buttonBorderWidth
        number4.layer.borderColor = buttonBorderColor
        number4.layer.cornerRadius = buttonCornerRadius
        
        number5.backgroundColor = buttonColor
        number5.layer.borderWidth = buttonBorderWidth
        number5.layer.borderColor = buttonBorderColor
        number5.layer.cornerRadius = buttonCornerRadius
        
        number6.backgroundColor = buttonColor
        number6.layer.borderWidth = buttonBorderWidth
        number6.layer.borderColor = buttonBorderColor
        number6.layer.cornerRadius = buttonCornerRadius
        
        number7.backgroundColor = buttonColor
        number7.layer.borderWidth = buttonBorderWidth
        number7.layer.borderColor = buttonBorderColor
        number7.layer.cornerRadius = buttonCornerRadius
        
        number8.backgroundColor = buttonColor
        number8.layer.borderWidth = buttonBorderWidth
        number8.layer.borderColor = buttonBorderColor
        number8.layer.cornerRadius = buttonCornerRadius
        
        number9.backgroundColor = buttonColor
        number9.layer.borderWidth = buttonBorderWidth
        number9.layer.borderColor = buttonBorderColor
        number9.layer.cornerRadius = buttonCornerRadius
        
        number0.backgroundColor = buttonColor
        number0.layer.borderWidth = buttonBorderWidth
        number0.layer.borderColor = buttonBorderColor
        number0.layer.cornerRadius = buttonCornerRadius
        
        deleteBtn.backgroundColor = buttonColor
        deleteBtn.layer.borderWidth = buttonBorderWidth
        deleteBtn.layer.borderColor = buttonBorderColor
        deleteBtn.layer.cornerRadius = buttonCornerRadius
        deleteBtn.setTitle("", for: .normal)
        
        goBtn.backgroundColor = buttonColor
        goBtn.layer.borderWidth = buttonBorderWidth
        goBtn.layer.borderColor = buttonBorderColor
        goBtn.layer.cornerRadius = buttonCornerRadius
            
        let attrFont = UIFont.systemFont(ofSize: 35)
        
        let title1 = number1.titleLabel!.text!
        let attrTitle1 = NSAttributedString(string: title1, attributes: [NSAttributedString.Key.font: attrFont])
        number1.setAttributedTitle(attrTitle1, for: UIControl.State.normal)
        
        let title2 = number2.titleLabel!.text!
        let attrTitle2 = NSAttributedString(string: title2, attributes: [NSAttributedString.Key.font: attrFont])
        number2.setAttributedTitle(attrTitle2, for: UIControl.State.normal)
        
        let title3 = number3.titleLabel!.text!
        let attrTitle3 = NSAttributedString(string: title3, attributes: [NSAttributedString.Key.font: attrFont])
        number3.setAttributedTitle(attrTitle3, for: UIControl.State.normal)
        
        let title4 = number4.titleLabel!.text!
        let attrTitle4 = NSAttributedString(string: title4, attributes: [NSAttributedString.Key.font: attrFont])
        number4.setAttributedTitle(attrTitle4, for: UIControl.State.normal)
        
        let title5 = number5.titleLabel!.text!
        let attrTitle5 = NSAttributedString(string: title5, attributes: [NSAttributedString.Key.font: attrFont])
        number5.setAttributedTitle(attrTitle5, for: UIControl.State.normal)
        
        let title6 = number6.titleLabel!.text!
        let attrTitle6 = NSAttributedString(string: title6, attributes: [NSAttributedString.Key.font: attrFont])
        number6.setAttributedTitle(attrTitle6, for: UIControl.State.normal)
        
        let title7 = number7.titleLabel!.text!
        let attrTitle7 = NSAttributedString(string: title7, attributes: [NSAttributedString.Key.font: attrFont])
        number7.setAttributedTitle(attrTitle7, for: UIControl.State.normal)
        
        let title8 = number8.titleLabel!.text!
        let attrTitle8 = NSAttributedString(string: title8, attributes: [NSAttributedString.Key.font: attrFont])
        number8.setAttributedTitle(attrTitle8, for: UIControl.State.normal)
        
        let title9 = number9.titleLabel!.text!
        let attrTitle9 = NSAttributedString(string: title9, attributes: [NSAttributedString.Key.font: attrFont])
        number9.setAttributedTitle(attrTitle9, for: UIControl.State.normal)
        
        let title0 = number0.titleLabel!.text!
        let attrTitle0 = NSAttributedString(string: title0, attributes: [NSAttributedString.Key.font: attrFont])
        number0.setAttributedTitle(attrTitle0, for: UIControl.State.normal)
        
        let titleGO = goBtn.titleLabel!.text!
        let attrTitleGO = NSAttributedString(string: titleGO, attributes: [NSAttributedString.Key.font: attrFont])
        goBtn.setAttributedTitle(attrTitleGO, for: UIControl.State.normal)
        
        // Show the view.
        addSubview(view)
    }
    
    // Loads a XIB file into a view and returns this view.
    private func viewFromNibForClass() -> UIView {
        
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: String(describing: type(of: self)), bundle: bundle)
        let view = nib.instantiate(withOwner: self, options: nil).first as! UIView
        
        return view
    }
}

extension UIButton {
    
        func flash() {
            let flash = CABasicAnimation(keyPath: "opacity")
            flash.duration = 0.3
            flash.fromValue = 1
            flash.toValue = 0.1
            flash.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
            flash.autoreverses = true
            flash.repeatCount = 1
            layer.add(flash, forKey: nil)
        }
    
}
