//
//  NumPadTypeProtocol.swift
//  Hello_Product
//
//  Created by Zentech-038 on 06/11/23.
//

import Foundation

protocol NumPadTypeProtocol {
    func setTextField(number: String)
    func goBtnAction()
    func enableSubmitBtn()
}
