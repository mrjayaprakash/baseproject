//
//  QRHelper.swift
//  Hello_Product
//
//  Created by Zentech-038 on 26/11/23.
//

import Foundation
import UIKit
import CoreImage

class QRHelper {
    
    static func generateQRCode(from value: String) -> UIImage? {
        // Convert the integer to a string
        let stringValue = "\(value)"
        
        // Create the data for the QR code
        if let data = stringValue.data(using: .utf8) {
            // Create the QR code filter
            let qrCodeFilter = CIFilter(name: "CIQRCodeGenerator")
            
            // Set the filter's input message
            qrCodeFilter?.setValue(data, forKey: "inputMessage")
            
            // Get the output image from the filter
            if let outputImage = qrCodeFilter?.outputImage {
                // Scale the image to an appropriate size
                let transformedImage = outputImage.transformed(by: CGAffineTransform(scaleX: 10, y: 10))
                
                // Convert the CIImage to a UIImage
                if let cgImage = CIContext().createCGImage(transformedImage, from: transformedImage.extent) {
                    return UIImage(cgImage: cgImage)
                }
            }
        }
        
        // Return nil if something went wrong
        return nil
    }
}
