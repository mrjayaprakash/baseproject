//
//  AppDelegate.swift
//  Hello_Product
//
//  Created by Zentech-038 on 06/11/23
//

import UIKit
import IQKeyboardManager
import UserNotifications


@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
            
        IQKeyboardManager.shared().isEnabled = true
        
        var initialViewController = UIViewController()
        
        registerForPushNotifications()
        
        if UserDefaults.standard.string(forKey: Constants.loginTockenConstant) == nil {
//            print("Don't have Token Saved")
            initialViewController = UIStoryboard(name: "Login", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        } else {
//            print("Token is already Saved")
            initialViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MenuVC") as! MenuVC
            
        }
        
        let nav: UINavigationController = UINavigationController(rootViewController: initialViewController)
        
        nav.navigationController?.navigationBar.isHidden = true
        self.window?.rootViewController = nav
        self.window?.makeKeyAndVisible()

        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    private func registerForPushNotifications() {
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) {
            (granted, error) in
            // 1. Check to see if permission is granted
            guard granted else { return }
            // 2. Attempt registration for remote notifications on the main thread
            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
            }
        }
    }
}

extension AppDelegate: UNUserNotificationCenterDelegate {
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        print("Device Token :- \(deviceToken)")
        
        let deviceTokenString = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
        print("Decoded Device Token: \(deviceTokenString)")
        
        
        if isUserRegisteredForRemoteNotifications() {
            /////// call push register api
            
            UserDefaults.standard.set(deviceTokenString, forKey: Constants.deviceToken)

            
        } else {
            /////// show alert push notification needs to be enabled from settings
            
            let alert = UIAlertController(
                title: "Alert",
                message: "Please enable push notifications from settings.",
                preferredStyle: UIAlertController.Style.alert
            )
            
            alert.addAction(UIAlertAction(
                title: "OK",
                style: UIAlertAction.Style.default,
                handler: nil
            ))
            
            UIApplication.shared.keyWindow?.rootViewController?.present(
                alert,
                animated: true,
                completion: nil
            )
        }
        
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Error while registring push Notification :- \(error)")
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
           let actionIdentifier = response.actionIdentifier

        switch actionIdentifier {
        case UNNotificationDismissActionIdentifier: // Notification was dismissed by user
            // Do something
            completionHandler()
        case UNNotificationDefaultActionIdentifier: // App was opened from notification
            // Do something
            print("Launched from notification")
            completionHandler()
        default:
            completionHandler()
        }
       }
}

extension AppDelegate {
    
    func isUserRegisteredForRemoteNotifications() -> Bool {
        let isRegisteredForRemoteNotifications = UIApplication.shared.isRegisteredForRemoteNotifications
        if isRegisteredForRemoteNotifications
        {
            // User is registered for notification
            return true
        }
        else
        {
            // Show alert user is not registered for notification
            return false
        }
    }
    
    
    func application(
      _ application: UIApplication,
      didReceiveRemoteNotification userInfo: [AnyHashable: Any],
      fetchCompletionHandler completionHandler:
      @escaping (UIBackgroundFetchResult) -> Void
    ) {
        guard let aps = userInfo["aps"] as? [String: AnyObject] else {
            completionHandler(.failed)
            return
        }
        
        guard let message = aps["alert"]?["body"] as? String else {return}
        
        let alert = UIAlertController(
            title: "Push",
            message: "\(message)",
            preferredStyle: UIAlertController.Style.alert
        )
        
        alert.addAction(UIAlertAction(
            title: "OK",
            style: UIAlertAction.Style.default,
            handler: { action in

            }
        ))
        
        UIApplication.shared.keyWindow?.rootViewController?.present(
            alert,
            animated: true,
            completion: nil
        )
    }
}

