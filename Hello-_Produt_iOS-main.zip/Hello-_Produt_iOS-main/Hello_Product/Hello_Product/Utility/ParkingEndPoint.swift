//
//  ParkingEndPoint.swift
//  Hello_Product
//
//  Created by Zentech-038 on 01/04/24.
//

import Foundation

enum ParkingEndPoint {
    case getAllParking(siteID: String)
    case getAllParkingbyUnit(unitID: String)
    case postParkingBookingDetail(detail: PostParkingDetailModel)
    case getOccupiedParkingDetails
    case ReleaseSlot(id: String)
    case getAllOpenParking(siteID: String)


}

// https://fakestoreapi.com/products
extension ParkingEndPoint: EndPointType {

    var path: String {
        switch self {
            
        case.getAllParking(siteID: let siteID):
            
            return "/api/parkingDetails/getParkingBySiteId/\(siteID)"
            
        case.getAllParkingbyUnit(unitID: let unitID):
            return "/api/parkingDetails/getParkingByUnitId/\(unitID)"

        case .postParkingBookingDetail:
            return "/api/OccupiedParking/postOccupiedParking"
            
        case .getOccupiedParkingDetails:
            return "/api/OccupiedParking/getAllOccupiedParking"
            
        case .ReleaseSlot(id: let id):
            return "/api/OccupiedParking/cancelOccupiedParkingById/\(id)"
            
        case .getAllOpenParking(siteID: let siteID):
            return "/api/parkingDetails/getFreeParkingBySiteId/\(siteID)"

        }
    }

    var baseURL: String {
//        return "https://192.168.1.19:7010"
        return "https://helloproduct.azurewebsites.net"
        
    }

    var url: URL? {
        return URL(string: "\(baseURL)\(path)")
    }

    var method: HTTPMethods {
        switch self {
            
        case .getAllParking:
            return .get
            
        case .postParkingBookingDetail:
            return .post
            
        case .getOccupiedParkingDetails:
            return .get
            
        case .ReleaseSlot:
            return .delete
            
        case .getAllParkingbyUnit(unitID: let unitID):
            return .get

        case .getAllOpenParking(siteID: let siteID):
            return .get

        }
    }

    var body: Encodable? {
        switch self {
            
        case .getAllParking(siteID: let siteID):
            return nil
            
        case .postParkingBookingDetail(detail: let detail):
            return detail
            
        case .getOccupiedParkingDetails:
            return nil
            
        case .ReleaseSlot:
            return nil
            
        case .getAllParkingbyUnit(unitID: let unitID):
            return nil
            
        case .getAllOpenParking(siteID: let siteID):
            return nil
        }
    }

    var headers: [String : String]? {
        ApiManager.commonHeaders
    }
}
