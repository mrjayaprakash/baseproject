//
//  RaiseAlertEndPoint.swift
//  Hello_Product
//
//  Created by Zentech-038 on 14/02/24.
//

import Foundation

enum RaiseAlertEndPoint {
    case registerDeviceToken(details: PushModel)
//    case raiseAlert(details: Alert)
}

extension RaiseAlertEndPoint: EndPointType {
    

    var path: String {
        switch self {
            
        case .registerDeviceToken:
            return "/api/DeviceToken/SetDeviceTokenAsync"
            
//        case .raiseAlert:
//            return "/api/EmergencyAlert/SetEmergencyAlertAsync"
        }
    }

    var baseURL: String {
        return "https://helloproduct.azurewebsites.net"
//        return "https://192.168.1.19:7010"

    }

    var url: URL? {
        return URL(string: "\(baseURL)\(path)")
    }

    var method: HTTPMethods {
        switch self {
        
        case .registerDeviceToken:
            return .get

        }
    }

    var body: Encodable? {
        switch self {
            
        case .registerDeviceToken:
            return nil
            
        }
    }

    var headers: [String : String]? {
        switch self {
            
        case .registerDeviceToken:
            return ApiManager.commonHeaders

        }
    }
}
