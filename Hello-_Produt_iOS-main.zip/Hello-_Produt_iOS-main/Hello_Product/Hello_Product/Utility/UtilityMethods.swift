//
//  UtilityMethod.swift
//  Hello_Product
//
//  Created by Zentech-038 on 17/11/23.
//

import Foundation

class UtilityMethods {
    static func isJWTExpired(exp: Int64) -> Bool {
        //Time in seconds since 1970.
        let expiry = exp //1465891091

        //if expirationDate > Now
        if Date(timeIntervalSince1970: Double(expiry)) > Date() {
            print("JWT hasn't expired yet.")
            return false
        } else {
            print("JWT has expired.")
            return true
        }
    }
}
