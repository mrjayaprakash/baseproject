//
//  LoginEndPointType.swift
//  Hello_Product
//
//  Created by Zentech-038 on 16/11/23.
//

import Foundation


enum LoginEndPoint {
    case login(loginDetails: LoginModel) // POST
}

extension LoginEndPoint: EndPointType {

    var path: String {
        switch self {
        case .login:
            return "/api/Auth/login"
        }
    }

    var baseURL: String {
        return "http://192.168.0.219:5000"
    }

    var url: URL? {
        return URL(string: "\(baseURL)\(path)")
    }

    var method: HTTPMethods {
        switch self {
        case .login:
            return .post
        }
    }

    var body: Encodable? {
        switch self {
        case .login(let loginDetails):
            return loginDetails
        }
    }

    var headers: [String : String]? {
        ApiManager.commonHeaders
    }
}
