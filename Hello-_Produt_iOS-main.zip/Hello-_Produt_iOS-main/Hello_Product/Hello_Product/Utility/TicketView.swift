//
//  TicketView.swift
//  MovieBooking
//
//  Created by Zentech-038 on 15/02/24.
//

import SwiftUI

struct TicketView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    TicketView()
}
