//
//  ManageUsersEndPoint.swift
//  Hello_Product
//
//  Created by Zentech-038 on 19/11/23.
//

import Foundation

enum ManageUsersEndPoint {
    case getAllMembers
    case getMemberDetailsById(memberId: String)
    case deleteMember(memberId: String)
    case getAllRole
    case getAllSites
    case getAllUnits
    case getAllRFIDs
    case getAllPendingRequest(unitId: String)
    case getAllInvitedVisitor(memberId: String)
    case cancelInvite(visitorId: String, cancelDetails: CancelInvite)
    case sendInvite(details: SendInvitationDetail)
    case rescheduleInvite(details: RescheduleDetails, id: String)
    case acceptRequest(status: Status, mobileNo: String)
    case rejectRequest(status: Status, mobileNo: String)
    case fetchVisitorByMobile(mobileNo: String)
    case fetchVersionPletform
    case postMemberDetail(detail: MultipartRequest)
    case registerForPushNotification(details: PushModel)
    case getBannerImage(id: String)
    
    
}

// https://fakestoreapi.com/products
extension ManageUsersEndPoint: EndPointType {

    var path: String {
        switch self {
        case .getAllMembers:
            return "/api/ManageUsers/getAllMembers"
            
        case .getMemberDetailsById(let memberId):
            return "/api/ManageUsers/getMemberById/\(memberId)"
            
        case .deleteMember(let memberId):
            return "/api/ManageUsers/deleteUsers/\(memberId)"
            
        case .getAllRole:
            return "/api/Role/getAllRole"
            
        case .getAllSites:
            return "/api/SiteDetails/getAllSiteDetails"
            
        case .getAllUnits:
            return "/api/Unit/getAllUnit"
            
        case .getAllRFIDs:
            return "/api/RFID/getAllAvailableRFID"
            
        case .getAllPendingRequest(unitId: let unitId):
            return "/api/Visitors/getPendingVisitor/\(unitId)"
            
        case .getAllInvitedVisitor(memberId: let memberId):
            return "/api/InviteVisitor/getInvitedVisitor/\(memberId)"
            
        case .cancelInvite(visitorId: let id, cancelDetails: let details):
            return "/api/InviteVisitor/putInvitedVisitorComment/\(id)"
            
        case .sendInvite:
            return "/api/InviteVisitor/postInvitedVisitor"
            
        case .rescheduleInvite(details: let details, id: let id):
            return "/api/InviteVisitor/putInvitedVisitor/\(id)"
            
        case .acceptRequest(status: let status, mobileNo: let mobileNo):
            return "/api/Visitors/updateVisitorStatus/\(mobileNo)"
            
        case .rejectRequest(status: let status, mobileNo: let mobileNo):
            return "/api/Visitors/updateVisitorStatus/\(mobileNo)"
            
        case .fetchVisitorByMobile(mobileNo: let mobileNo):
            return "/api/Visitors/getVisitorByMobileNumber/\(mobileNo)"
            
        case .fetchVersionPletform:
            return "/api/VersionUpdate/getAllVersionUpdate"
        
        case .postMemberDetail:
            return "/api/ManageUsers/postUsers"

        case .registerForPushNotification:
            return "/api/DeviceToken/SetDeviceTokenAsync"
            
        case .getBannerImage(id: let id):
            return "/api/AdvertisementImage/getAllAdvertisementImageById/\(id)"
        }
    }

    var baseURL: String {
        return "https://helloproduct.azurewebsites.net"
//        return "https://192.168.1.19:7010"

    }

    var url: URL? {
        return URL(string: "\(baseURL)\(path)")
    }

    var method: HTTPMethods {
        switch self {
        case .getAllMembers:
            return.get
            
        case .getMemberDetailsById:
            return .get
            
        case .deleteMember:
            return .delete
        
        case .getAllRole:
            return .get
            
        case .getAllSites:
            return .get
            
        case .getAllUnits:
            return .get
            
        case .getAllRFIDs:
            return .get
            
        case .getAllPendingRequest:
            return .get
            
        case .getAllInvitedVisitor:
            return .get
            
        case .cancelInvite:
            return .put
            
        case .sendInvite:
            return .post
            
        case .rescheduleInvite:
            return .put
            
        case .acceptRequest:
            return .put
        case .rejectRequest:
            return .put
            
        case .fetchVisitorByMobile:
            return .get
            
        case .fetchVersionPletform:
            return .get
        
        case .postMemberDetail:
            return .post
            
        case .registerForPushNotification:
            return .post
            
        case .getBannerImage(id: let id):
            return .get
            
        }
    }

    var body: Encodable? {
        switch self {
        case .getAllMembers:
            return nil
            
        case .getMemberDetailsById:
            return nil
            
        case .deleteMember:
            return nil
        
        case .getAllRole:
            return nil
            
        case .getAllSites:
            return nil
            
        case .getAllUnits:
            return nil
            
        case .getAllRFIDs:
            return nil
            
        case .getAllPendingRequest:
            return nil
            
        case .getAllInvitedVisitor:
            return nil
            
        case .cancelInvite(visitorId: let visitorId, cancelDetails: let cancelDetails):
            return cancelDetails
            
        case .sendInvite(details: let details):
            return details
            
        case .rescheduleInvite(details: let details, id: let id):
            return details
            
        case .acceptRequest(status: let status, mobileNo: let mobileNo):
            return status
            
        case .rejectRequest(status: let status, mobileNo: let mobileNo):
            return status
            
        case .fetchVisitorByMobile:
            return nil
            
        case .fetchVersionPletform:
            return nil
            
        case .postMemberDetail(detail: let detail):
            return detail
            
        case .registerForPushNotification(details: let details):
            return details
            
        case .getBannerImage(id: let id):
            return nil
        }
    }

    var headers: [String : String]? {
        ApiManager.commonHeaders
    }
}
