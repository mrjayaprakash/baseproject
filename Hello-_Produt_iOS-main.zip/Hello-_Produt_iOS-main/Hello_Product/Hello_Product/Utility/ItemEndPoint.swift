//
//  ItemEndPoint.swift
//  Hello_Product
//
//  Created by Zentech-038 on 17/11/23.
//

import Foundation

enum LoginEndPoint {
    case login(loginDetail: LoginDetailModel) // POST
    case checkUserAvailable(mobileNo: String)
    case changePassword(mobileNo: String, password: ChangePassword)
}

// https://fakestoreapi.com/products
extension LoginEndPoint: EndPointType {

    var path: String {
        switch self {
        case .login:
            return "/api/Auth/login"
        
        case .checkUserAvailable(mobileNo: let mobileNo):
            return "/api/ManageUsers/getEmployeeStatus/\(mobileNo)"
            
        case .changePassword(mobileNo: let mobileNo, password: let password):
            return "/api/Password/putPassword/\(mobileNo)"
        }
    }

    var baseURL: String {
//        return "http://192.168.1.17:5000"
        return "https://helloproduct.azurewebsites.net"
    }

    var url: URL? {
        return URL(string: "\(baseURL)\(path)")
    }

    var method: HTTPMethods {
        switch self {
        case .login:
            return .post
        
        case .checkUserAvailable:
            return .get
            
        case .changePassword:
            return .put
        }
    }

    var body: Encodable? {
        switch self {
        
        case .login(let loginDetail):
            return loginDetail
            
        case .checkUserAvailable:
            return nil
            
        case .changePassword(mobileNo: let mobileNo, password: let password):
            return password
        }
    }

    var headers: [String : String]? {
        ApiManager.commonHeaders
    }
}
