//
//  TicketingEndPoint.swift
//  Hello_Product
//
//  Created by Zentech-038 on 23/04/24.
//

import Foundation

enum TicketingEndPoint {
    case getAllAssignedTicketbyId(id: String)
    case getAssetDetails(id: String)
    case getStatusDetail(id: String)
    case getAllStatus
}

// https://fakestoreapi.com/products
extension TicketingEndPoint: EndPointType {

    var path: String {
        switch self {
        case .getAllAssignedTicketbyId(id: let id):
            return "/api/TicketDetails/getTicketDetailsAssignedToId/\(id)"
            
        case .getAssetDetails(id: let id):
            return "/api/AssetsMaster/getAllAssetsMasterById/\(id)"
            
        case .getStatusDetail(id: let id):
            return "/api/TicketStatusDetails/GetTicketStatusDetailsByTickitId/\(id)"
            
        case .getAllStatus:
            return "/api/TicketStatusMaster/GetTicketStatusMasterAll"
            
        }
    }

    var baseURL: String {
//        return "https://192.168.1.19:7010"
        return "https://helloproduct.azurewebsites.net"
        
    }

    var url: URL? {
        return URL(string: "\(baseURL)\(path)")
    }

    var method: HTTPMethods {
        switch self {
            
        case .getAllAssignedTicketbyId:
            return .get
            
        case .getAssetDetails:
            return .get
            
        case .getStatusDetail:
            return .get
            
        case .getAllStatus:
            return .get
        }
    }

    var body: Encodable? {
        switch self {
    
        case .getAllAssignedTicketbyId:
            return nil
        case .getAssetDetails:
            return nil
        case .getStatusDetail:
            return nil
        case .getAllStatus:
            return nil
        }
    }

    var headers: [String : String]? {
        ApiManager.commonHeaders
    }
}
