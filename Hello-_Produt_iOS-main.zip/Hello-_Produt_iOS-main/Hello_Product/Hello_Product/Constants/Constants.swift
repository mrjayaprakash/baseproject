//
//  Constant.swift
//  Hello_Product
//
//  Created by Zentech-038 on 06/11/23.
//

import Foundation
import UIKit


class Constants {
    static var loginTockenConstant = "LoginToken"
    static var memberIdConstant = "memberId"
    static var memberNameConstant = "memberName"
    static var qrNumverConstant = "qrNumber"
    static var roleConstant = "role"
    static var techId = "techId"
    static var unitName = "unitName"
    static var deviceToken = "deviceToken"
    static var myDesignation = "myDesignation"
    static var myrole = "myrole"
    static var myUnitNo = "myUnitNo"

}

//class URLConstants {
//    static var baseURL = "http://192.168.0.219:5000"
//    
//    static var login = "\(baseURL)/api/Auth/login"
//
//}

class GlobalConstants {
    static var isSimulatorDebugOn = false
    static var loggedInMemberDetails = MemberDetails()
    
    static var myDesignation = ""
    static var memberImageString = ""
    static var genderConstants: [Gender] = [Gender(id: 1, name: "Male"), 
                                            Gender(id: 2, name: "Female"),
                                            Gender(id: 3, name: "Others")]
}

class ColorConstants {
    static var cellBackgroundColor = UIColor(red: 224/255, green: 224/255, blue: 224/255, alpha: 1.0) //  #EDEDED
    static var TrackerLineColor  = #colorLiteral(red: 0, green: 0.6788796186, blue: 0.2190021574, alpha: 1)
    static var CanceledBooking  = #colorLiteral(red: 0, green: 0.6788796186, blue: 0.2190021574, alpha: 1)
    static var OccupiedBooking  = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
}

