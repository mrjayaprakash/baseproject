//
//  PushModel.swift
//  Hello_Product
//
//  Created by Zentech-038 on 09/02/24.
//

import Foundation
import UIKit

struct PushModel: Codable {
    var memberId: Int?
    var deviceToken: String?
    var deviceType: String?
    
    init(memberId: Int, deviceToken: String, deviceType: String) {
        self.memberId = memberId
        self.deviceToken = deviceToken
        self.deviceType = deviceType
    }
}


struct RegisterResponse: Codable {
    var isSuccess: Bool?
    var message: String?
    var data: [VersionInfo]?
}
