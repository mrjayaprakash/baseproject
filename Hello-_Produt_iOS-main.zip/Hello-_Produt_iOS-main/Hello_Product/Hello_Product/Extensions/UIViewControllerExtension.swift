//
//  UIViewControllerExtension.swift
//  Hello_Product
//
//  Created by Zentech-038 on 22/11/23.
//

import Foundation
import UIKit
import MBProgressHUD

extension UIViewController {
    //Loader
    func showActivityIndicator(progressLabel:String = "") {
        let progressHUD = MBProgressHUD.showAdded(to: self.view, animated: true)
        progressHUD.label.text = progressLabel
        progressHUD.label.numberOfLines = 2
    }
    
    func hideActivityIndicator() {
        DispatchQueue.main.async {
            MBProgressHUD.hide(for: self.view, animated: true)
        }
    }
    
    // validations
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    func isValidName(_ name: String) -> Bool {
        let nameRegex = "^[a-zA-Z ]+$" // Regular expression for alphabetic characters and spaces
        
        let namePredicate = NSPredicate(format: "SELF MATCHES %@", nameRegex)
        let isValid = namePredicate.evaluate(with: name)
        
        return isValid
    }

    
    func isValidIndianMobileNumber(_ mobileNumber: String) -> Bool {
        let mobileNumberRegex = "^[0-9]{10}$" // Regular expression for 10 digits without spaces or dashes
        
        let mobileNumberPredicate = NSPredicate(format: "SELF MATCHES %@", mobileNumberRegex)
        let isValid = mobileNumberPredicate.evaluate(with: mobileNumber)
        
        return isValid
    }
    
    func showUpdateAlert(url: URL){
        let alert  = UIAlertController(title: "Alert", message: "A new version of the app is available on the Appstore. Kindly update the app to continue.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Update", style: .default, handler: {_ in
            
            UIApplication.shared.openURL(url)

            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(url)
            }
        }))
        self.present(alert, animated: true, completion: nil)
    }

    
    
}

extension NSMutableData {
    func appendString(_ string: String) {
        if let data = string.data(using: .utf8) {
            append(data)
        }
    }
}
