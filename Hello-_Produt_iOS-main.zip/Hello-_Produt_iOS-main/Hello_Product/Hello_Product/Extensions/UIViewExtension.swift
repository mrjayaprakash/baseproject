//
//  UIViewExtension.swift
//  Hello_Product
//
//  Created by Zentech-038 on 26/11/23.
//

import Foundation
import UIKit

extension UIView {
    func applyCardEffect() {
        // Set corner radius
        self.layer.cornerRadius = 10.0
        self.layer.masksToBounds = false

        // Set shadow properties
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.5
        self.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.layer.shadowRadius = 4.0

        // Set border
        self.layer.borderWidth = 1.0
        self.layer.borderColor = UIColor.clear.cgColor

        // Optionally, you can add a background color
        self.backgroundColor = UIColor.white
    }
    
    func applyCardEffectWithRedBackground() {
        // Set corner radius
        self.layer.cornerRadius = 10.0
        self.layer.masksToBounds = false

        // Set shadow properties
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.5
        self.layer.shadowOffset = CGSize(width: 0, height: 2)
        self.layer.shadowRadius = 4.0

        // Set border
        self.layer.borderWidth = 1.0
        self.layer.borderColor = UIColor.clear.cgColor

        // Optionally, you can add a background color
        self.backgroundColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
    }
    
    func exportAsPdfFromView() -> String {
        
        let pdfPageFrame = self.bounds
        let pdfData = NSMutableData()
        UIGraphicsBeginPDFContextToData(pdfData, pdfPageFrame, nil)
        UIGraphicsBeginPDFPageWithInfo(pdfPageFrame, nil)
        guard let pdfContext = UIGraphicsGetCurrentContext() else { return "" }
        self.layer.render(in: pdfContext)
        UIGraphicsEndPDFContext()
        return self.saveViewPdf(data: pdfData)
        
    }
    
    // Save pdf file in document directory
    func saveViewPdf(data: NSMutableData) -> String {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let docDirectoryPath = paths[0]
        let pdfPath = docDirectoryPath.appendingPathComponent("VisitingCard.pdf")
        if data.write(to: pdfPath, atomically: true) {
            return pdfPath.path
        } else {
            return ""
        }
    }
}
